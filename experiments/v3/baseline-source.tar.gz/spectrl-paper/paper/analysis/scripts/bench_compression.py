"""Explicit v3 lossless benchmark with saved repeated timings and provenance."""
from contextlib import redirect_stdout
from datetime import datetime, timezone
import copy
import hashlib
import io
import json
import os
from pathlib import Path
import platform
from statistics import median
import time
import warnings

import cbor2
import numpy as np

from spectrl import encode_spectrum
from spectrl.cbor_format import read_token_document
from spectrl.peaks import canonical_sort
from spectrl.pipeline import decode_pipeline, encode_pipeline
from _datasets import encode_all, inputs

PAPER = Path(__file__).resolve().parents[2]
REPO = PAPER.parent
REPORT = PAPER / 'analysis/reports/compression-v3.json'
CANDIDATES = [('raw-zlib', 0, 1), ('raw-zstd', 0, 2), ('shuffle-zstd', 1, 2),
              ('dictionary-zstd', 2, 2), ('delta-zlib', 3, 1), ('delta-zstd', 3, 2), ('raw-none', 0, 0)]
PROFILES = {'raw-zlib': ['raw-zlib'],
            'psi-adaptive': ['raw-zlib', 'raw-zstd', 'shuffle-zstd', 'dictionary-zstd', 'raw-none'],
            'without-dictionary': ['raw-zlib', 'raw-zstd', 'shuffle-zstd', 'delta-zlib', 'delta-zstd', 'raw-none'],
            'v3-adaptive': [x[0] for x in CANDIDATES]}
REPEATS = 5


def measure(fn):
    fn()
    samples = []
    for _ in range(REPEATS):
        start = time.perf_counter_ns()
        fn()
        samples.append((time.perf_counter_ns() - start) / 1e6)
    return samples


def main():
    with redirect_stdout(io.StringIO()):
        rows = encode_all()
    arrays, spectra = [], []
    for row in rows:
        source = canonical_sort(row.source)
        values = [(k, getattr(source, k)) for k in ('mz', 'intensity', 'charge')]
        values += sorted(source.extra_arrays.items())
        choices = {}
        for key, data in values:
            if data is None:
                continue
            tail = {'float32': 1000521, 'float64': 1000523, 'int32': 1000519}[data.dtype.name]
            results = {}
            for label, eid, cid in CANDIDATES:
                enc, comp = [eid, 1], [cid, 1]
                blob, fidelity = encode_pipeline(data, tail, enc, comp)
                decoded = decode_pipeline(blob, tail, len(data), enc, comp, fidelity)
                if decoded.dtype != data.dtype or decoded.tobytes() != data.tobytes():
                    raise AssertionError(f'bit mismatch: {row.dataset.key}/{key}/{label}')
                results[label] = {'blob_bytes': len(blob),
                    'descriptor_cost': len(cbor2.dumps({2: enc, 3: comp, 5: blob, 7: 0}, canonical=True)),
                    'encoding': enc, 'compression': comp,
                    'encode_ms': measure(lambda: encode_pipeline(data, tail, enc, comp)),
                    'decode_ms': measure(lambda: decode_pipeline(blob, tail, len(data), enc, comp, 0))}
            choices[key] = results
            arrays.append({'dataset': row.dataset.key, 'spectrum_id': row.spectrum_id, 'array': key,
                           'dtype': data.dtype.name, 'representation': row.representation, 'ms_level': row.ms_level, 'count': len(data), 'raw_bytes': data.nbytes, 'pipelines': results})
        profiles = {}
        for profile, candidates in PROFILES.items():
            selected = {key: min(candidates, key=lambda label: choices[key][label]['descriptor_cost']) for key in choices}
            settings = {key: {field: choices[key][label][field] for field in ('encoding', 'compression')}
                        for key, label in selected.items()}
            with warnings.catch_warnings():
                warnings.simplefilter('ignore')
                token = encode_spectrum(source, lossless=True, array_encodings=settings)
            profiles[profile] = {'token_bytes': len(token), 'selected': selected}
        if profiles['v3-adaptive']['token_bytes'] != len(row.lossless_token):
            raise AssertionError('manual adaptive selection differs from production')
        without_context = copy.deepcopy(source)
        without_context.source = None
        without_context.acquisition = None
        without_context.processing = []
        without_context.array_processing = {}
        for item in [*without_context.scans, *without_context.precursors]:
            item.source = None
            item.acquisition = None
            item.processing = []
        wider = copy.deepcopy(source)
        for key, data in values:
            if data is not None and data.dtype == np.dtype('float32'):
                if key in ('mz', 'intensity', 'charge'):
                    setattr(wider, key, data.astype('float64'))
                else:
                    wider.extra_arrays[key] = data.astype('float64')
        with warnings.catch_warnings():
            warnings.simplefilter('ignore')
            no_context_bytes = len(encode_spectrum(without_context, lossless=True))
            widened_bytes = len(encode_spectrum(wider, lossless=True))
        spectra.append({'dataset': row.dataset.key, 'spectrum_id': row.spectrum_id, 'points': row.n_peaks,
                        'representation': row.representation, 'ms_level': row.ms_level,
                        'no_context_token_bytes': no_context_bytes, 'widened_float32_token_bytes': widened_bytes,
                        'profiles': profiles})
    paths = [PAPER / path for path in inputs()]
    paths += list((REPO / 'src/spectrl').rglob('*.py'))
    paths += [Path(__file__), PAPER / 'analysis/scripts/_datasets.py', PAPER / 'analysis/uv.lock']
    report = {'format': 'spectrl.v3', 'measured_at': datetime.now(timezone.utc).isoformat(),
              'environment': {'python': platform.python_version(), 'platform': platform.platform()},
              'warmups': 1, 'repeats': REPEATS, 'arrays': arrays, 'spectra': spectra,
              'inputs': {os.path.relpath(p, PAPER): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(set(paths))}}
    REPORT.write_text(json.dumps(report, indent=2) + '\n')
    print(f'Wrote {len(arrays)} arrays from {len(spectra)} spectra to {REPORT}')


if __name__ == '__main__':
    main()
