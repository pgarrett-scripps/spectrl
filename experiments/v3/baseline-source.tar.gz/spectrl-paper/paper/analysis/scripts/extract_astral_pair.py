"""Extract compact Astral spectra from a ThermoRawFileParser export.

Run with the paper analysis environment. Each input is a non-indexed mzML.
By default, select the lower median nonempty MS2 by point count and its MS1.
With --per-level, select evenly spaced point-count quantiles in each MS level
and retain referenced precursor scans. Ties break on source file order.
Peak arrays are copied unchanged.
"""

import argparse
import copy
import hashlib
import json
import xml.etree.ElementTree as ET
from collections import Counter, defaultdict
from pathlib import Path

NS = "http://psi.hupo.org/ms/mzml"
ET.register_namespace("", NS)
ET.register_namespace("xsi", "http://www.w3.org/2001/XMLSchema-instance")


def tag(name):
    return "{" + NS + "}" + name


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def subset(source, output, per_level=None):
    groups = defaultdict(list)
    references = {}
    metadata = {}
    windows = Counter()
    filters = Counter()
    header = []
    root_attrs = {}
    run_attrs = {}
    spectrum_attrs = {}
    stack = []
    for event, elem in ET.iterparse(source, events=("start", "end")):
        if event == "start":
            stack.append(elem)
            if elem.tag == tag("mzML"):
                root_attrs = dict(elem.attrib)
            elif elem.tag == tag("run"):
                run_attrs = dict(elem.attrib)
            elif elem.tag == tag("spectrumList"):
                spectrum_attrs = dict(elem.attrib)
            continue
        if elem.tag == tag("spectrum"):
            sid = elem.attrib["id"]
            params = {p.attrib["accession"]: p.attrib.get("value", "") for p in elem.iter(tag("cvParam"))}
            level = int(params["MS:1000511"])
            count = int(elem.attrib["defaultArrayLength"])
            references[sid] = [p.attrib["spectrumRef"] for p in elem.iter(tag("precursor")) if "spectrumRef" in p.attrib]
            metadata[sid] = {"id": sid, "ms_level": level, "n_peaks": count,
                             "scan_start_time": params.get("MS:1000016"),
                             "filter_string": params.get("MS:1000512")}
            if count:
                groups[level].append((count, len(metadata), sid))
            if level == 2:
                windows[(params.get("MS:1000828"), params.get("MS:1000829"))] += 1
            filters[params.get("MS:1000512", "").split(" ")[0]] += 1
            stack[-2].remove(elem)
        elif len(stack) == 2 and stack[-2].tag == tag("mzML") and elem.tag != tag("run"):
            header.append(copy.deepcopy(elem))
            stack[-2].remove(elem)
        stack.pop()

    if per_level is None:
        ordered = sorted(groups[2])
        quantile_ids = {ordered[(len(ordered) - 1) // 2][2]}
        selection = "Lower median nonempty MS2 by point count, ties by source file order, plus its referenced MS1"
    else:
        if per_level < 2:
            raise ValueError("per_level must be at least two")
        quantile_ids = set()
        for level in (1, 2):
            ordered = sorted(groups[level])
            k = min(per_level, len(ordered))
            positions = {round(j * (len(ordered) - 1) / (k - 1)) for j in range(k)} if k > 1 else {0}
            quantile_ids.update(ordered[p][2] for p in positions)
        selection = f"At most {per_level} nonempty spectra per MS level at evenly spaced point-count quantiles, including both extremes, ties by source file order, plus referenced MS1 spectra"
    chosen = set(quantile_ids)
    for selected in quantile_ids:
        if metadata[selected]["ms_level"] != 2:
            continue
        parents = references[selected]
        if len(parents) != 1 or metadata[parents[0]]["ms_level"] != 1:
            raise ValueError("Selected MS2 must reference exactly one MS1 spectrum")
        chosen.update(parents)

    root = ET.Element(tag("mzML"), root_attrs)
    root.extend(header)
    run = ET.SubElement(root, tag("run"), run_attrs)
    spectra = ET.SubElement(run, tag("spectrumList"), {**spectrum_attrs, "count": str(len(chosen))})
    stack = []
    for event, elem in ET.iterparse(source, events=("start", "end")):
        if event == "start":
            stack.append(elem)
            continue
        if elem.tag == tag("spectrum"):
            if elem.attrib["id"] in chosen:
                saved = copy.deepcopy(elem)
                saved.set("index", str(len(spectra)))
                spectra.append(saved)
            stack[-2].remove(elem)
        stack.pop()
    ET.ElementTree(root).write(output, encoding="utf-8", xml_declaration=True)
    report = {
        "source_mzml": source.name,
        "source_mzml_sha256": digest(source),
        "subset_mzml": output.name,
        "subset_mzml_sha256": digest(output),
        "subset_bytes": output.stat().st_size,
        "selection": selection,
        "per_level": per_level,
        "source_nonempty_spectra_by_ms_level": {str(k): len(v) for k, v in groups.items()},
        "source_analyzer_filter_prefix_counts": dict(filters),
        "source_ms2_isolation_offsets": [{"lower": k[0], "upper": k[1], "count": v} for k, v in windows.items()],
        "selected_spectra": [{**metadata[e.attrib["id"]], "selection_role": "point_count_quantile" if e.attrib["id"] in quantile_ids else "precursor_dependency"} for e in spectra],
    }
    output.with_suffix(".selection.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({k: v for k, v in report.items() if k != "selected_spectra"}, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--per-level", type=int, help="Select point-count quantiles per MS level instead of one median MS2")
    args = parser.parse_args()
    subset(args.source, args.output, args.per_level)
