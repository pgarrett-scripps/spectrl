"""Verified report access and summaries for the expanded encoding study."""

import hashlib
import json
from pathlib import Path
from statistics import median

PAPER = Path(__file__).resolve().parents[2]
REPORT = PAPER / "analysis/reports/encoding-study.json"


def load():
    report = json.loads(REPORT.read_text())
    for name, expected in report["inputs"].items():
        if hashlib.sha256((PAPER / name).read_bytes()).hexdigest() != expected:
            raise RuntimeError(f"Encoding study input changed: {name}. Rerun bench_encoding_study.py.")
    return report


def selected(report, budget, pool, role):
    return [r["lossy"][budget]["arrays"][role][pool] for r in report["spectra"]]


def add_stats(stats):
    report = load()
    rows = report["spectra"]
    stats.add(
        "study.n_psi_pipelines",
        len(rows[0]["arrays"][0]["pipelines"]),
        fmt=",",
        desc="Supported PSI array pipelines measured",
        sign="+",
    )
    stats.add(
        "study.n_schema_valid",
        sum(c["schema_valid"] for r in rows for c in r["containers"].values()),
        fmt=",",
        desc="Schema-validated single-spectrum mzML documents across three common profiles",
        sign="+",
    )
    stats.add(
        "study.repeats",
        report["repeats"],
        fmt=",",
        desc="Timed repetitions in the expanded encoding experiment",
        sign="+",
    )
    stats.add(
        "study.n_budgets",
        len(report["budgets"]),
        fmt=",",
        desc="Predefined paired reconstruction-error budgets",
        sign="+",
    )
    for i, (mz, intensity) in enumerate(report["budgets"]):
        for key, value, fmt in [("mz_da", mz, ".0e"), ("intensity_pct", intensity * 100, ".3f")]:
            stats.add(f"study.budget{i}.{key}", value, fmt=fmt, desc=f"Predefined budget {i} for {key}", sign="+")
        before = sum(r["lossy"][i]["psi_token_chars"] for r in rows)
        after = sum(r["lossy"][i]["extended_token_chars"] for r in rows)
        stats.add(
            f"study.budget{i}.saving_pct",
            100 * (1 - after / before),
            fmt=".1f",
            desc=f"Additional aggregate token reduction from quantizers at budget {i}",
            sign="+",
            between=(-100, 100),
        )
    i = 1
    for pool in ("psi", "extended"):
        arrays = selected(report, i, pool, "intensity")
        errors = [a["errors"] for a in arrays]
        positives = sum(e["positive_count"] for e in errors)
        stats.add(
            f"study.{pool}.zero_pct",
            100 * sum(e["positive_to_zero"] for e in errors) / positives,
            fmt=".3f",
            desc=f"Positive intensities reconstructed as zero at the middle budget with {pool}",
            between=(0, 100),
        )
        stats.add(
            f"study.{pool}.sa_min",
            min(e["spectral_angle"] for e in errors if e["spectral_angle"] is not None),
            fmt=".6f",
            desc=f"Minimum defined spectral angle at the middle budget with {pool}",
            between=(0, 1),
        )
    for mode in ("lossless", "lossy"):

        def total(label, mode=mode):
            return sum(r["outer"][mode]["cbor"][label]["framed_chars"] for r in rows)

        stats.add(
            f"study.brotli_{mode}_saving_pct",
            100 * (1 - total("brotli-9") / total("zlib-9")),
            fmt=".1f",
            desc=f"Aggregate CBOR framed size reduction from Brotli 9 versus zlib 9 in {mode} profile",
            sign="+" if mode == "lossy" else "-",
            between=(-100, 100),
        )
        ratio = median(median(r["outer"][mode]["cbor"]["brotli-9"]["encode_ms"]) for r in rows) / median(
            median(r["outer"][mode]["cbor"]["zlib-9"]["encode_ms"]) for r in rows
        )
        stats.add(
            f"study.brotli_{mode}_overhead_pct",
            100 * (total("brotli-9") / total("zlib-9") - 1),
            fmt=".1f",
            desc=f"Aggregate framed CBOR overhead for Brotli 9 versus zlib 9 in {mode}",
            sign="+" if mode == "lossless" else "-",
            between=(-100, 100),
        )
        stats.add(
            f"study.brotli_{mode}_time_ratio",
            ratio,
            fmt=".1f",
            desc=f"Ratio of median outer encode time Brotli 9 to zlib 9 for {mode}",
            sign="+",
        )
    for profile in ("raw-zlib", "psi-lossless", "numpress-default"):
        sizes = [r["containers"][profile] for r in rows]
        stats.add(
            f"study.{profile}.framed_saving_pct",
            median(100 * (1 - s["spectrl_chars"] / s["mzml_framed_chars"]) for s in sizes),
            fmt=".1f",
            desc=f"Median spectrl token reduction versus framed gzip mzML for {profile}",
            between=(-100, 100),
        )
