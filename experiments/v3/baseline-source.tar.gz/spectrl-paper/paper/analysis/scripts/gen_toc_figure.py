#!/usr/bin/env python3
"""Write ../../figures/toc_graphic.png: the ACS table-of-contents graphic.

Laid out at the size a TOC graphic is printed (3.25 x 1.75 in, per the ACS
graphics requirements) and rendered at 600 dpi. It restates the title as one
picture: a spectrl token sitting in a browser address bar, the complete
spectrum that bar resolves to, and a row of chips summarizing its use.

Honest by construction: the string after the `#` is an actual token and the
spectrum below is the untrimmed scan it encodes. The scan is the run's
median-size MS2 token, so the TOC graphic and the byte-anatomy figure dissect
the same spectrum. The chips summarize portability and local decoding.

The host is the reserved example domain rather than any particular deployment.
The claim is that a token opens in ANY spectrl-aware viewer, and a real host
would both narrow that and spend a third of the bar's characters saying so.

"""

from __future__ import annotations

from pathlib import Path

import matplotlib
import numpy as np

from _assets import record
from _bsa import MZML_INPUT, median_ms2
from spectrl import decode_token

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.colors import LinearSegmentedColormap  # noqa: E402
from matplotlib.patches import (  # noqa: E402
    Arc,
    FancyArrowPatch,
    FancyBboxPatch,
    Rectangle,
)
from matplotlib.ticker import MaxNLocator  # noqa: E402

HERE = Path(__file__).resolve().parent
PAPER = HERE.parent.parent
OUT = PAPER / "figures" / "toc_graphic.png"

W, H = 3.25, 1.75  # ACS TOC graphic, printed at natural size

INK = "#0f172a"
MUTED = "#64748b"
FAINT = "#94a3b8"
BLUE = "#2563eb"
BAR = "#f1f5f9"
EDGE = "#cbd5e1"

# Peak shading, weakest to strongest. Both stops are on the manuscript's blue.
PEAK_CMAP = LinearSegmentedColormap.from_list("spectrl", ["#a8c9f5", BLUE])

MZ_ACCESSION = "MS:1000744"  # selected ion m/z
Z_ACCESSION = "MS:1000041"  # charge state

# RFC 2606 reserves example.com for exactly this. The library's own docs use
# the same placeholder host, and to_fragment() writes the `#` separator.
VIEWER = "viewer.example/#"

# DejaVu Sans Mono advance width, in em. Monospace is what lets the URL be
# placed as two differently coloured runs without measuring glyphs: the token
# starts exactly len(VIEWER) advances after the prefix.
MONO_ADV = 0.602

BAR_X, BAR_W = 0.035, 0.93
BAR_Y, BAR_H = 0.805, 0.15
URL_PT = 6
URL_X = 0.10  # text start, clear of the padlock
URL_RIGHT = 0.955

CHIP_Y, CHIP_H, CHIP_GAP = 0.035, 0.225, 0.018


def draw_padlock(fig, cx, cy, height):
    """A padlock glyph, drawn rather than typed: DejaVu has no lock codepoint."""
    body_w, body_h = height * 0.62 * H / W, height * 0.52
    fig.patches.append(Rectangle(
        (cx - body_w / 2, cy - body_h / 2), body_w, body_h,
        transform=fig.transFigure, facecolor=MUTED, edgecolor="none", zorder=5))
    fig.patches.append(Arc(
        (cx, cy + body_h / 2), body_w * 0.62, height * 0.5, theta1=0,
        theta2=180, transform=fig.transFigure, edgecolor=MUTED, lw=0.9,
        zorder=5))


def draw_address_bar(fig, token):
    fig.patches.append(FancyBboxPatch(
        (BAR_X, BAR_Y), BAR_W, BAR_H,
        boxstyle="round,pad=0,rounding_size=0.05", transform=fig.transFigure,
        facecolor=BAR, edgecolor=EDGE, lw=0.7))
    cy = BAR_Y + BAR_H / 2
    draw_padlock(fig, 0.072, cy, BAR_H * 0.52)

    char_w = MONO_ADV * URL_PT / 72.0 / W
    fig.text(URL_X, cy, VIEWER, fontsize=URL_PT, family="monospace",
             color=FAINT, ha="left", va="center")
    # The token is the part that matters, so it carries the ink. The viewer
    # host recedes. Truncated to whatever the bar holds, as a browser would.
    token_x = URL_X + len(VIEWER) * char_w
    room = int((URL_RIGHT - token_x) / char_w) - 1
    fig.text(token_x, cy, token[:room] + "…", fontsize=URL_PT,
             family="monospace", color=INK, ha="left", va="center")


def precursor_of(token):
    """(m/z, charge) as the token itself carries them, or None.

    Read back out of the token rather than off the source spectrum, so the
    annotation can only say what a decoder would actually recover.
    """
    doc = decode_token(token)
    for prec in doc.precursors:
        for ion in prec.selected_ions:
            params = {cv.accession: cv.value for cv in ion.params}
            if MZ_ACCESSION in params:
                return float(params[MZ_ACCESSION]), params.get(Z_ACCESSION)
    return None


def draw_spectrum(fig, mz, intensity, precursor):
    ax = fig.add_axes([0.045, 0.345, 0.91, 0.40])
    intensity = np.asarray(intensity, dtype=float)
    rel = intensity / intensity.max()

    # Peaks are shaded by height as well as drawn by it. The encoding is
    # redundant, deliberately: at this size the low-intensity forest is a
    # third of a millimetre tall, and shading is what keeps it reading as
    # texture under the tall ions rather than as a smear along the axis.
    ax.vlines(mz, 0, rel, colors=PEAK_CMAP(0.30 + 0.70 * rel), lw=0.7)

    lo, hi = float(np.min(mz)), float(np.max(mz))
    pad = 0.03 * (hi - lo)
    ax.set_xlim(lo - pad, hi + pad)
    ax.set_ylim(0, 1.12)

    if precursor is not None:
        prec_mz, charge = precursor
        ax.axvline(prec_mz, ymax=0.80, color=EDGE, lw=0.6, ls=(0, (2, 1.6)),
                   zorder=1)
        label = f"precursor {prec_mz:.2f}"
        if charge is not None:
            label += f" ({int(charge)}+)"
        ax.text(prec_mz, 0.90, label, fontsize=6, color=MUTED, ha="center",
                va="center", transform=ax.get_xaxis_transform())

    # Enough ticks to place the axis, few enough that 6 pt labels do not run
    # into each other at 3.25 in wide. Any tick landing in the right margin is
    # dropped: "m/z" is right-aligned on this same row for want of a second
    # line, and a tick label there overprints it.
    x0, x1 = ax.get_xlim()
    ticks = [t for t in MaxNLocator(4).tick_values(lo, hi)
             if x0 < t < x0 + 0.88 * (x1 - x0)]
    ax.set_xticks(ticks)
    ax.set_yticks([])
    ax.tick_params(axis="x", labelsize=6, colors=MUTED, length=1.4,
                   width=0.5, pad=1.2)
    for side in ("top", "right", "left"):
        ax.spines[side].set_visible(False)
    ax.spines["bottom"].set_color(EDGE)
    ax.spines["bottom"].set_linewidth(0.6)
    # Sits on the tick-label row, right-aligned, rather than centred under it:
    # a second line below the ticks would collide with the chips.
    fig.text(URL_RIGHT, 0.310, "m/z", fontsize=6, color=MUTED, ha="right",
             va="center")


def draw_chips(fig, chips):
    """A row of equal-width chips: a headline figure over what it measures."""
    width = (BAR_W - CHIP_GAP * (len(chips) - 1)) / len(chips)
    for i, (value, label) in enumerate(chips):
        x = BAR_X + i * (width + CHIP_GAP)
        fig.patches.append(FancyBboxPatch(
            (x, CHIP_Y), width, CHIP_H,
            boxstyle="round,pad=0,rounding_size=0.04",
            transform=fig.transFigure, facecolor=BAR, edgecolor=EDGE, lw=0.6))
        cx = x + width / 2
        fig.text(cx, CHIP_Y + CHIP_H * 0.63, value, fontsize=7, color=BLUE,
                 ha="center", va="center")
        fig.text(cx, CHIP_Y + CHIP_H * 0.24, label, fontsize=6, color=MUTED,
                 ha="center", va="center")


def main() -> int:
    mz, intensity, token, _ = median_ms2()

    fig = plt.figure(figsize=(W, H), dpi=600)
    fig.patch.set_facecolor("white")

    draw_address_bar(fig, token)
    # "resolves to", drawn so the two halves read as one statement. The head is
    # kept short relative to the shaft: at this scale the gap between the bar
    # and the plot is only a few points, and a default head fills all of it and
    # reads as a blob.
    fig.patches.append(FancyArrowPatch(
        (0.5, 0.797), (0.5, 0.752), transform=fig.transFigure,
        arrowstyle="-|>,head_width=1.0,head_length=1.6", color=FAINT, lw=0.8,
        shrinkA=0, shrinkB=0))
    draw_spectrum(fig, mz, intensity, precursor_of(token))
    draw_chips(fig, [
        ("one spectrum", "portable text"),
        ("Python + JS", "shared format"),
        ("local decoding", "no backend"),
    ])

    OUT.parent.mkdir(exist_ok=True)
    fig.savefig(OUT, facecolor="white", metadata={"Software": None})
    plt.close(fig)

    record("fig.toc", str(OUT.relative_to(PAPER)), kind="figure",
           inputs=[MZML_INPUT],
           desc="TOC graphic: a real spectrl token in a browser address bar, "
                "the complete MS2 spectrum it resolves to, and a coverage "
                "summary")
    print(f"wrote {OUT.relative_to(PAPER)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
