"""Plot size versus actual reconstruction error for the fixed budget experiment."""

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from _assets import record
from _study_results import PAPER, REPORT, load, selected


def main():
    report = load()
    fig, axes = plt.subplots(2, 2, figsize=(6.8, 5.2), dpi=320)
    colors = {"psi": "#64748b", "extended": "#2563eb"}
    names = {"psi": "Tuned PSI pool", "extended": "PSI + quantizers"}
    for pool in colors:
        style = "s--" if pool == "psi" else "o-"
        for ax, role, key, scale in [
            (axes[0, 0], "mz", "max_abs", 1),
            (axes[0, 1], "intensity", "max_base_peak_fraction", 100),
        ]:
            values = [selected(report, i, pool, role) for i in range(len(report["budgets"]))]
            x = [max(v["errors"][key] for v in group) * scale for group in values]
            y = [sum(v["blob_bytes"] for v in group) / 2**20 for group in values]
            ax.plot(x, y, style, color=colors[pool], label=names[pool], markersize=5)
            ax.set_xscale("log")
        x = list(range(len(report["budgets"])))
        y = [sum(r["lossy"][i][pool + "_token_chars"] for r in report["spectra"]) / 2**20 for i in x]
        axes[1, 0].plot(x, y, style, color=colors[pool], label=names[pool])
        groups = [selected(report, i, pool, "intensity") for i in x]
        zeros = [
            100 * sum(v["errors"]["positive_to_zero"] for v in g) / sum(v["errors"]["positive_count"] for v in g)
            for g in groups
        ]
        axes[1, 1].plot(x, zeros, style, color=colors[pool], label=names[pool])
    axes[0, 0].set(title="A  m/z arrays", xlabel="Maximum observed error (Da)", ylabel="Total payload (MiB)")
    axes[0, 1].set(
        title="B  Intensity arrays", xlabel="Maximum observed error (% base peak)", ylabel="Total payload (MiB)"
    )
    axes[1, 0].set(title="C  Complete tokens", ylabel="Total text (Mi characters)")
    axes[1, 1].set(title="D  Weak intensity rounding", ylabel="Positive values reconstructed as zero (%)")
    labels = [f"{m:.0e} Da\n{100 * i:g}%" for m, i in report["budgets"]]
    for ax in axes[1]:
        ax.set_xticks(range(len(labels)), labels)
        ax.set_xlabel("Allowed m/z / intensity error (% base peak)")
    for ax in axes.flat:
        ax.spines[["top", "right"]].set_visible(False)
        ax.grid(alpha=0.15)
        ax.tick_params(labelsize=7)
        ax.xaxis.label.set_size(8)
        ax.yaxis.label.set_size(8)
        ax.title.set_size(10)
    handles, labels = axes[0, 0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="lower center", ncol=2, frameon=False, fontsize=8)
    fig.tight_layout(rect=(0, 0.07, 1, 1))
    out = PAPER / "figures/lossy_study.png"
    fig.savefig(out, metadata={"Software": None}, facecolor="white")
    plt.close(fig)
    record(
        "fig.lossy_study",
        str(out.relative_to(PAPER)),
        kind="figure",
        inputs=[str(REPORT.relative_to(PAPER)), *report["inputs"]],
        desc="Controlled error budgets, payload and complete token sizes, and weak-intensity rounding",
    )


if __name__ == "__main__":
    main()
