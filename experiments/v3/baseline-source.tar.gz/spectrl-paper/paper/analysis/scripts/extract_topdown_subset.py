"""Select identified top-down CID spectra from the TopPIC tutorial mzML files.

Usage: uv run python scripts/extract_topdown_subset.py SOURCE IDENTIFICATIONS OUTPUT
The published TopPIC report supplies identification evidence only. Spectrum XML
and binary arrays are copied from the centroided mzML without deconvolution.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import xml.etree.ElementTree as ET
from pathlib import Path

from extract_public_subset import select
from rebuild_subset import NS, digest, extract


def identified_proteins(report: Path, source_stem: str) -> dict[str, dict]:
    lines = report.read_text().splitlines()
    start = next(i for i, line in enumerate(lines) if line.startswith("Data file name\t"))
    eligible = {}
    for row in csv.DictReader(lines[start:], delimiter="\t"):
        if row["Data file name"].replace("\\", "/").split("/")[-1] != f"{source_stem}_ms2.msalign":
            raise ValueError("Identification report does not match the source file")
        first, last = int(row["First residue"]), int(row["Last residue"])
        sequence = row["Database protein sequence"]
        complete = first == 1 or (first == 2 and sequence.startswith("M"))
        q_values = [float(row[name]) for name in ("Spectrum-level Q-value", "Proteoform-level Q-value")]
        if not complete or last != len(sequence) or row["Fragmentation"] != "CID":
            continue
        if not all(math.isfinite(q) and 0 <= q <= 0.01 for q in q_values):
            continue
        scan = row["Scan(s)"]
        if not scan.isdecimal():
            raise ValueError("Expected one native scan per identification")
        native_id = f"controllerType=0 controllerNumber=1 scan={scan}"
        if native_id in eligible:
            raise ValueError(f"Duplicate identification for {native_id}")
        eligible[native_id] = {
            "prsm_id": int(row["Prsm ID"]),
            "protein_accession": row["Protein accession"],
            "protein_description": row["Protein description"],
            "first_residue": first,
            "last_residue": last,
            "database_sequence_length": len(sequence),
            "precursor_mass_da": float(row["Precursor mass"]),
            "reported_charge": int(row["Charge"]),
            "spectrum_q_value": q_values[0],
            "proteoform_q_value": q_values[1],
        }
    if not eligible:
        raise ValueError("No qualifying full-length protein identifications")
    return eligible


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("identifications", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--per-level", type=int, default=6)
    args = parser.parse_args()
    if args.per_level < 1:
        parser.error("--per-level must be positive")
    eligible = identified_proteins(args.identifications, args.source.stem)
    ids, counts = select(args.source, args.per_level, {2}, set(eligible))
    extract(args.source, ids, args.output)
    evidence = {}
    for spectrum in ET.parse(args.output).iter(NS + "spectrum"):
        native_id = spectrum.get("id")
        if native_id not in eligible:
            continue
        params = {p.get("accession"): p.get("value") for p in spectrum.findall(NS + "cvParam")}
        activation = {p.get("accession") for p in spectrum.findall(".//" + NS + "activation/" + NS + "cvParam")}
        if params.get("MS:1000511") != "2" or "MS:1000127" not in params or "MS:1000133" not in activation:
            raise ValueError(f"Expected centroid CID MS2 spectrum: {native_id}")
        evidence[native_id] = {"n_peaks": int(spectrum.get("defaultArrayLength")), **eligible[native_id]}
    if len(evidence) != min(args.per_level, len(eligible)):
        raise ValueError("Selected spectrum count does not match the identified candidate pool")
    record = {
        "mzml_sha256": digest(args.source),
        "subset_sha256": digest(args.output),
        "identifications_sha256": digest(args.identifications),
        "source_nonempty_spectra_by_ms_level": counts,
        "eligible_identified_ms2": len(eligible),
        "selected_ids": ids,
        "selected_ms_levels": [2],
        "per_level": args.per_level,
        "selection": "Evenly spaced point-count quantiles among CID MS2 scans identified as full-length proteins or initiator-methionine-excised proteins, with both reported Q-values at most 0.01. Ties follow source order. Referenced precursor scans are retained.",
        "identifications": evidence,
    }
    args.output.with_suffix(".selection.json").write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps(record, indent=2))


if __name__ == "__main__":
    main()
