"""Matched containers, all supported PSI codecs, bounded loss, and outer compressors."""

import copy
import gzip
import hashlib
import io
import json
import os
import platform
import warnings
import zlib
from collections import Counter
from contextlib import redirect_stdout
from dataclasses import fields, is_dataclass
from datetime import UTC, datetime
from pathlib import Path

import brotli
import cbor2
import numpy as np
import zstandard
from _datasets import _assert_metadata_equal, encode_all, inputs
from _mzml_baseline import matched_source, mzml_element, mzml_token
from _study_codecs import (
    BUDGETS,
    PSI_ALL,
    PSI_LOSSLESS,
    QUANT_INT,
    QUANT_MZ,
    REPEATS,
    candidate,
    numpress_descriptor,
    timings,
    tuned_candidates,
)

from spectrl import decode_token, encode_spectrum
from spectrl.cbor_format import frame_payload, read_token_document
from spectrl.model import SpectrlUserParam
from spectrl.peaks import canonical_sort
from spectrl.token import b64url_encode

PAPER = Path(__file__).resolve().parents[2]
REPORT = PAPER / "analysis/reports/encoding-study.json"
STANDARDS = ["analysis/data/standards/mzML1.1.0.xsd", "analysis/data/standards/psi-ms.obo"]
OUTER = [
    ("zlib-6", lambda b: zlib.compress(b, 6), zlib.decompress),
    ("zlib-9", lambda b: zlib.compress(b, 9), zlib.decompress),
    (
        "zstd-3",
        lambda b: zstandard.ZstdCompressor(level=3).compress(b),
        lambda b: zstandard.ZstdDecompressor().decompress(b),
    ),
    (
        "zstd-9",
        lambda b: zstandard.ZstdCompressor(level=9).compress(b),
        lambda b: zstandard.ZstdDecompressor().decompress(b),
    ),
    ("brotli-5", lambda b: brotli.compress(b, quality=5), brotli.decompress),
    ("brotli-9", lambda b: brotli.compress(b, quality=9), brotli.decompress),
]


def encode(source, **kwargs):
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        return encode_spectrum(source, **kwargs)


def assemble(doc, selections):
    out = copy.deepcopy(doc)
    for desc in out[6]:
        key = {1000514: "mz", 1000515: "intensity", 1000516: "charge"}.get(desc[1], desc.get(4, f"MS:{desc[1]:07d}"))
        item, blob = selections[key]
        desc.update({0: item["dtype"], 2: item["encoding"], 3: item["compression"], 5: blob, 7: item["fidelity"]})
    return frame_payload(cbor2.dumps(out, canonical=True))


def metadata_counts(source):
    counts = Counter()

    def walk(value):
        if is_dataclass(value):
            if isinstance(value, SpectrlUserParam):
                counts["free-text parameters"] += 1
            for field in fields(value):
                walk(getattr(value, field.name))
        elif isinstance(value, dict):
            if "software" in value:
                counts["software records"] += 1
                counts["software parameters"] += len(value["software"].get("params", [])) + len(
                    value["software"].get("user_params", [])
                )
            if "components" in value:
                counts["instrument components"] += len(value["components"])
            for child in value.values():
                walk(child)
        elif isinstance(value, list):
            for child in value:
                walk(child)

    walk(source)
    counts.update(
        {
            "source context": int(bool(source.source)),
            "acquisition context": int(bool(source.acquisition)),
            "processing steps": len(source.processing),
            "array processing steps": sum(map(len, source.array_processing.values())),
            "array parameters": sum(map(len, source.array_params.values()))
            + sum(map(len, source.array_user_params.values())),
            "scan records": len(source.scans),
            "precursor records": len(source.precursors),
            "external spectrum references": sum(
                bool(v.source and v.source.get("spectrum_ref")) for v in [*source.scans, *source.precursors]
            ),
        }
    )
    return dict(counts)


def outer_measure(raw):
    results = {}
    for label, compress, decompress in OUTER:
        packed = compress(raw)
        if decompress(packed) != raw:
            raise AssertionError("outer compressor changed the payload")
        results[label] = {
            "bytes": len(packed),
            "framed_chars": 22 + len(b64url_encode(packed)),
            "encode_ms": timings(lambda compress=compress: compress(raw)),
            "decode_ms": timings(lambda decompress=decompress, packed=packed: decompress(packed)),
        }
    return results


def main():
    with redirect_stdout(io.StringIO()):
        rows = encode_all()
    records = []
    for index, row in enumerate(rows):
        source = canonical_sort(matched_source(row))
        values = [
            (key, getattr(source, key)) for key in ("mz", "intensity", "charge") if getattr(source, key) is not None
        ]
        values += sorted(source.extra_arrays.items())
        base = encode(source, lossless=True, array_encodings={key: "zlib" for key, _ in values})
        doc, _ = read_token_document(base)
        choices, array_records = {}, []
        for role, data in values:
            available, measured = {}, {}
            pipelines = PSI_ALL if role in ("mz", "intensity") else PSI_LOSSLESS
            for label, eid, cid in pipelines:
                try:
                    enc = numpress_descriptor(eid, data) if eid in (4, 5, 6) else [eid, 1]
                    item, blob = candidate(data, role, enc, [cid, 1], timed=True)
                    available[label] = (item, blob)
                    measured[label] = {"eligible": True, **item}
                except ValueError as exc:
                    measured[label] = {"eligible": False, "reason": str(exc)}
            choices[role] = available
            array_records.append(
                {
                    "role": role,
                    "dtype": data.dtype.name,
                    "count": len(data),
                    "raw_bytes": data.nbytes,
                    "pipelines": measured,
                }
            )
        exact_choices = {
            key: min((a[label] for label, _, _ in PSI_LOSSLESS), key=lambda x: x[0]["descriptor_bytes"])
            for key, a in choices.items()
        }
        psi_token = assemble(doc, exact_choices)
        _assert_metadata_equal(source, decode_token(psi_token))
        compact = encode(source)
        containers = {}
        for label, token in [("raw-zlib", base), ("psi-lossless", psi_token), ("numpress-default", compact)]:
            xml = mzml_element(token).encode()
            containers[label] = {
                "spectrl_chars": len(token),
                "mzml_bytes": len(xml),
                "mzml_gzip_bytes": len(gzip.compress(xml, compresslevel=9, mtime=0)),
                "mzml_framed_chars": len(mzml_token(xml.decode())),
                "schema_valid": True,
            }
        lossy = []
        for mz_error, intensity_fraction in BUDGETS:
            standard, extended, role_results = dict(exact_choices), dict(exact_choices), {}
            for role, data in values:
                if role not in ("mz", "intensity"):
                    continue
                bound = mz_error if role == "mz" else intensity_fraction * float(np.max(np.abs(data), initial=0))
                if bound <= 0:
                    pool = [exact_choices[role]]
                else:
                    allowed = {0, 1, 2, 4} if role == "mz" else {0, 1, 2, 4, 5, 6}
                    defaults = [
                        value
                        for value in choices[role].values()
                        if value[0]["encoding"][0] in allowed and value[0]["errors"]["max_abs"] <= bound
                    ]
                    pool = [exact_choices[role], *defaults, *tuned_candidates(data, role, bound)]
                standard[role] = min(pool, key=lambda x: x[0]["descriptor_bytes"])
                custom = []
                if bound > 0:
                    enc = [QUANT_MZ if role == "mz" else QUANT_INT, 1, {"step": 2 * bound}]
                    for cid in (1, 2):
                        try:
                            item, blob = candidate(data, role, enc, [cid, 1])
                        except ValueError:
                            continue
                        if item["errors"]["max_abs"] <= bound:
                            custom.append((item, blob))
                extended[role] = min([standard[role], *custom], key=lambda x: x[0]["descriptor_bytes"])
                role_results[role] = {
                    "bound": bound,
                    "psi": standard[role][0],
                    "extended": extended[role][0],
                    "custom_eligible": bool(custom),
                }
            token_psi, token_extended = assemble(doc, standard), assemble(doc, extended)
            for token in (token_psi, token_extended):
                decoded = decode_token(token)
                _assert_metadata_equal(source, decoded, lossy=True)
                for role, data in values:
                    recovered = (
                        getattr(decoded, role) if role in ("mz", "intensity", "charge") else decoded.extra_arrays[role]
                    )
                    if len(recovered) != len(data):
                        raise AssertionError("complete token changed array length")
                    if role in role_results:
                        maximum = float(np.max(np.abs(data.astype("float64") - recovered), initial=0))
                        if maximum > role_results[role]["bound"]:
                            raise AssertionError("complete token exceeded the error bound")
                    elif recovered.dtype != data.dtype or recovered.tobytes() != data.tobytes():
                        raise AssertionError("complete token changed an auxiliary array")
            lossy.append(
                {
                    "mz_bound_da": mz_error,
                    "intensity_bound_fraction": intensity_fraction,
                    "psi_token_chars": len(token_psi),
                    "extended_token_chars": len(token_extended),
                    "arrays": role_results,
                }
            )
        outer = {}
        for label, token in [("lossless", psi_token), ("lossy", compact)]:
            rawdoc, _ = read_token_document(token)
            xml = mzml_element(token).encode()
            outer[label] = {"cbor": outer_measure(cbor2.dumps(rawdoc, canonical=True)), "xml": outer_measure(xml)}
        records.append(
            {
                "dataset": row.dataset.key,
                "id": row.spectrum_id,
                "representation": row.representation,
                "points": row.n_peaks,
                "metadata": metadata_counts(source),
                "arrays": array_records,
                "containers": containers,
                "lossy": lossy,
                "outer": outer,
            }
        )
        if index % 10 == 0:
            print(f"{index + 1}/{len(rows)} spectra complete", flush=True)
    paths = [PAPER / p for p in [*inputs(), *STANDARDS, "analysis/uv.lock", "analysis/pyproject.toml"]]
    paths += list((PAPER.parent / "src/spectrl").rglob("*.py"))
    paths += [
        Path(__file__),
        *[
            PAPER / "analysis/scripts" / p
            for p in ["_study_codecs.py", "_datasets.py", "_mzml_baseline.py", "_spectral_similarity.py"]
        ],
    ]
    report = {
        "measured_at": datetime.now(UTC).isoformat(),
        "repeats": REPEATS,
        "warmups": 1,
        "environment": {
            "python": platform.python_version(),
            "platform": platform.platform(),
            "brotli": brotli.__version__,
            "zstandard": zstandard.__version__,
            "zlib": zlib.ZLIB_RUNTIME_VERSION,
        },
        "budgets": BUDGETS,
        "spectra": records,
        "inputs": {os.path.relpath(p, PAPER): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(set(paths))},
    }
    REPORT.write_text(json.dumps(report, indent=2) + "\n")
    print(f"Wrote {REPORT}", flush=True)


if __name__ == "__main__":
    main()
