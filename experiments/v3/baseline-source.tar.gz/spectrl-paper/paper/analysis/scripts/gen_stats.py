#!/usr/bin/env python3
"""Write corpus counts used by the manuscript, gated on cross-language decoding."""

from __future__ import annotations

import math
import statistics
from pathlib import Path

from spectrl.codecs.numpress import DEFAULT_NUMSLOF_FP

from _datasets import DATASETS, encode_all, inputs
from _coverage import sampling_target, validate_coverage
from _fidelity import validate_all
from _interop import assert_cross_language
from _sizes import measure_sizes
from _spectral_similarity import add_stats, analyze
from _stats import Stats
from _codec_results import add_stats as add_compression_stats
from _study_results import add_stats as add_study_stats

HERE = Path(__file__).resolve().parent
PAPER = HERE.parent.parent
REPO = PAPER.parent


def main() -> int:
    rows = encode_all()
    categories, modalities = validate_coverage(rows)
    n_tokens_ts, n_tokens_py = assert_cross_language(rows)
    stats = Stats()
    add_compression_stats(stats)
    add_study_stats(stats)
    add_stats(stats, analyze(rows))
    stats.add(
        "accuracy.intensity_zero_threshold",
        math.expm1(0.5 / DEFAULT_NUMSLOF_FP),
        fmt=".7f",
        desc="Source intensity threshold below which SLOF rounds to zero at the default fixed point",
        sign="+",
    )
    stats.add("corpus.n_categories", len(categories), fmt=",", desc="Reported representation, MS level, and acquisition groups", sign="+")
    stats.add("corpus.n_sparse_categories", sum(len(group) < sampling_target() for group in categories.values()),
              fmt=",", desc="Reported spectrum categories below the three-spectrum target", sign="+")
    full = validate_all()
    stats.add("fidelity.n_spectra", sum(row.n_spectra for row in full.values()),
              fmt=",", desc="Every spectrum in the benchmark input mzML files validated in both modes", sign="+")
    stats.add("fidelity.n_peaks", sum(row.n_peaks for row in full.values()),
              fmt=",", desc="Total peaks in the complete source-file fidelity validation", sign="+")
    stats.add("fidelity.n_empty", sum(row.n_empty for row in full.values()),
              fmt=",", desc="Empty spectra included in complete source-file fidelity validation", sign="+")
    for dataset in DATASETS:
        stats.add(f"fidelity.{dataset.key}.n_spectra", full[dataset.key].n_spectra,
                  fmt=",", desc=f"All source spectra validated in {dataset.label}", sign="+")
    stats.add("fidelity.mz_abs_error_max", max(row.mz_abs_error_max for row in full.values()),
              fmt=".2e", unit=" Da", desc="Maximum default-mode absolute m/z error across all source spectra", sign="+")
    stats.add("fidelity.intensity_norm_error_max_pct",
              100 * max(row.intensity_norm_error_max for row in full.values()), fmt=".3f", unit="%",
              desc="Maximum default-mode intensity error relative to the base peak across all source spectra", sign="+")
    stats.add("fidelity.intensity_relative_error_max_pct",
              100 * max(row.intensity_relative_error_max for row in full.values()), fmt=".3f", unit="%",
              desc="Maximum default-mode absolute intensity error divided by the nonzero source intensity across all peaks", sign="+")
    stats.add("corpus.n_datasets", len(DATASETS), fmt=",", desc="Public mzML files in the benchmark corpus", sign="+")
    stats.add(
        "corpus.n_spectra", len(rows), fmt=",", desc="Representative real spectra encoded in both modes", sign="+"
    )
    stats.add("corpus.n_topdown_ms2", len(modalities["Top-down MS2"]), fmt=",",
              desc="Experimental top-down CID and ETD MS2 spectra with published protein identifications, excluding MS1 parents",
              sign="+")
    stats.add(
        "corpus.n_points_max", max(row.n_peaks for row in rows), fmt=",",
        desc="Maximum point count among the selected corpus spectra", sign="+",
    )
    stats.add("corpus.n_tokens_ts", n_tokens_ts, fmt=",", desc="Python corpus tokens decoded by TypeScript", sign="+")
    stats.add("corpus.n_tokens_py", n_tokens_py, fmt=",", desc="TypeScript corpus tokens decoded by Python", sign="+")
    stats.add(
        "corpus.n_ms3", sum(row.ms_level == 3 for row in rows), fmt=",", desc="Real MS3 spectra in the corpus", sign="+"
    )
    stats.add(
        "corpus.n_profile",
        sum(row.representation == "profile" for row in rows),
        fmt=",",
        desc="Real profile spectra in the corpus",
        sign="+",
    )
    stats.add(
        "corpus.n_mobility",
        sum(row.ion_mobility != "none" for row in rows),
        fmt=",",
        desc="Real spectra carrying ion-mobility metadata",
        sign="+",
    )
    stats.add(
        "accuracy.mz_abs_error_max",
        max(row.mz_abs_error_max for row in rows),
        fmt=".2e",
        unit=" Da",
        desc="Maximum absolute m/z reconstruction error in default mode",
        sign="+",
    )
    stats.add(
        "accuracy.intensity_norm_error_max_pct",
        100 * max(row.intensity_norm_error_max for row in rows),
        fmt=".3f",
        unit="%",
        desc="Maximum default-mode intensity error normalized to the source spectrum base peak",
        sign="+",
    )

    # Reported as positive savings because the prose says "smaller"; the sign
    # guards then fail the build if a re-run ever reverses the direction.
    sizes = measure_sizes(rows)
    stats.add("size.n_smaller_gzip", sum(row.framed_saving_pct > 0 for row in sizes), fmt=",",
              desc="Selected raw-zlib spectrl tokens smaller than information-matched framed gzip mzML", sign="+")
    stats.add("size.n_larger_gzip", sum(row.framed_saving_pct < 0 for row in sizes), fmt=",",
              desc="Selected spectrl tokens with raw-zlib arrays and automatic outer compression larger than framed gzip mzML", between=(0, len(rows)))
    dda_ms2 = {id(row) for row in categories["Centroid MS2, DDA"]}
    stats.add(
        "size.centroid_dda_ms2_gz_median_saving_pct",
        statistics.median(row.framed_saving_pct for row in sizes if id(row.spectrum) in dda_ms2),
        fmt=".1f",
        unit="%",
        desc="Median per-spectrum percentage reduction for the selected centroid DDA MS2 category "
        "against codec- and information-matched mzML after gzip and equivalent token framing",
        sign="+",
    )
    stats.add("size.mzml_gz_min_saving_pct", min(row.framed_saving_pct for row in sizes),
              fmt=".2f", unit="%", desc="Minimum per-spectrum reduction against transport-matched XML", between=(-1000, 100))
    stats.add(
        "size.mzml_gz_median_saving_pct",
        statistics.median(row.framed_saving_pct for row in sizes),
        fmt=".0f",
        unit="%",
        desc="Median per-spectrum percentage reduction against the same "
        "raw-zlib matched mzML document after gzip and base64url in the "
        "same versioned, checksummed token framing",
        sign="+",
    )
    return stats.write(
        inputs=[
            *inputs(),
            "analysis/reports/compression-v3.json",
            "analysis/reports/encoding-study.json",
            "analysis/data/standards/mzML1.1.0.xsd",
            "analysis/data/standards/psi-ms.obo",
            "../test-vectors/reverse-vectors.json",
            "analysis/scripts/validate_tokens.mjs",
            "../js/package-lock.json",
            *["../" + path.relative_to(REPO).as_posix() for path in sorted((REPO / "src/spectrl").rglob("*.py"))],
            *["../" + path.relative_to(REPO).as_posix() for path in sorted((REPO / "js/dist").glob("*.js"))],
        ]
    )


if __name__ == "__main__":
    raise SystemExit(main())
