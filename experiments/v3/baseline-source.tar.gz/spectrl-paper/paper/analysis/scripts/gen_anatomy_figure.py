#!/usr/bin/env python3
"""Write ../../figures/token_anatomy.png: where a token's bytes go.

Three nested levels of a real, typical MS2 token from the test data: the
five dot-separated text parts (identifier, version, mode, payload, checksum).
the decoded CBOR payload split by top-level header entry, with the two
compressed array blobs. It also shows a zoom into the header-metadata prefix (peak
count, spectrum id, CV params, scan, precursor). Every byte span is measured
from the token itself, so the figure cannot drift from the wire format.
"""

from __future__ import annotations

from pathlib import Path

import matplotlib

from _assets import record
from _bsa import MZML_INPUT, median_ms2

from spectrl.cbor_format import read_token_payload

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.patches import Polygon  # noqa: E402

HERE = Path(__file__).resolve().parent
PAPER = HERE.parent.parent
OUT = PAPER / "figures" / "token_anatomy.png"

INK = "#1e293b"
MUTED = "#64748b"
EDGE = "#cbd5e1"
ZOOM = "#f1f5f9"

KEY_NAMES = {
    0: "peak count", 1: "spectrum id", 2: "spectrum params", 3: "scan",
    4: "precursor", 5: "products", 7: "user params",
    8: "source", 9: "acquisition", 10: "processing", 11: "extensions",
}
ARRAY_NAMES = {1000514: "m/z", 1000515: "intensity", 1000516: "charge"}
ARRAY_COLORS = {"m/z": "#2563eb", "intensity": "#7ea6f5"}
META_COLORS = ["#94a3b8", "#a8b6c8", "#8898ab", "#b6c2d1", "#7d8fa5", "#c3cdd9"]

BAR_H = 0.34
ROW_Y = {"token": 3.3, "payload": 1.65, "meta": 0.0}


def _item_end(buf: bytes, i: int) -> int:
    """End offset of the definite-length CBOR item starting at buf[i]."""
    ib = buf[i]
    major, ai = ib >> 5, ib & 0x1F
    if ai < 24:
        arg, head = ai, 1
    elif ai == 24:
        arg, head = buf[i + 1], 2
    elif ai == 25:
        arg, head = int.from_bytes(buf[i + 1:i + 3], "big"), 3
    elif ai == 26:
        arg, head = int.from_bytes(buf[i + 1:i + 5], "big"), 5
    elif ai == 27:
        arg, head = int.from_bytes(buf[i + 1:i + 9], "big"), 9
    else:
        raise ValueError("indefinite-length item in deterministic CBOR")
    if major in (0, 1):
        return i + head
    if major in (2, 3):
        return i + head + arg
    if major == 4:
        j = i + head
        for _ in range(arg):
            j = _item_end(buf, j)
        return j
    if major == 5:
        j = i + head
        for _ in range(2 * arg):
            j = _item_end(buf, j)
        return j
    if major == 6:
        return _item_end(buf, i + head)
    return i + {24: 2, 25: 3, 26: 5, 27: 9}.get(ai, 1)


def _entries(buf: bytes) -> list[tuple[int, int, int]]:
    """(key, start, end) for each top-level map entry, in wire order."""
    if buf[0] >> 5 != 5:
        raise ValueError("payload is not a CBOR map")
    out, i = [], 1
    for _ in range(buf[0] & 0x1F):
        key_end = _item_end(buf, i)
        key = buf[i] if buf[i] < 24 else int.from_bytes(buf[i + 1:key_end], "big")
        val_end = _item_end(buf, key_end)
        out.append((key, i, val_end))
        i = val_end
    return out


def _array_segments(buf: bytes, start: int, end: int) -> list[tuple[str, int, str]]:
    """Split the array-list entry into (label, size, color) per descriptor,
    separating descriptor overhead from each embedded blob."""
    j = _item_end(buf, start)          # skip the key item
    ib = buf[j]
    head = {0: 1, 24: 2, 25: 3}.get(ib & 0x1F if (ib & 0x1F) >= 24 else 0, 1)
    n = ib & 0x1F if (ib & 0x1F) < 24 else buf[j + 1]
    segments: list[tuple[str, int, str]] = []
    pos = j + head
    lead = (pos - start)               # key + list framing, folded into first desc
    for _ in range(n):
        desc_end = _item_end(buf, pos)
        # walk the descriptor map to find key 1 (array tail) and key 5 (blob)
        tail, blob = None, 0
        k = pos + 1
        for _ in range(buf[pos] & 0x1F):
            k_end = _item_end(buf, k)
            dkey = buf[k]
            v_end = _item_end(buf, k_end)
            if dkey == 1:
                v = buf[k_end] if buf[k_end] < 24 else int.from_bytes(buf[k_end + 1:v_end], "big")
                tail = v
            if dkey == 5:
                blob = v_end - k_end - (5 if (buf[k_end] & 0x1F) == 26 else
                                        3 if (buf[k_end] & 0x1F) == 25 else
                                        2 if (buf[k_end] & 0x1F) == 24 else 1)
            k = v_end
        name = ARRAY_NAMES.get(tail, "array")
        color = ARRAY_COLORS.get(name, "#60a5fa")
        overhead = (desc_end - pos) - blob + lead
        lead = 0
        segments.append((f"{name} desc", overhead, "#475569", "below"))
        segments.append((f"{name} data", blob, color, None))
        pos = desc_end
    return segments


def _draw_row(ax, y, total, segments, unit):
    """One full-width bar. Returns each segment's (frac0, frac1).

    A segment is (name, size, color, side): side ("above"/"below") places the
    leader label used when the segment is too thin for an inline label."""
    spans, left = [], 0
    for name, size, color, side in segments:
        frac0, frac1 = left / total, (left + size) / total
        ax.barh(y, frac1 - frac0, left=frac0, height=BAR_H, color=color,
                edgecolor="white", linewidth=0.8, align="center")
        spans.append((frac0, frac1))
        left += size
    for (name, size, color, side), (frac0, frac1) in zip(segments, spans):
        mid = (frac0 + frac1) / 2
        if frac1 - frac0 >= 0.085:
            lum = int(color[1:3], 16) * 0.3 + int(color[3:5], 16) * 0.6
            ax.text(mid, y, f"{name}\n{size:,} {unit}", ha="center",
                    va="center", fontsize=6.4,
                    color="white" if lum < 150 else INK, linespacing=1.25)
        else:
            above = side == "above"
            ty = y + (BAR_H / 2 + 0.30 if above else -(BAR_H / 2 + 0.30))
            ha = "left" if mid < 0.10 else "right" if mid > 0.90 else "center"
            ax.annotate(f"{name}, {size:,} {unit}",
                        xy=(mid, y + (BAR_H / 2 if above else -BAR_H / 2)),
                        xytext=(mid, ty), ha=ha,
                        va="bottom" if above else "top", fontsize=6.0,
                        color=MUTED,
                        arrowprops=dict(arrowstyle="-", color=EDGE, lw=0.7))
    return spans


def _zoom(ax, upper_y, upper_span, lower_y):
    poly = Polygon(
        [(upper_span[0], upper_y - BAR_H / 2), (upper_span[1], upper_y - BAR_H / 2),
         (1.0, lower_y + BAR_H / 2), (0.0, lower_y + BAR_H / 2)],
        closed=True, facecolor=ZOOM, edgecolor=EDGE, linewidth=0.6, zorder=0)
    ax.add_patch(poly)


def main() -> int:
    mz, _, token, _ = median_ms2()
    identifier, version, mode, payload_txt, checksum_txt = token.split(".")
    buf = read_token_payload(token)
    entries = _entries(buf)

    # Level 1: the token text, in characters.
    token_segments = [
        (f"{identifier}. (identifier)", len(identifier) + 1, "#475569", "below"),
        (f"{version}. (version)", len(version) + 1, "#64748b", "above"),
        (f"{mode}. (payload mode)", len(mode) + 1, "#2563eb", "below"),
        ("base64url(payload)", len(payload_txt), "#e2e8f0", None),
        (f".{checksum_txt} (checksum)", len(checksum_txt) + 1, "#94a3b8", "above"),
    ]

    # Level 2: the payload bytes by top-level entry. Arrays split out.
    payload_segments: list[tuple[str, int, str, str | None]] = []
    meta_segments: list[tuple[str, int, str, str | None]] = []
    meta_bytes = 0
    prev_end = 0
    color_i = 0
    sides = ["below", "above"]
    for key, start, end in entries:
        framing = start - prev_end            # map head before first entry
        prev_end = end
        if key == 6:
            payload_segments.extend(_array_segments(buf, start, end))
        else:
            size = end - start + framing
            meta_bytes += size
            label = KEY_NAMES.get(key, f"key {key}")
            meta_segments.append((label, size, META_COLORS[color_i % len(META_COLORS)],
                                  sides[color_i % 2]))
            color_i += 1

    payload_segments.insert(0, ("metadata", meta_bytes, "#94a3b8", None))
    assert sum(s[1] for s in payload_segments) == len(buf)

    fig, axes = plt.subplots(3, 1, figsize=(7, 5.2), dpi=300,
                             gridspec_kw={"height_ratios": [1, 1, 1.2]})
    rows = [
        (f"Token text: {len(token):,} characters", len(token), token_segments, "chars"),
        (f"Expanded CBOR: {len(buf):,} bytes, before outer compression", len(buf), payload_segments, "B"),
        (f"Metadata detail: {meta_bytes:,} bytes", meta_bytes, meta_segments, "B"),
    ]
    for ax, (title, total, segments, unit) in zip(axes, rows):
        ax.set_xlim(0, 1)
        ax.set_ylim(0, 1)
        ax.axis("off")
        ax.text(0, 1.08, title, weight="bold", fontsize=9, color=INK, transform=ax.transAxes)
        left = 0
        for index, (name, size, color, _) in enumerate(segments):
            width = size / total
            ax.barh(0.82, width, left=left, height=0.22, color=color, edgecolor="white")
            if width > 0.18:
                ax.text(left + width / 2, 0.82, f"{size:,}", ha="center", va="center",
                        fontsize=8, color=INK if color == "#e2e8f0" else "white")
            left += width
            col, row = index % 3, index // 3
            x, y = col / 3, 0.48 - row * 0.22
            ax.plot([x + 0.012], [y], marker="s", color=color, markersize=6)
            name = name.replace("base64url(payload)", "payload")
            ax.text(x + 0.033, y, f"{name}: {size:,} {unit}", va="center", fontsize=6.8, color=INK)
    fig.text(0.5, 0.012, f"Median BSA MS2 token with selected context: {len(mz)} peaks",
             ha="center", fontsize=7, color=MUTED)
    fig.subplots_adjust(left=0.03, right=0.98, top=0.93, bottom=0.09, hspace=0.42)

    OUT.parent.mkdir(exist_ok=True)
    fig.savefig(OUT, metadata={"Software": None}, bbox_inches="tight")
    plt.close(fig)

    record("fig.anatomy", str(OUT.relative_to(PAPER)), kind="figure",
           inputs=[MZML_INPUT],
           desc="Nested byte layout of a median MS2 token: text parts (identifier, "
                "version, mode, payload, checksum), payload entries with array blobs, and the "
                "header-metadata breakdown")
    print(f"wrote {OUT.relative_to(PAPER)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
