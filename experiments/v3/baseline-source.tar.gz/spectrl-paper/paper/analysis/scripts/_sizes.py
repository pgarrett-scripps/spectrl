"""Shared, audited per-spectrum sizes for figures, tables, and prose statistics."""

from dataclasses import dataclass
import gzip

from _datasets import DatasetRow, inputs
from spectrl import encode_spectrum
import warnings
from _mzml_baseline import mzml_element, mzml_token, matched_source


@dataclass(frozen=True)
class SizeRow:
    spectrum: DatasetRow
    token_bytes: int
    xml_bytes: int
    framed_xml_bytes: int
    gzip_xml_bytes: int

    @property
    def xml_saving_pct(self):
        return 100 * (1 - self.token_bytes / self.xml_bytes)

    @property
    def framed_saving_pct(self):
        return 100 * (1 - self.token_bytes / self.framed_xml_bytes)


def measure_sizes(rows):
    measured = []
    for row in rows:
        keys = [k for k in ("mz", "intensity", "charge") if getattr(row.source, k) is not None]
        keys += list(row.source.extra_arrays)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            token = encode_spectrum(matched_source(row), lossless=True, array_encodings=dict.fromkeys(keys, "zlib"))
        xml = mzml_element(token)
        measured.append(SizeRow(
            row, len(token.encode("ascii")),
            len(xml.encode("utf-8")), len(mzml_token(xml).encode("ascii")),
            len(gzip.compress(xml.encode("utf-8"), compresslevel=9, mtime=0)),
        ))
    return measured


POINT_BINS = (
    ("<100", 0, 100),
    ("100-999", 100, 1000),
    ("1,000-9,999", 1000, 10000),
    (">=10,000", 10000, float("inf")),
)


def size_inputs():
    return [*inputs(), 'analysis/data/standards/mzML1.1.0.xsd', 'analysis/data/standards/psi-ms.obo']
