"""Plot corpus composition, matched containers, and category size reductions."""

from collections import Counter
from pathlib import Path
from statistics import median

import matplotlib
import numpy as np

from _assets import record
from _coverage import validate_coverage
from _datasets import encode_all, inputs
from _sizes import measure_sizes, size_inputs
from _study_results import REPORT, load

matplotlib.use("Agg")
import matplotlib.pyplot as plt

PAPER = Path(__file__).resolve().parents[2]
COLORS = {1: "#2563eb", 2: "#ea580c", 3: "#9333ea"}
INK = "#0f172a"
MUTED = "#64748b"


def style(ax):
    ax.spines[["top", "right", "left"]].set_visible(False)
    ax.spines["bottom"].set_color("#cbd5e1")
    ax.tick_params(axis="both", labelsize=8, length=0, colors=INK)
    ax.grid(axis="x", color="#e2e8f0", linewidth=0.6)
    ax.set_axisbelow(True)


def save(fig, name, data, desc):
    path = PAPER / "figures" / f"{name}.png"
    fig.savefig(path, dpi=400, facecolor="white", metadata={"Software": None})
    plt.close(fig)
    record(f"fig.{name}", str(path.relative_to(PAPER)), kind="figure",
           inputs=data, desc=desc)
    print(f"wrote {path.relative_to(PAPER)}")


def composition(rows):
    mobility = {"none": "None", "scalar": "Scalar", "array": "Per-peak array"}
    groups = [
        ("A  Source domain", Counter(r.dataset.domain for r in rows)),
        ("B  Representation", Counter(r.representation.capitalize() for r in rows)),
        ("C  MS level", Counter(f"MS{r.ms_level}" for r in rows)),
        ("D  Mobility", Counter(mobility.get(r.ion_mobility, r.ion_mobility) for r in rows)),
    ]
    fig, axes = plt.subplots(2, 2, figsize=(7.0, 4.8))
    for ax, (title, counts) in zip(axes.flat, groups):
        pairs = sorted(counts.items(), key=lambda pair: -pair[1])
        assert sum(counts.values()) == len(rows)
        labels, values = zip(*pairs)
        y = np.arange(len(labels))
        ax.barh(y, values, height=0.57, color="#2563eb")
        ax.set_yticks(y, labels)
        ax.invert_yaxis()
        ax.set_xlim(0, len(rows) * 1.08)
        for pos, value in zip(y, values):
            ax.text(value + 3, pos, str(value), va="center", fontsize=8, color=INK)
        ax.set_title(title, loc="left", fontsize=10, weight="bold", pad=10)
        ax.set_xlabel("Selected spectra", fontsize=8)
        style(ax)
    fig.subplots_adjust(left=0.25, right=0.97, top=0.92, bottom=0.1,
                        wspace=0.95, hspace=0.65)
    save(fig, "corpus", inputs(), "Selected benchmark composition by domain, representation, MS level, and mobility")


def containers():
    report = load()
    fig, axes = plt.subplots(1, 2, figsize=(7.0, 3.3), sharey=True)
    profiles = ["raw-zlib", "psi-lossless", "numpress-default"]
    for ax, mode in zip(axes, ["centroid", "profile"]):
        rows = [r for r in report["spectra"] if r["representation"] == mode]
        x = np.arange(len(profiles))
        for offset, key, label, color in [
            (-0.19, "spectrl_chars", "spectrl", "#2563eb"),
            (0.19, "mzml_framed_chars", "Framed gzip mzML", "#94a3b8"),
        ]:
            values = [sum(r["containers"][p][key] for r in rows) / 2**20 for p in profiles]
            bars = ax.bar(x + offset, values, width=0.34, label=label, color=color)
            ax.bar_label(bars, labels=[f"{v:.2f}" for v in values], fontsize=7, padding=3)
        ax.set_xticks(x, ["Raw-zlib", "PSI-lossless", "Numpress\ndefault"], fontsize=8)
        ax.set_title(f"{mode.capitalize()} (n = {len(rows)})", loc="left", fontsize=10, weight="bold")
        ax.spines[["top", "right"]].set_visible(False)
        ax.grid(axis="y", color="#e2e8f0", linewidth=0.6)
        ax.set_axisbelow(True)
        ax.tick_params(labelsize=8)
    axes[0].set_ylabel("Complete text (Mi characters)", fontsize=9)
    axes[0].set_ylim(0, axes[0].get_ylim()[1] * 1.2)
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="lower center", ncol=2, frameon=False, fontsize=8)
    fig.subplots_adjust(left=0.1, right=0.99, top=0.87, bottom=0.23, wspace=0.12)
    save(fig, "matched_containers", [str(REPORT.relative_to(PAPER)), *report["inputs"]],
         "Aggregate text sizes by array profile and representation with matched spectrum information")


def categories(rows):
    groups, _ = validate_coverage(rows)
    measured = {id(r.spectrum): r for r in measure_sizes(rows)}
    fig, ax = plt.subplots(figsize=(7.0, 6.0))
    labels = list(groups)
    for y, (label, members) in enumerate(groups.items()):
        values = [measured[id(r)].framed_saving_pct for r in members]
        points = [r.n_peaks for r in members]
        color = COLORS[members[0].ms_level]
        ax.hlines(y, min(values), max(values), color=color, linewidth=1.7)
        ax.plot(median(values), y, "o", color=color, markersize=5)
        for x, value in [(1.03, str(len(members))),
                         (1.15, str(len({r.dataset.key for r in members}))),
                         (1.28, f"{min(points):,} to {max(points):,}")]:
            ax.text(x, y, value, transform=ax.get_yaxis_transform(), va="center", fontsize=7.5)
        if y % 2 == 0:
            ax.axhspan(y - 0.5, y + 0.5, color="#f8fafc", zorder=0)
    ax.set_yticks(range(len(labels)), labels)
    ax.set_ylim(len(labels) - 0.35, -1)
    for x, title in [(1.03, "n"), (1.15, "Files"), (1.28, "Points")]:
        ax.text(x, -0.9, title, transform=ax.get_yaxis_transform(), fontsize=7.5, weight="bold")
    ax.set_xlim(0, 60)
    ax.set_xlabel("Text length reduction (%)", fontsize=9)
    style(ax)
    ax.tick_params(axis="y", labelsize=8)
    fig.subplots_adjust(left=0.31, right=0.73, top=0.98, bottom=0.09)
    save(fig, "size_categories", size_inputs(), "Median and observed range of per-spectrum size reductions by category")


def main():
    rows = encode_all()
    composition(rows)
    containers()
    categories(rows)


if __name__ == "__main__":
    main()
