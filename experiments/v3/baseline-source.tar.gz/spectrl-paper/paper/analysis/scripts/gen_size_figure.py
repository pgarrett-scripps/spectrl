#!/usr/bin/env python3
"""Plot token length against peak count for every corpus spectrum."""

from __future__ import annotations

import json
from pathlib import Path

import matplotlib

from _assets import record
from _datasets import encode_all, inputs

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.lines import Line2D  # noqa: E402

HERE = Path(__file__).resolve().parent
PAPER = HERE.parent.parent
OUT = PAPER / "figures" / "token_size.png"
STATS = PAPER / "stats.json"

INK = "#1e293b"
MUTED = "#64748b"
EDGE = "#cbd5e1"
# Match MS-level colors and representation shapes in the size-reduction figure.
LEVEL_COLORS = {1: "#2563eb", 2: "#d97706", 3: "#9333ea"}
MARKERS = {"centroid": "o", "profile": "^", "unknown": "s"}


def _threshold(values: dict, key: str) -> int:
    entry = values[key]
    if entry["origin"]["by"] != "hand":
        raise RuntimeError(f"{key} in stats.json is no longer a hand entry")
    return int(entry["value"])


def draw_size(rows, values: dict) -> None:
    query_limit = _threshold(values, "carrier.query_limit_chars")
    chromium_limit = _threshold(values, "carrier.chromium_url_limit_chars")

    fig, ax = plt.subplots(figsize=(6.8, 4.1), dpi=300)

    thresholds = [(query_limit, "cautious query-string threshold")]
    for limit, label in thresholds:
        ax.axhline(limit, color=EDGE, lw=0.9, ls=(0, (4, 2.4)), zorder=1)
        ax.annotate(
            f"{label} (≤{limit:,})", xy=(0.0, limit), xycoords=("axes fraction", "data"),
            xytext=(5, 3), textcoords="offset points", fontsize=7, color=MUTED, ha="left",
        )

    ax.axhline(chromium_limit, color=MUTED, lw=0.9, ls=(0, (6, 2.4, 1.2, 2.4)), zorder=1)
    ax.annotate(
        f"Chromium URL limit ({chromium_limit:,} characters)",
        xy=(1.0, chromium_limit), xycoords=("axes fraction", "data"),
        xytext=(-5, 3), textcoords="offset points", fontsize=7, color=MUTED, ha="right",
    )

    for row in rows:
        color = LEVEL_COLORS[row.ms_level]
        marker = MARKERS[row.representation]
        ax.plot(
            [row.n_peaks, row.n_peaks], [row.lossy_chars, row.lossless_chars],
            color=EDGE, lw=0.7, zorder=2,
        )
        ax.scatter(row.n_peaks, row.lossy_chars, s=26, marker=marker, color=color, edgecolor="white",
                   linewidth=0.6, zorder=3)
        ax.scatter(row.n_peaks, row.lossless_chars, s=26, marker=marker, facecolor="white", edgecolor=color,
                   linewidth=1.1, zorder=3)

    ax.set_xscale("log")
    ax.set_yscale("log")
    ax.set_xlabel("Points in spectrum")
    ax.set_ylabel("Token length (characters)")
    ax.grid(alpha=0.15, which="major")
    ax.spines[["top", "right"]].set_visible(False)
    ax.tick_params(colors=MUTED)
    for spine in ("left", "bottom"):
        ax.spines[spine].set_color(EDGE)

    handles = [
        Line2D([], [], marker="o", ls="", color=LEVEL_COLORS[level], markeredgecolor="white",
               markersize=6, label=f"MS{level}")
        for level in sorted(LEVEL_COLORS)
    ] + [
        Line2D([], [], marker=MARKERS[mode], ls="", color=MUTED, markersize=6,
               label=mode.capitalize())
        for mode in sorted({row.representation for row in rows})
    ] + [
        Line2D([], [], marker="o", ls="", color=INK, markeredgecolor="white", markersize=6,
               label="default"),
        Line2D([], [], marker="o", ls="", markerfacecolor="white", markeredgecolor=INK,
               markersize=6, label="bit-exact"),
    ]
    ax.legend(handles=handles, frameon=False, fontsize=7.5, loc="upper left", ncol=3,
              bbox_to_anchor=(0, 0.9), borderaxespad=0.2)

    fig.tight_layout()
    fig.savefig(OUT, metadata={"Software": None}, bbox_inches="tight")
    plt.close(fig)
    record(
        "fig.size",
        str(OUT.relative_to(PAPER)), kind="figure",
        inputs=[*inputs(), "stats.json"],
        desc="Token length versus peak count in default and bit-exact modes, "
             "with query-string and Chromium URL limits",
    )


def main() -> int:
    values = json.loads(STATS.read_text(encoding="utf-8"))["values"]
    rows = encode_all()
    draw_size(rows, values)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
