"""Plot per-role payloads, full-token ablation, and repeated pipeline timings."""
from pathlib import Path
from statistics import median
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from _assets import record
from _codec_results import load, REPORT, PAPER

LABELS = ['Raw + zlib', 'Raw + zstd', 'Shuffle + zstd', 'Dictionary + zstd', 'Delta-shuffle + zlib', 'Delta-shuffle + zstd', 'Raw']
KEYS = ['raw-zlib', 'raw-zstd', 'shuffle-zstd', 'dictionary-zstd', 'delta-zlib', 'delta-zstd', 'raw-none']
COLORS = ['#94a3b8', '#94a3b8', '#64748b', '#64748b', '#2563eb', '#2563eb', '#cbd5e1']


def main():
    report = load()
    fig, axes = plt.subplots(2, 2, figsize=(7, 5.6), dpi=320)
    for ax, role, panel in [(axes[0, 0], 'mz', 'A  m/z payload'), (axes[0, 1], 'intensity', 'B  Intensity payload')]:
        arrays = [a for a in report['arrays'] if a['array'] == role]
        sizes = [sum(a['pipelines'][k]['blob_bytes'] for a in arrays) / 1024**2 for k in KEYS]
        ax.barh(LABELS, sizes, color=COLORS)
        ax.invert_yaxis()
        ax.set_xlabel('Total payload bytes (MiB)')
        ax.set_title(panel, loc='left', fontsize=10)
    profiles = ['raw-zlib', 'psi-adaptive', 'without-dictionary', 'v3-adaptive']
    names = ['Raw + zlib', 'Adaptive PSI', 'V3 without dictionary', 'V3 adaptive']
    sizes = [sum(r['profiles'][p]['token_bytes'] for r in report['spectra']) / 1024**2 for p in profiles]
    ax = axes[1, 0]
    ax.barh(names, sizes, color=['#94a3b8', '#64748b', '#60a5fa', '#2563eb'])
    ax.invert_yaxis()
    ax.set_title('C  Complete tokens', loc='left', fontsize=10)
    ax.set_xlabel('Total text (Mi characters)')
    ax = axes[1, 1]
    y = np.arange(len(KEYS))
    for offset, op, color, label in [(-0.18, 'encode_ms', '#2563eb', 'Encode'), (0.18, 'decode_ms', '#d97706', 'Decode')]:
        times = [median(median(a['pipelines'][k][op]) for a in report['arrays']) for k in KEYS]
        ax.barh(y + offset, times, height=0.32, color=color, label=label)
    ax.set_yticks(y, LABELS)
    ax.invert_yaxis()
    ax.set_xscale('log')
    ax.set_xlabel('Median per-array time (ms)')
    ax.set_title('D  Python pipeline runtime', loc='left', fontsize=10)
    ax.legend(frameon=False, fontsize=7, loc='lower right')
    for ax in axes.flat:
        ax.spines[['top', 'right']].set_visible(False)
        ax.tick_params(labelsize=7)
        ax.grid(axis='x', alpha=0.15)
        ax.set_axisbelow(True)
        ax.xaxis.label.set_size(8)
    fig.tight_layout(w_pad=2, h_pad=2)
    out = PAPER / 'figures/compression_v3.png'
    fig.savefig(out, metadata={'Software': None}, facecolor='white')
    plt.close(fig)
    record('fig.compression', str(out.relative_to(PAPER)), kind='figure',
           inputs=[str(REPORT.relative_to(PAPER)), *report['inputs']],
           desc='V3 lossless payloads by array role, full-token ablation, and repeated pipeline timing')
    print(out)


if __name__ == '__main__':
    main()
