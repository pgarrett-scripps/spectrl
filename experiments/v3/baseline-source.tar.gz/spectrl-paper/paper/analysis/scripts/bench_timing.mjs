#!/usr/bin/env node
import { readFileSync } from "node:fs"
import { performance } from "node:perf_hooks"
import { decodeToken, encodeSpectrum } from "../../../js/dist/index.js"

import { installZstd } from "../../../js/dist/zstd.js"
installZstd()

const request = JSON.parse(readFileSync(0, "utf8"))
const types = { float64: Float64Array, float32: Float32Array, int32: Int32Array }
function array(value) {
  if (value === null) return null
  const Type = types[value.dtype]
  if (!Type) throw new Error(`Unsupported dtype: ${value.dtype}`)
  return new Type(value.values)
}
const rows = request.rows.map(row => ({ ...row, source: {
  ...row.source,
  mz: array(row.source.mz), intensity: array(row.source.intensity),
  charge: array(row.source.charge),
  extraArrays: Object.fromEntries(Object.entries(row.source.extraArrays).map(([k, v]) => [k, array(v)])),
} }))
const measurements = []
for (const lossless of [false, true]) {
  const tokens = rows.map(row => encodeSpectrum(row.source, { lossless, quiet: true }))
  const samples = rows.map(() => ({ encode_ms: [], decode_ms: [] }))
  for (const iteration of Array.from({ length: request.warmups + request.repeats }, (_, i) => i)) {
    for (const [index, row] of rows.entries()) {
      const start = performance.now()
      const encoded = encodeSpectrum(row.source, { lossless, quiet: true })
      const middle = performance.now()
      const decoded = decodeToken(tokens[index])
      const end = performance.now()
      if (!encoded.length || decoded.mz.length !== row.source.mz.length) throw new Error("Invalid result")
      if (iteration >= request.warmups) {
        samples[index].encode_ms.push(middle - start)
        samples[index].decode_ms.push(end - middle)
      }
    }
  }
  measurements.push(...rows.map((row, index) => ({
    package: "TypeScript", mode: lossless ? "Lossless" : "Default",
    dataset: row.dataset, spectrum_id: row.spectrum_id, points: row.points, ...samples[index],
  })))
}
const pkg = JSON.parse(readFileSync(new URL("../../../js/package.json", import.meta.url), "utf8"))
process.stdout.write(JSON.stringify({ environment: { node: process.version, typescript_package: pkg.version }, measurements }))
