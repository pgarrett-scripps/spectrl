"""Group the selected corpus and enforce its documented sampling target."""

from collections import defaultdict
import json

from _datasets import MANIFEST


def sampling_target():
    return json.loads(MANIFEST.read_text())["sampling"]["minimum_per_reported_category"]


def coverage_groups(rows):
    manifest = json.loads(MANIFEST.read_text())
    metadata = {item["key"]: item for item in manifest["datasets"]}
    categories = defaultdict(list)
    modalities = defaultdict(list)
    for row in rows:
        acquisition = row.dataset.acquisition
        if acquisition == "profile":
            acquisition = "unspecified"
        label = f"{row.representation.capitalize()} MS{row.ms_level}, {acquisition}"
        categories[label].append(row)
        for tag in metadata[row.dataset.key].get("coverage_groups", []):
            if tag in ("ETD", "EThcD", "ECD acquisition", "Top-down MS2",
                       "Top-down ETD", "Glycopeptide MS2", "MALDI MS2") and row.ms_level == 1:
                continue
            modalities[tag].append(row)
    return dict(sorted(categories.items())), dict(sorted(modalities.items()))


def validate_coverage(rows):
    policy = json.loads(MANIFEST.read_text())["sampling"]
    target = policy["minimum_per_reported_category"]
    if not isinstance(target, int) or target < 1:
        raise ValueError("Sampling target must be a positive integer")
    groups = coverage_groups(rows)
    for kind, grouped in zip(("categories", "modalities"), groups):
        exceptions = policy["exceptions"].get(kind, {})
        for label, members in grouped.items():
            if len(members) >= target:
                if label in exceptions:
                    raise AssertionError(f"Remove resolved sampling exception: {label}")
                continue
            exception = exceptions.get(label)
            if not exception or not exception.get("reason"):
                raise AssertionError(f"Undocumented sparse {kind} group: {label} ({len(members)})")
            if len(members) != exception["expected_count"]:
                raise AssertionError(f"Sampling exception count changed: {label} ({len(members)})")
        if missing := set(exceptions) - set(grouped):
            raise AssertionError(f"Sampling exceptions refer to absent groups: {missing}")
    return groups
