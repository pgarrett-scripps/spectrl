"""Compare outer text encodings while preserving every payload byte."""

import base64
from urllib.parse import quote, unquote

import base91

from spectrl.token import b64url_decode, b64url_encode
from spectrl.cbor_format import token_checksum


def measure_text_encodings(rows):
    measured = []
    for row in rows:
        for mode, token in (("Default", row.lossy_token), ("Lossless", row.lossless_token)):
            magic, version, payload_mode, original, checksum = token.split(".")
            payload = b64url_decode(original)
            overhead = len(token) - len(original)
            if b64url_encode(payload) != original:
                raise AssertionError("Noncanonical base64url baseline")
            for encoding, encode, decode in (
                ("Base85", base64.b85encode, base64.b85decode),
                ("basE91", base91.encode, base91.decode),
            ):
                encoded = encode(payload)
                text = encoded.decode("ascii") if isinstance(encoded, bytes) else encoded
                if bytes(decode(text)) != payload:
                    raise AssertionError(f"{encoding} changed payload bytes")
                body = f"{magic}.{version}.{payload_mode}.{text}"
                candidate = f"{body}.{token_checksum(body)}"
                raw_bytes = len(candidate.encode("ascii"))
                if raw_bytes != len(text) + overhead:
                    raise AssertionError("Framing overhead changed")
                escaped = quote(candidate, safe="")
                if unquote(escaped) != candidate:
                    raise AssertionError("URL escaping changed candidate text")
                measured.append({
                    "dataset": row.dataset.key,
                    "spectrum_id": row.spectrum_id,
                    "mode": mode,
                    "encoding": encoding,
                    "payload_bytes": len(payload),
                    "base64url_payload_bytes": len(original),
                    "candidate_payload_bytes": len(text),
                    "base64url_token_bytes": len(token),
                    "candidate_token_bytes": raw_bytes,
                    "escaped_candidate_bytes": len(escaped),
                    "payload_saving_pct": 100 * (1 - len(text) / len(original)),
                    "token_saving_pct": 100 * (1 - raw_bytes / len(token)),
                    "escaped_saving_pct": 100 * (1 - len(escaped) / len(token)),
                })
    return measured
