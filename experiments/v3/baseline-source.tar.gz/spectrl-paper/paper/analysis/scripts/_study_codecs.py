"""Analysis-only bounded quantizers and standard pipeline measurements."""

import math
import struct
import time

import cbor2
import numpy as np
from _spectral_similarity import normalized_spectral_angle

from spectrl.codecs._delta import delta_shuffle, delta_unshuffle
from spectrl.codecs.dictionary import shuffle
from spectrl.codecs.numpress import (
    DEFAULT_NUMLIN_FP,
    DEFAULT_NUMSLOF_FP,
    _resolve_backend,
    _safe_slof_fp,
    decode_numlin_raw,
    decode_numslof_raw,
    encode_numlin_raw,
)
from spectrl.pipeline import Encoding, decode_pipeline, encode_pipeline, register_encoding

QUANT_MZ = "paper:quantized-delta"
QUANT_INT = "paper:quantized-intensity"
LINEAR_FP = "paper:linear-fp"
SLOF_FP = "paper:slof-fp"
BUDGETS = [(1e-6, 1e-5), (1e-5, 1e-4), (1e-4, 1e-3)]
REPEATS = 3
PSI_LOSSLESS = [
    ("raw-none", 0, 0),
    ("raw-zlib", 0, 1),
    ("raw-zstd", 0, 2),
    ("shuffle-zstd", 1, 2),
    ("dictionary-zstd", 2, 2),
]
PSI_ALL = PSI_LOSSLESS + [
    (f"{name}-{comp}", eid, cid)
    for name, eid in [("linear", 4), ("pic", 5), ("slof", 6)]
    for comp, cid in [("none", 0), ("zlib", 1), ("zstd", 2)]
]


def validate_step(params):
    if set(params) != {"step"} or not math.isfinite(params["step"]) or params["step"] <= 0:
        raise ValueError("quantization needs a finite positive step")


def quantize(data, step, dtype):
    a = np.asarray(data, dtype=np.float64)
    scaled = np.rint(a / step)
    cap = min(np.iinfo(dtype).max, 2**53 - 1)
    if not np.isfinite(scaled).all() or np.any(scaled < 0) or np.any(scaled > cap):
        raise ValueError("quantized words exceed the supported domain")
    return scaled.astype(dtype)


def mz_encode(a, tail, p):
    words = quantize(a, p["step"], "<u8")
    return delta_shuffle(words.tobytes(), 8)


def mz_decode(b, tail, n, p):
    if len(b) != 8 * n:
        raise ValueError("quantized m/z count mismatch")
    return np.frombuffer(delta_unshuffle(b, 8), dtype="<u8").astype("float64") * p["step"]


def intensity_encode(a, tail, p):
    return shuffle(quantize(a, p["step"], "<u4").tobytes(), 4)


def intensity_decode(b, tail, n, p):
    if len(b) != 4 * n:
        raise ValueError("quantized intensity count mismatch")
    return np.frombuffer(shuffle(b, 4, inverse=True), dtype="<u4").astype("float64") * p["step"]


register_encoding(QUANT_MZ, Encoding(mz_encode, mz_decode, validate_step, False, (1000523,)))
register_encoding(QUANT_INT, Encoding(intensity_encode, intensity_decode, validate_step, False, (1000523,)))


def validate_fp(params):
    if set(params) != {"fp"} or not math.isfinite(params["fp"]) or params["fp"] <= 0:
        raise ValueError("fixed point must be finite and positive")


def slof_float_encode(a, tail, p):
    data = np.asarray(a, dtype="float64")
    if not np.isfinite(data).all() or np.any(data < 0):
        raise ValueError("SLOF requires finite nonnegative values")
    if np.any(np.log1p(data) * p["fp"] > 65535):
        raise ValueError("SLOF scaled value exceeds uint16")
    return _resolve_backend().encode_slof(data, p["fp"]).tobytes()


def float_fp_decode(fn, raw, n, params):
    if len(raw) < 8 or struct.unpack(">d", raw[:8])[0] != params["fp"]:
        raise ValueError("Numpress fixed point mismatch")
    result = fn(raw)
    if len(result) != n:
        raise ValueError("Numpress length mismatch")
    return result


register_encoding(
    LINEAR_FP,
    Encoding(
        lambda a, t, p: encode_numlin_raw(a, p["fp"]),
        lambda b, t, n, p: float_fp_decode(decode_numlin_raw, b, n, p),
        validate_fp,
        False,
        (1000523,),
    ),
)
register_encoding(
    SLOF_FP,
    Encoding(
        slof_float_encode,
        lambda b, t, n, p: float_fp_decode(decode_numslof_raw, b, n, p),
        validate_fp,
        False,
        (1000523,),
    ),
)


def timings(fn):
    fn()
    samples = []
    for _ in range(REPEATS):
        start = time.perf_counter_ns()
        fn()
        samples.append((time.perf_counter_ns() - start) / 1e6)
    return samples


def errors(a, b, role):
    a, b = np.asarray(a, dtype="float64"), np.asarray(b, dtype="float64")
    if a.shape != b.shape or not np.isfinite(b).all():
        raise AssertionError("invalid reconstructed array")
    diff = np.abs(a - b)
    positive = a > 0
    scale = float(np.max(np.abs(a), initial=0)) or 1.0
    return {
        "max_abs": float(diff.max(initial=0)),
        "max_ppm": float(np.max(diff[positive] / a[positive], initial=0) * 1e6),
        "max_base_peak_fraction": float(diff.max(initial=0) / scale),
        "positive_to_zero": int(np.sum(positive & (b == 0))),
        "positive_count": int(positive.sum()),
        "spectral_angle": normalized_spectral_angle(a, b) if role == "intensity" and np.all(a >= 0) else None,
        "values_exact": bool(np.array_equal(a, b)),
    }


def candidate(data, role, enc, comp, timed=False):
    tail = {"float32": 1000521, "float64": 1000523, "int32": 1000519}[data.dtype.name]
    if enc[0] not in (0, 1, 2, 3):
        tail = 1000523
    blob, fidelity = encode_pipeline(data, tail, enc, comp)
    recovered = decode_pipeline(blob, tail, len(data), enc, comp, fidelity)
    if fidelity == 0 and (data.dtype != recovered.dtype or data.tobytes() != recovered.tobytes()):
        raise AssertionError("lossless pipeline changed native bits")
    item = {
        "encoding": enc,
        "compression": comp,
        "dtype": tail,
        "fidelity": fidelity,
        "blob_bytes": len(blob),
        "errors": errors(data, recovered, role),
        "descriptor_bytes": len(cbor2.dumps({0: tail, 2: enc, 3: comp, 5: blob, 7: fidelity}, canonical=True)),
    }
    if timed:
        item["encode_ms"] = timings(lambda: encode_pipeline(data, tail, enc, comp))
        item["decode_ms"] = timings(lambda: decode_pipeline(blob, tail, len(data), enc, comp, fidelity))
    return item, blob


def numpress_descriptor(eid, data, error=None):
    if eid == 4:
        fp = DEFAULT_NUMLIN_FP if error is None else max(1, math.ceil(0.5 / error))
    elif eid == 6:
        fp = (
            _safe_slof_fp(data, DEFAULT_NUMSLOF_FP)
            if error is None
            else max(1, math.ceil(0.5 / math.log1p(error / (float(np.max(data, initial=0)) + 1))))
        )
        if _safe_slof_fp(data, fp) != fp:
            raise ValueError("SLOF cannot meet this bound at uint16 width")
    else:
        return [eid, 1]
    return [eid, 1, {"fp": fp}]


def tuned_candidates(data, role, error):
    choices = []
    # Both floating fixed points allowed by Numpress and the package's integer
    # settings compete. This avoids attributing an API restriction to PSI.
    for eid in [4] if role == "mz" else [4, 6]:
        floating = 0.5 / error if eid == 4 else 0.5 / math.log1p(error / (float(np.max(data, initial=0)) + 1))
        descriptors = [[LINEAR_FP if eid == 4 else SLOF_FP, 1, {"fp": floating * (1 + 1e-12)}]]
        try:
            descriptors.append(numpress_descriptor(eid, data, error))
        except ValueError:
            pass
        for enc in descriptors:
            for cid in (0, 1, 2):
                try:
                    result, blob = candidate(data, role, enc, [cid, 1])
                except ValueError:
                    continue
                if result["errors"]["max_abs"] <= error:
                    choices.append((result, blob))
    return choices
