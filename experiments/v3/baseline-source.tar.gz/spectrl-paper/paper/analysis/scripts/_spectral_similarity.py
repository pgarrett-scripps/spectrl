"""Compare paired source and decoded intensities in the selected benchmark."""

from __future__ import annotations

import hashlib
import json
import math
from collections import Counter
from pathlib import Path

import numpy as np
from spectrl import decode_token

from _coverage import coverage_groups
from _datasets import DatasetRow, inputs
from _provenance import code_inputs

PAPER = Path(__file__).resolve().parents[2]
REPORT = PAPER / "analysis/reports/spectral_similarity.json"
MODES = ("lossless", "default")


def normalized_spectral_angle(source, decoded) -> float | None:
    """Return the normalized angle similarity, or None for undefined vectors.

    The half-angle identity avoids cancellation in arccos near a score of one.
    Independent positive scaling before the L2 norm prevents norm overflow.
    """
    a, b = (np.asarray(values, dtype=np.float64) for values in (source, decoded))
    if a.ndim != 1 or a.shape != b.shape:
        raise ValueError("Spectral angle requires paired one-dimensional arrays")
    if not np.isfinite(a).all() or not np.isfinite(b).all():
        raise ValueError("Spectral angle requires finite intensities")
    if np.any(a < 0) or np.any(b < 0):
        raise ValueError("This normalized spectral angle requires nonnegative intensities")
    if a.size == 0 or not np.any(a) or not np.any(b):
        return None
    if np.array_equal(a, b):
        return 1.0
    a = a / np.max(a)
    b = b / np.max(b)
    a /= np.linalg.norm(a)
    b /= np.linalg.norm(b)
    angle = 2 * math.atan2(float(np.linalg.norm(a - b)), float(np.linalg.norm(a + b)))
    return float(np.clip(1 - 2 * angle / math.pi, 0, 1))


def paired_arrays(row: DatasetRow, mode: str):
    """Preserve source point identity through the encoder's stable sorting."""
    if mode not in MODES:
        raise ValueError(f"Unknown encoding mode: {mode}")
    order = np.argsort(row.source.mz, kind="stable")
    source_mz = np.asarray(row.source.mz, dtype=np.float64)[order]
    source_i = np.asarray(row.source.intensity, dtype=np.float64)[order]
    token = row.lossless_token if mode == "lossless" else row.lossy_token
    decoded = decode_token(token)
    decoded_mz = np.asarray(decoded.mz, dtype=np.float64)
    decoded_i = np.asarray(decoded.intensity, dtype=np.float64)
    if not (source_mz.shape == source_i.shape == decoded_mz.shape == decoded_i.shape):
        raise AssertionError(f"Point correspondence changed: {row.spectrum_id}")
    if mode == "lossless":
        np.testing.assert_array_equal(source_mz, decoded_mz)
        np.testing.assert_array_equal(source_i, decoded_i)
    return source_mz, source_i, decoded_mz, decoded_i


def analyze(rows: list[DatasetRow]) -> dict:
    measurements = []
    identities = set()
    for row in rows:
        identity = (row.dataset.key, row.spectrum_id)
        if identity in identities:
            raise AssertionError(f"Duplicate spectrum: {identity}")
        identities.add(identity)
        for mode in MODES:
            mz, source, decoded_mz, decoded = paired_arrays(row, mode)
            score = normalized_spectral_angle(source, decoded)
            reason = None
            if not source.size:
                reason = "empty"
            elif not np.any(source):
                reason = "zero_source_norm"
            elif not np.any(decoded):
                reason = "zero_decoded_norm"
            positive = source > 0
            zeroed = positive & (decoded == 0)
            base_peak = float(np.max(source, initial=0))
            abs_error = np.abs(decoded - source)
            measurements.append({
                "dataset": row.dataset.key,
                "spectrum_id": row.spectrum_id,
                "representation": row.representation,
                "ms_level": row.ms_level,
                "mode": mode,
                "points": row.n_peaks,
                "spectral_angle": score,
                "undefined_reason": reason,
                "positive_values": int(np.count_nonzero(positive)),
                "positive_values_zeroed": int(np.count_nonzero(zeroed)),
                "zeroed_fraction": float(np.count_nonzero(zeroed) / np.count_nonzero(positive))
                if np.any(positive) else 0.0,
                "zeroed_intensity_pct": float(100 * np.sum(source[zeroed]) / np.sum(source))
                if np.any(positive) else 0.0,
                "mz_abs_error_max_da": float(np.max(np.abs(decoded_mz - mz), initial=0)),
                "intensity_error_max_base_peak_pct": float(100 * np.max(abs_error, initial=0) / base_peak)
                if base_peak else None,
                "arrays_exact": bool(np.array_equal(source, decoded) and np.array_equal(mz, decoded_mz)),
            })
    summary = []
    for representation in ("all", *sorted({row.representation for row in rows})):
        for mode in MODES:
            group = [m for m in measurements if m["mode"] == mode
                     and (representation == "all" or m["representation"] == representation)]
            scores = [m["spectral_angle"] for m in group if m["spectral_angle"] is not None]
            summary.append({
                "representation": representation,
                "mode": mode,
                "total": len(group),
                "valid": len(scores),
                "undefined": dict(Counter(m["undefined_reason"] for m in group
                                          if m["undefined_reason"] is not None)),
                "median": float(np.median(scores)) if scores else None,
                "p05": float(np.percentile(scores, 5, method="linear")) if scores else None,
                "minimum": min(scores) if scores else None,
                "maximum": max(scores) if scores else None,
            })
    valid = [m for m in measurements if m["mode"] == "default" and m["spectral_angle"] is not None]
    if not valid:
        raise ValueError("The selected benchmark has no defined default-mode spectral angles")
    tie = lambda m: (m["dataset"], m["spectrum_id"])
    examples = []

    def add_example(measurement, criterion):
        identity = (measurement["dataset"], measurement["spectrum_id"])
        existing = next((e for e in examples if (e["dataset"], e["spectrum_id"]) == identity), None)
        if existing:
            existing["criteria"].append(criterion)
        else:
            examples.append({"dataset": identity[0], "spectrum_id": identity[1], "criteria": [criterion]})

    for representation, level, criterion in (
        ("centroid", 2, "Centroid MS2 near median SA"),
        ("profile", None, "Profile near median SA"),
    ):
        group = [m for m in valid if m["representation"] == representation
                 and (level is None or m["ms_level"] == level)]
        if group:
            median = float(np.median([m["spectral_angle"] for m in group]))
            add_example(min(group, key=lambda m: (abs(m["spectral_angle"] - median), *tie(m))), criterion)
    _, modalities = coverage_groups(rows)
    topdown_ids = {(row.dataset.key, row.spectrum_id)
                   for row in modalities.get("Top-down MS2", []) if row.ms_level == 2}
    topdown = [m for m in valid if tie(m) in topdown_ids]
    if not topdown:
        raise ValueError("The figure requires a top-down MS2 spectrum with a defined spectral angle")
    median = float(np.median([m["spectral_angle"] for m in topdown]))
    add_example(min(topdown, key=lambda m: (abs(m["spectral_angle"] - median), *tie(m))),
                "Top-down MS2 near median SA")
    add_example(min(valid, key=lambda m: (m["spectral_angle"], *tie(m))), "Lowest default-mode SA")
    return {"schema_version": 1, "n_spectra": len(rows), "measurements": measurements,
            "summary": summary, "examples": examples}


def analysis_inputs() -> list[str]:
    repo = PAPER.parent
    return [*inputs(), *["../" + p.relative_to(repo).as_posix()
                         for p in sorted((repo / "src/spectrl").rglob("*.py"))]]


def write_report(report: dict) -> None:
    report = {
        **report,
        "metric": "1 - 2/pi * acos(dot(source, decoded)/(norm(source)*norm(decoded)))",
        "implementation": "Equivalent atan2 half-angle identity on L2-normalized vectors",
        "preprocessing": "Stable source m/z sort, index pairing, untransformed intensities, no filtering or binning",
        "selection": "Existing benchmark selection from corpus.json, with no additional spectrum sampling",
        "inputs": {name: hashlib.sha256((PAPER / name).read_bytes()).hexdigest()
                   for name in sorted(set(analysis_inputs()) | set(code_inputs()))},
    }
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")


def add_stats(stats, report: dict) -> None:
    for group in report["summary"]:
        if group["representation"] != "all":
            continue
        prefix = f"spectral_angle.{group['mode']}"
        stats.add(f"{prefix}.n_valid", group["valid"], fmt=",", sign="+",
                  desc=f"Selected spectra with defined {group['mode']} spectral angle")
        stats.add(f"{prefix}.n_undefined", group["total"] - group["valid"], fmt=",",
                  between=(0, group["total"]), desc=f"Undefined {group['mode']} spectral angles")
        for name in ("median", "p05", "minimum"):
            stats.add(f"{prefix}.{name}", group[name], fmt=".8f",
                      between=(1, 1) if group["mode"] == "lossless" else (0, 1),
                      desc=f"{name} normalized spectral angle for selected {group['mode']} spectra")
