#!/usr/bin/env python3
"""Write ../../figures/what_encodes.png: what a spectrl token encodes.

The data model, not the bytes (the anatomy figure covers those): the token is
the `spectrl` identifier, the `v3` format version, an explicit payload mode,
a base64url payload, and a required trailing CRC-32 checksum. The document is a map of small integer
keys. The diagram lists keys 0 through 11 in specification order, with each
field's purpose and CBOR type.

Grounded in schema/registry.json rather than typed here: the script fails if
the registry declares a header key the diagram does not list (or vice versa),
and it checks the required flags, so a future format addition cannot silently
fall off this picture.
"""

from __future__ import annotations

import json
from pathlib import Path

import matplotlib

from _assets import record

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.patches import FancyBboxPatch  # noqa: E402

HERE = Path(__file__).resolve().parent
PAPER = HERE.parent.parent
OUT = PAPER / "figures" / "what_encodes.png"

REGISTRY_INPUT = "../schema/registry.json"  # as declared to the manifest
REGISTRY = (PAPER / REGISTRY_INPUT).resolve()

INK = "#0f172a"
MUTED = "#64748b"
FAINT = "#94a3b8"
BLUE = "#2563eb"
BAR = "#f1f5f9"
EDGE = "#cbd5e1"

W = 6.3

# One row per header key, in key order: (key, name, purpose, encoding,
# required). `required` is checked against the registry (and stated in the
# footer, not by color: the rows are drawn uniformly so nothing in the payload
# visually pairs with the colored token-strip parts). The format version
# (token prefix) and checksum (trailing part) live in the token strip, not in
# the header.
ROWS = [
    (0, "peak count", "length of every peak array", "int", True),
    (1, "spectrum ID", 'native identifier, e.g. "scan=42"', "text", False),
    (2, "CV parameters", "controlled terms: MS level, polarity, centroid/profile",
     "ordered pairs", False),
    (3, "scan list", "per-scan params and scan windows", "map", False),
    (4, "precursors", "isolation window, selected ions, activation",
     "array of maps", False),
    (5, "products", "isolation windows", "array of maps", False),
    (6, "peak arrays", "compressed m/z, intensity, charge, and additional arrays",
     "array of maps", False),
    (7, "free-text params", "named values with optional types and units", "array of maps",
     False),
    (8, "source", "source file and spectrum references", "map", False),
    (9, "acquisition", "instrument, components, and acquisition software", "map", False),
    (10, "processing", "known software, processing, and selection history", "array of maps", False),
    (11, "extensions", "versioned optional or required records", "map", False),
]


def check_against_registry() -> None:
    """Rows must list exactly the registry's header keys, flags included."""
    registry = json.loads(REGISTRY.read_text())
    declared = {int(k): v["required"] for k, v in registry["header_keys"].items()}
    listed = {key: required for key, _, _, _, required in ROWS}
    if len(listed) != len(ROWS):
        raise SystemExit("a header key is listed twice")
    if set(listed) != set(declared):
        raise SystemExit(
            f"diagram out of step with {REGISTRY_INPUT}: "
            f"missing {set(declared) - set(listed) or '{}'}, "
            f"extra {set(listed) - set(declared) or '{}'}")
    wrong = [k for k in listed if listed[k] != declared[k]]
    if wrong:
        raise SystemExit(f"required flag wrong for keys {wrong}")


def rounded(ax, x, y, w, h, *, face, edge, lw=0.7, radius=0.045):
    ax.add_patch(FancyBboxPatch(
        (x, y), w, h, boxstyle=f"round,pad=0,rounding_size={radius}",
        facecolor=face, edgecolor=edge, linewidth=lw))


def draw_token_strip(ax, y, h):
    """The five token parts: identifier, version, mode, payload, and checksum."""
    rounded(ax, 0.15, y, 0.82, h, face=BLUE, edge="none")
    ax.text(0.56, y + h / 2, "spectrl", fontsize=8, family="monospace",
            color="white", ha="center", va="center")
    ax.text(1.02, y + h / 2, ".", fontsize=9, family="monospace", color=INK,
            ha="center", va="center")
    rounded(ax, 1.08, y, 0.55, h, face=BLUE, edge="none")
    ax.text(1.355, y + h / 2, "v3", fontsize=8, family="monospace",
            color="white", ha="center", va="center")
    ax.text(1.68, y + h / 2, ".", fontsize=9, family="monospace", color=INK,
            ha="center", va="center")
    rounded(ax, 1.74, y, 0.35, h, face=BLUE, edge="none")
    ax.text(1.915, y + h / 2, "z", fontsize=8, family="monospace",
            color="white", ha="center", va="center")
    ax.text(2.15, y + h / 2, ".", fontsize=9, family="monospace", color=INK,
            ha="center", va="center")
    rounded(ax, 2.21, y, 5.12 - 2.21, h, face=BAR, edge=EDGE)
    ax.text((2.21 + 5.12) / 2, y + h / 2, "base64url( zlib( CBOR ) )",
            fontsize=7.1, family="monospace", color=INK, ha="center",
            va="center")
    ax.text(5.185, y + h / 2, ".", fontsize=9, family="monospace", color=INK,
            ha="center", va="center")
    rounded(ax, 5.25, y, 0.9, h, face=BAR, edge=BLUE, lw=0.9)
    ax.text(5.7, y + h / 2, "checksum", fontsize=7.2, family="monospace",
            color=BLUE, ha="center", va="center")
    ax.text(3.0, y - 0.1, "mode: z = zlib, r = raw CBOR", fontsize=5.2, color=MUTED,
            ha="center", va="center")
    # Label the framing fields.
    ax.text(0.88, y - 0.1, "identifier + format version", fontsize=5.2, color=MUTED,
            ha="center", va="center")
    ax.text(5.7, y - 0.1, "CRC-32 of the parts\nbefore it (required)",
            fontsize=5.2, color=MUTED, ha="center", va="top",
            linespacing=1.25)


NAME_X, PURPOSE_X, ENC_X = 0.62, 1.78, 6.06


def draw_row(ax, y, h, row):
    key, name, purpose, encoding, _required = row
    cy = y + h / 2
    rounded(ax, 0.15, y, 6.0, h, face=BAR, edge=EDGE, lw=0.6, radius=0.035)
    rounded(ax, 0.23, cy - 0.075, 0.3, 0.15, face="white", edge=EDGE, lw=0.6,
            radius=0.03)
    ax.text(0.38, cy, str(key), fontsize=6, family="monospace", color=MUTED,
            ha="center", va="center")
    ax.text(NAME_X, cy, name, fontsize=6.8, color=INK, fontweight="bold",
            ha="left", va="center")
    ax.text(PURPOSE_X, cy, purpose, fontsize=6.3, color=MUTED, ha="left",
            va="center")
    ax.text(ENC_X, cy, encoding, fontsize=5.6, family="monospace", color=FAINT,
            ha="right", va="center")


def main() -> int:
    check_against_registry()

    strip_h, row_h, row_gap = 0.3, 0.225, 0.045
    list_h = len(ROWS) * (row_h + row_gap) - row_gap
    H = 0.12 + strip_h + 0.42 + list_h + 0.68

    fig, ax = plt.subplots(figsize=(W, H), dpi=300)
    ax.set_xlim(0, W)
    ax.set_ylim(0, H)
    ax.set_axis_off()
    fig.subplots_adjust(left=0, right=1, top=1, bottom=0)

    strip_y = H - 0.12 - strip_h
    draw_token_strip(ax, strip_y, strip_h)
    list_top = strip_y - 0.42

    for i, row in enumerate(ROWS):
        y = list_top - row_h - i * (row_h + row_gap)
        draw_row(ax, y, row_h, row)

    ax.text(0.15, 0.55, "header key", fontsize=5.5, color=MUTED, ha="left",
            va="center")
    ax.text(0.72, 0.55,
            "Peak count is required. Other fields are optional.", fontsize=5.5, color=FAINT, ha="left",
            va="center")
    ax.text(ENC_X, 0.55, "CBOR type", fontsize=5.5, color=MUTED,
            ha="right", va="center")

    ax.text(W / 2, 0.28, "Array values  →  encoding [ID, revision, parameters]  →  compression  →  bytes",
            fontsize=7, color=BLUE, ha="center")
    ax.text(W / 2, 0.08, "Decode in reverse. Built-in and custom operations share the same descriptor contract.",
            fontsize=6, color=MUTED, ha="center")
    OUT.parent.mkdir(exist_ok=True)
    fig.savefig(OUT, facecolor="white", metadata={"Software": None})
    plt.close(fig)

    record("fig.encodes", str(OUT.relative_to(PAPER)), kind="figure",
           inputs=[REGISTRY_INPUT],
           desc="What a spectrl token encodes: identifier, version, payload, "
                "payload mode and checksum, with the header's integer keys in order, each with "
                "its purpose and CBOR type")
    print(f"wrote {OUT.relative_to(PAPER)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
