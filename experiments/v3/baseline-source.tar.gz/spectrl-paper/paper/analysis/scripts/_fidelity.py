"""Stream every source spectrum through both Python encoding modes."""

from __future__ import annotations

import hashlib
import json
import warnings
import xml.etree.ElementTree as ET
from dataclasses import dataclass

import numpy as np
from mzmlpy.run import Mzml
from spectrl import decode_token, encode_spectrum, from_mzmlpy

from _datasets import DATASETS, MANIFEST, _assert_metadata_equal, _ref_groups


@dataclass
class Fidelity:
    n_spectra: int = 0
    n_peaks: int = 0
    n_empty: int = 0
    n_zero_intensities: int = 0
    mz_abs_error_max: float = 0.0
    intensity_norm_error_max: float = 0.0
    intensity_relative_error_max: float = 0.0


def validate_spectrum(source) -> Fidelity:
    """Require normalized lossless equality and measure default-mode errors."""
    order = np.argsort(source.mz, kind="stable") if source.mz is not None else None
    arrays = {name: getattr(source, name) for name in ("mz", "intensity", "charge")}
    arrays.update(source.extra_arrays)
    normalized = {
        name: None if array is None else np.asarray(array)[order]
        for name, array in arrays.items()
    }
    decoded_modes = []
    for lossless in (False, True):
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            decoded = decode_token(encode_spectrum(source, lossless=lossless))
        _assert_metadata_equal(source, decoded, lossy=not lossless)
        if source.array_units != decoded.array_units:
            raise AssertionError(f"array units changed: {source.id}")
        if set(source.extra_arrays) != set(decoded.extra_arrays):
            raise AssertionError(f"additional array identities changed: {source.id}")
        actual = {name: getattr(decoded, name) for name in ("mz", "intensity", "charge")}
        actual.update(decoded.extra_arrays)
        for name, expected in normalized.items():
            array = actual[name]
            if expected is None or array is None:
                if expected is not array:
                    raise AssertionError(f"array presence changed: {source.id}, {name}")
                continue
            if expected.shape != array.shape or lossless and expected.dtype != array.dtype:
                raise AssertionError(f"array shape or dtype changed: {source.id}, {name}")
            if not np.isfinite(array).all():
                raise AssertionError(f"nonfinite decoded array: {source.id}, {name}")
            if lossless:
                if array.tobytes() != expected.tobytes():
                    raise AssertionError(f"array bits changed: {source.id}, {name}")
        decoded_modes.append(decoded)
    result = Fidelity(n_spectra=1, n_peaks=source.default_array_length)
    if source.default_array_length == 0:
        result.n_empty = 1
        return result
    default = decoded_modes[0]
    mz = normalized["mz"]
    intensity = normalized["intensity"]
    result.mz_abs_error_max = float(np.max(np.abs(default.mz - mz), initial=0.0))
    error = np.abs(default.intensity - intensity)
    scale = float(np.max(np.abs(intensity), initial=0.0)) or 1.0
    result.intensity_norm_error_max = float(np.max(error / scale, initial=0.0))
    nonzero = intensity != 0
    result.intensity_relative_error_max = float(
        np.max(error[nonzero] / np.abs(intensity[nonzero]), initial=0.0)
    )
    result.n_zero_intensities = int(np.count_nonzero(~nonzero))
    np.testing.assert_array_equal(default.intensity[~nonzero], intensity[~nonzero])
    return result


def validate_all() -> dict[str, Fidelity]:
    """Include every spectrum, without the size benchmark's quantile selection."""
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    hashes = {item["key"]: item["sha256"] for item in manifest["datasets"]}
    results = {}
    for dataset in DATASETS:
        with dataset.path.open("rb") as stream:
            digest = hashlib.file_digest(stream, "sha256").hexdigest()
        if digest != hashes[dataset.key]:
            raise RuntimeError(f"corpus hash mismatch: {dataset.key}")
        # Count actual elements because a subset fixture can retain its parent run's list count.
        xml_count = 0
        for _, element in ET.iterparse(dataset.path):
            if element.tag == "{http://psi.hupo.org/ms/mzml}spectrum":
                xml_count += 1
            element.clear()
        total = Fidelity()
        with Mzml(str(dataset.path)) as mzml:
            refs = _ref_groups(mzml)
            for spectrum in mzml.spectra:
                source = from_mzmlpy(spectrum, ref_groups=refs, run=mzml)
                try:
                    result = validate_spectrum(source)
                except Exception as error:
                    raise AssertionError(f"{dataset.key}, {source.id}: {error}") from error
                for name in ("n_spectra", "n_peaks", "n_empty", "n_zero_intensities"):
                    setattr(total, name, getattr(total, name) + getattr(result, name))
                for name in ("mz_abs_error_max", "intensity_norm_error_max", "intensity_relative_error_max"):
                    setattr(total, name, max(getattr(total, name), getattr(result, name)))
                if total.n_spectra % 1000 == 0:
                    print(f"Full-file fidelity: {dataset.key}, {total.n_spectra} spectra", flush=True)
        if total.n_spectra != xml_count:
            raise AssertionError(f"{dataset.key}: validated {total.n_spectra} of {xml_count} spectrum elements")
        results[dataset.key] = total
        print(f"Full-file fidelity passed: {dataset.key}, {total}", flush=True)
    return results
