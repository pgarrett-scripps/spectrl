"""Select point-count quantiles and retain referenced spectra without changing arrays.

Run from analysis with uv run python scripts/extract_public_subset.py SOURCE OUTPUT.
The adjacent selection JSON records the source hash and native spectrum IDs.
"""

from __future__ import annotations

import argparse
import json
import xml.etree.ElementTree as ET
from pathlib import Path

from rebuild_subset import NS, digest, extract


def select(source: Path, per_level: int, ms_levels: set[int] | None = None,
           eligible_ids: set[str] | None = None) -> tuple[list[str], dict]:
    records = []
    for _, elem in ET.iterparse(source):
        if elem.tag != NS + "spectrum":
            continue
        level = next(int(p.get("value")) for p in elem.findall(NS + "cvParam")
                     if p.get("accession") == "MS:1000511")
        refs = [p.get("spectrumRef") for p in elem.iter(NS + "precursor")
                if p.get("spectrumRef")]
        records.append((elem.get("id"), level, int(elem.get("defaultArrayLength")), refs))
        elem.clear()
    by_id = {r[0]: r for r in records}
    if len(by_id) != len(records):
        raise ValueError("Source spectrum IDs are not unique")
    if ms_levels and not ms_levels <= {r[1] for r in records}:
        raise ValueError("Requested MS level is absent from the source")
    if eligible_ids is not None and (not eligible_ids or not eligible_ids <= by_id.keys()):
        raise ValueError("Eligible spectrum IDs must be nonempty and present in the source")
    chosen = set()
    counts = {}
    for level in sorted({r[1] for r in records}):
        candidates = [r for r in records if r[1] == level and r[2] > 0]
        candidates.sort(key=lambda r: r[2])
        counts[str(level)] = len(candidates)
        if ms_levels is not None and level not in ms_levels:
            continue
        if eligible_ids is not None:
            candidates = [r for r in candidates if r[0] in eligible_ids]
        n = min(per_level, len(candidates))
        positions = [round(i * (len(candidates) - 1) / (n - 1)) for i in range(n)] if n > 1 else [0] if n else []
        chosen.update(candidates[i][0] for i in positions)
    pending = list(chosen)
    while pending:
        for ref in by_id[pending.pop()][3]:
            if ref not in by_id:
                raise ValueError(f"Source has an unresolved precursor reference: {ref}")
            if ref not in chosen:
                chosen.add(ref)
                pending.append(ref)
    return [r[0] for r in records if r[0] in chosen], counts


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--per-level", type=int, default=6)
    parser.add_argument("--ms-level", type=int, action="append",
                        help="Select quantiles only at this MS level, retaining referenced parents")
    args = parser.parse_args()
    if args.per_level < 1:
        parser.error("--per-level must be positive")
    ids, counts = select(args.source, args.per_level, set(args.ms_level) if args.ms_level else None)
    extract(args.source, ids, args.output)
    record = dict(mzml_sha256=digest(args.source), subset_sha256=digest(args.output),
                  source_nonempty_spectra_by_ms_level=counts, selected_ids=ids,
                  selection=f"At most {args.per_level} nonempty spectra per MS level at evenly spaced point-count quantiles, ties by source order, plus referenced precursor spectra",
                  per_level=args.per_level)
    if args.ms_level:
        record["selected_ms_levels"] = sorted(set(args.ms_level))
        record["selection"] = (
            f"At most {args.per_level} nonempty spectra at each requested MS level "
            f"{record['selected_ms_levels']} at evenly spaced point-count quantiles, "
            "ties by source order, plus referenced precursor spectra"
        )
    args.output.with_suffix(".selection.json").write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps(record, indent=2))


if __name__ == "__main__":
    main()
