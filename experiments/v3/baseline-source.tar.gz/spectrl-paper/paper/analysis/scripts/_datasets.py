"""Load, validate, and encode the public benchmark corpus."""

from __future__ import annotations

import hashlib
import json
import warnings
import xml.etree.ElementTree as ET
from dataclasses import dataclass, fields, is_dataclass
from pathlib import Path

import numpy as np
from mzmlpy.run import Mzml

from spectrl import decode_token, encode_spectrum, from_mzmlpy
from spectrl.cv import ION_MOBILITY_ARRAY_TAILS
from spectrl.model import InlineSpectrum, SpectrlCvParam, SpectrlUserParam

HERE = Path(__file__).resolve().parent
PAPER = HERE.parent.parent


@dataclass(frozen=True)
class Dataset:
    key: str
    label: str
    domain: str
    platform: str
    acquisition: str
    path: Path
    manifest_path: str
    source: str
    max_per_level: int | None
    select_spectrum_accession: str | None
    expected: dict


@dataclass
class DatasetRow:
    dataset: Dataset
    source: InlineSpectrum
    spectrum_id: str
    ms_level: int
    n_peaks: int
    lossy_token: str
    lossless_token: str
    lossy_chars: int
    lossless_chars: int
    representation: str
    polarity: str
    has_scan: bool
    has_precursor: bool
    ion_mobility: str
    extra_arrays: tuple[str, ...]
    mz_abs_error_max: float
    intensity_norm_error_max: float


MANIFEST = PAPER / "analysis" / "data" / "corpus.json"


def _load_datasets() -> tuple[Dataset, ...]:
    raw = json.loads(MANIFEST.read_text(encoding="utf-8"))
    return tuple(
        Dataset(
            key=item["key"],
            label=item["label"],
            domain=item["domain"],
            platform=item["platform"],
            acquisition=item["acquisition"],
            path=(PAPER / item["local_path"]).resolve(),
            manifest_path=item["local_path"],
            source=item["source"],
            max_per_level=item.get("max_per_level"),
            select_spectrum_accession=item.get("select_spectrum_accession"),
            expected=item["expected"],
        )
        for item in raw["datasets"]
    )


DATASETS = _load_datasets()
MOBILITY_ACCESSIONS = {"MS:1002476", "MS:1002815", "MS:1001581"}
MOBILITY_ARRAY_ACCESSIONS = set(ION_MOBILITY_ARRAY_TAILS)


def _ms_level(inline) -> int:
    return next(
        (int(p.value) for p in inline.params if p.accession == "MS:1000511"),
        0,
    )


def _ref_groups(mzml: Mzml) -> dict | None:
    groups = list(mzml.referenceable_param_groups)
    if groups and all(hasattr(group, "id") for group in groups):
        return {group.id: group for group in groups}
    return None


def _contains_accession(value, accessions: set[str]) -> bool:
    if isinstance(value, SpectrlCvParam):
        return value.accession in accessions
    if is_dataclass(value):
        return any(_contains_accession(getattr(value, field.name), accessions) for field in fields(value))
    if isinstance(value, (list, tuple)):
        return any(_contains_accession(item, accessions) for item in value)
    return False


def _scalar_mobility(inline) -> bool:
    return _contains_accession(inline, MOBILITY_ACCESSIONS)


def _normalized(value):
    if is_dataclass(value):
        return tuple((field.name, _normalized(getattr(value, field.name))) for field in fields(value))
    if isinstance(value, list):
        return tuple(_normalized(item) for item in value)
    if isinstance(value, dict):
        return {key: _normalized(item) for key, item in value.items()}
    return value


def _assert_metadata_equal(source, decoded, *, lossy=False) -> None:
    for field in (
        "default_array_length",
        "id",
        "params",
        "scans",
        "scan_combination",
        "precursors",
        "products",
        "user_params",
        "source", "acquisition", "processing", "array_params", "array_user_params", "array_units", "extensions", "array_extensions",
    ):
        if _normalized(getattr(source, field)) != _normalized(getattr(decoded, field)):
            raise AssertionError(f"lossless round trip changed {field}: {source.id}")
    history = {key: list(steps) for key, steps in decoded.array_processing.items()}
    if lossy:
        for key, steps in list(history.items()):
            if steps and steps[-1].get("operation") == "spectrl:lossy-encoding":
                event = steps.pop()
                if event.get("revision") != 1 or "encoding" not in event.get("parameters", {}):
                    raise AssertionError("invalid lossy encoding history")
            if not steps and key not in source.array_processing:
                del history[key]
    if _normalized(source.array_processing) != _normalized(history):
        raise AssertionError(f"array processing history changed: {source.id}")



def _select_representative(inlines: list, max_per_level: int | None) -> list:
    """Cap each MS-level group at max_per_level spectra, chosen at evenly
    spaced peak-count quantiles (always including the smallest and largest).
    Ties break on file order, so the selection is deterministic."""
    if max_per_level is None:
        return inlines
    by_level: dict[int, list[int]] = {}
    for idx, inline in enumerate(inlines):
        by_level.setdefault(_ms_level(inline), []).append(idx)
    keep: set[int] = set()
    for indices in by_level.values():
        ordered = sorted(indices, key=lambda i: (len(inlines[i].mz), i))
        k = min(max_per_level, len(ordered))
        positions = {round(j * (len(ordered) - 1) / (k - 1)) for j in range(k)} if k > 1 else {0}
        keep.update(ordered[p] for p in positions)
    return [inline for idx, inline in enumerate(inlines) if idx in keep]


def encode_dataset(dataset: Dataset) -> list[DatasetRow]:
    if not dataset.path.exists():
        raise FileNotFoundError(f"missing public input {dataset.path}. See analysis/data/README.md")
    actual_hash = hashlib.sha256(dataset.path.read_bytes()).hexdigest()
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    entry = next(item for item in manifest["datasets"] if item["key"] == dataset.key)
    if actual_hash != entry["sha256"]:
        raise RuntimeError(f"corpus hash mismatch for {dataset.key}: {actual_hash}")
    for supporting in entry.get("supporting_files", []):
        if hashlib.sha256((PAPER / supporting["path"]).read_bytes()).hexdigest() != supporting["sha256"]:
            raise RuntimeError(f"supporting-file hash mismatch for {dataset.key}: {supporting['path']}")
    if dataset.expected.get("required_document_accessions"):
        present = {node.get("accession") for _, node in ET.iterparse(dataset.path)
                   if node.tag == "{http://psi.hupo.org/ms/mzml}cvParam"}
        for accession in dataset.expected["required_document_accessions"]:
            if accession not in present:
                raise AssertionError(f"{dataset.key}: missing document accession {accession}")

    rows: list[DatasetRow] = []
    with Mzml(str(dataset.path)) as mzml:
        refs = _ref_groups(mzml)
        inlines = []
        for spec in mzml.spectra:
            inline = from_mzmlpy(spec, ref_groups=refs, run=mzml)
            if inline.mz is None or len(inline.mz) == 0:
                continue
            if dataset.select_spectrum_accession and not any(
                p.accession == dataset.select_spectrum_accession for p in inline.params
            ):
                continue
            inlines.append(inline)
        for inline in _select_representative(inlines, dataset.max_per_level):
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                lossy = encode_spectrum(inline)
                lossless = encode_spectrum(inline, lossless=True)
            decoded = decode_token(lossy)
            exact = decode_token(lossless)

            order = np.argsort(inline.mz, kind="stable")
            mz_src = np.asarray(inline.mz, dtype=np.float64)[order]
            int_src = np.asarray(inline.intensity, dtype=np.float64)[order]
            if len(decoded.mz) != len(mz_src):
                raise AssertionError(f"lossy round trip changed peak count: {inline.id}")
            mz_dec = np.asarray(decoded.mz, dtype=np.float64)
            int_dec = np.asarray(decoded.intensity, dtype=np.float64)
            mz_abs_error_max = float(np.max(np.abs(mz_dec - mz_src), initial=0.0))
            intensity_scale = float(np.max(np.abs(int_src), initial=0.0)) or 1.0
            intensity_norm_error_max = float(np.max(np.abs(int_dec - int_src) / intensity_scale, initial=0.0))
            for name in ("mz", "intensity", "charge"):
                original = getattr(inline, name)
                recovered = getattr(exact, name)
                if original is not None and (original.dtype != recovered.dtype or original[order].tobytes() != recovered.tobytes()):
                    raise AssertionError(f"lossless core representation changed: {name}")
            np.testing.assert_array_equal(exact.mz, mz_src)
            np.testing.assert_array_equal(exact.intensity, int_src)
            if inline.charge is not None:
                np.testing.assert_array_equal(exact.charge, np.asarray(inline.charge)[order])
            if set(exact.extra_arrays) != set(inline.extra_arrays):
                raise AssertionError(f"lossless round trip changed auxiliary arrays: {inline.id}")
            for name, array in inline.extra_arrays.items():
                np.testing.assert_array_equal(exact.extra_arrays[name], np.asarray(array)[order])
                if exact.extra_arrays[name].dtype != np.asarray(array).dtype or exact.extra_arrays[name].tobytes() != np.asarray(array)[order].tobytes():
                    raise AssertionError(f"lossless round trip changed {name} dtype: {inline.id}")
            _assert_metadata_equal(inline, exact)
            accessions = {p.accession for p in inline.params}
            representation = (
                "centroid" if "MS:1000127" in accessions else "profile" if "MS:1000128" in accessions else "unknown"
            )
            polarity = (
                "positive" if "MS:1000130" in accessions else "negative" if "MS:1000129" in accessions else "unknown"
            )
            mobility = (
                "array"
                if set(inline.extra_arrays) & MOBILITY_ARRAY_ACCESSIONS
                else "scalar"
                if _scalar_mobility(inline)
                else "none"
            )
            rows.append(
                DatasetRow(
                    dataset=dataset,
                    source=inline,
                    spectrum_id=inline.id or "",
                    ms_level=_ms_level(inline),
                    n_peaks=len(mz_src),
                    lossy_token=lossy,
                    lossless_token=lossless,
                    lossy_chars=len(lossy),
                    lossless_chars=len(lossless),
                    representation=representation,
                    polarity=polarity,
                    has_scan=bool(inline.scans),
                    has_precursor=bool(inline.precursors),
                    ion_mobility=mobility,
                    extra_arrays=tuple(sorted(inline.extra_arrays)),
                    mz_abs_error_max=mz_abs_error_max,
                    intensity_norm_error_max=intensity_norm_error_max,
                )
            )
    if "n_spectra" in dataset.expected and len(rows) != dataset.expected["n_spectra"]:
        raise AssertionError(f"{dataset.key}: unexpected spectrum count {len(rows)}")
    for level, count in dataset.expected.get("n_spectra_by_ms_level", {}).items():
        if sum(row.ms_level == int(level) for row in rows) != count:
            raise AssertionError(f"{dataset.key}: unexpected MS{level} spectrum count")
    levels = sorted({row.ms_level for row in rows})
    if levels != dataset.expected["ms_levels"]:
        raise AssertionError(f"{dataset.key}: expected MS levels {dataset.expected['ms_levels']}, got {levels}")
    representations = {row.representation for row in rows}
    if dataset.expected["representation"] not in representations:
        raise AssertionError(f"{dataset.key}: missing {dataset.expected['representation']} spectra")
    if dataset.expected.get("scalar_ion_mobility") and not any(row.ion_mobility == "scalar" for row in rows):
        raise AssertionError(f"{dataset.key}: expected scalar ion mobility metadata")
    if dataset.expected.get("array_ion_mobility") and not any(row.ion_mobility == "array" for row in rows):
        raise AssertionError(f"{dataset.key}: expected per-peak ion mobility")
    for accession in dataset.expected.get("required_spectrum_accessions", []):
        if not all(any(p.accession == accession for p in row.source.params) for row in rows):
            raise AssertionError(f"{dataset.key}: missing spectrum type {accession}")
    for accession in dataset.expected.get("required_activation_accessions", []):
        if not any(_contains_accession(row.source.precursors, {accession}) for row in rows):
            raise AssertionError(f"{dataset.key}: missing activation accession {accession}")
    return rows


def encode_all() -> list[DatasetRow]:
    return [row for dataset in DATASETS for row in encode_dataset(dataset)]


def inputs() -> list[str]:
    manifest = json.loads(MANIFEST.read_text())
    supporting = [item["path"] for dataset in manifest["datasets"]
                  for item in dataset.get("supporting_files", [])]
    return ["analysis/data/corpus.json", *[dataset.manifest_path for dataset in DATASETS], *supporting]
