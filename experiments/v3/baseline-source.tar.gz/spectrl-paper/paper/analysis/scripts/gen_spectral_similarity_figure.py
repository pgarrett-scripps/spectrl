"""Plot selected source and decoded spectra with paired intensity residuals."""

import math

import matplotlib
import numpy as np

from _assets import record
from _datasets import encode_all
from _spectral_similarity import PAPER, analysis_inputs, analyze, paired_arrays

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import FormatStrFormatter, MaxNLocator

SOURCE = "#64748b"
LOSSLESS = "#2563eb"
DEFAULT = "#c45a10"


def main():
    rows = encode_all()
    report = analyze(rows)
    lookup = {(row.dataset.key, row.spectrum_id): row for row in rows}
    scores = {(m["dataset"], m["spectrum_id"]): m for m in report["measurements"]
              if m["mode"] == "default"}
    examples = report["examples"]
    nrows = math.ceil(len(examples) / 2)
    with plt.rc_context({"font.size": 8, "axes.labelsize": 8, "axes.titlesize": 9,
                         "xtick.labelsize": 7, "ytick.labelsize": 7}):
        fig = plt.figure(figsize=(7.1, 3.2 * nrows + 0.4), dpi=400)
        outer = fig.add_gridspec(nrows, 2, hspace=0.62, wspace=0.35,
                                left=0.09, right=0.98, bottom=0.09, top=0.88)
        for index, example in enumerate(examples):
            identity = (example["dataset"], example["spectrum_id"])
            row, measured = lookup[identity], scores[identity]
            mz, source, lossy_mz, lossy = paired_arrays(row, "default")
            _, _, exact_mz, exact = paired_arrays(row, "lossless")
            scale = float(np.max(source))
            grid = outer[index // 2, index % 2].subgridspec(2, 1, height_ratios=(2.5, 1), hspace=0.08)
            ax = fig.add_subplot(grid[0])
            residual = fig.add_subplot(grid[1], sharex=ax)
            for x, y, color, width, style in (
                (mz, source, SOURCE, 1.5, "solid"),
                (exact_mz, exact, LOSSLESS, 1.0, "dashed"),
                (lossy_mz, lossy, DEFAULT, 0.55, "solid"),
            ):
                if row.representation == "centroid":
                    ax.vlines(x, 0, 100 * y / scale, color=color, lw=width, linestyles=style)
                else:
                    ax.plot(x, 100 * y / scale, color=color, lw=width, ls=style)
            ax.set_ylim(0, 112)
            ax.set_ylabel("Relative intensity (%)")
            ax.tick_params(labelbottom=False)
            title = example["criteria"][0]
            ax.set_title(f"{chr(65 + index)}  {title}\n{row.dataset.key}, MS{row.ms_level}",
                         loc="left", pad=7)
            ax.text(0.98, 0.96, f"Default SA = {measured['spectral_angle']:.8f}\nLossless SA = 1",
                    ha="right", va="top", transform=ax.transAxes, fontsize=7,
                    bbox={"facecolor": "white", "alpha": 0.9, "edgecolor": "none", "pad": 1})
            difference = 100 * (lossy - source) / scale
            limit = max(float(np.max(np.abs(difference))) * 1.12, 1e-8)
            residual.axhline(0, color=LOSSLESS, lw=0.8, ls="--")
            if row.representation == "centroid":
                residual.vlines(mz, 0, difference, color=DEFAULT, lw=0.6)
            else:
                residual.plot(mz, difference, color=DEFAULT, lw=0.6)
            residual.set_ylim(-limit, limit)
            residual.set_ylabel("Residual\n(% base peak)", fontsize=7)
            residual.set_xlabel("m/z")
            residual.yaxis.set_major_formatter(FormatStrFormatter("%.3g"))
            residual.yaxis.set_major_locator(MaxNLocator(nbins=3))
            for axis in (ax, residual):
                axis.spines[["top", "right"]].set_visible(False)
                axis.margins(x=0.02)
        handles = [Line2D([], [], color=SOURCE, lw=1.5, label="Source"),
                   Line2D([], [], color=LOSSLESS, lw=1, ls="--", label="Decoded lossless"),
                   Line2D([], [], color=DEFAULT, lw=0.8, label="Decoded default (lossy)")]
        fig.legend(handles=handles, loc="upper center", ncol=3, frameon=False,
                   bbox_to_anchor=(0.53, 0.98), fontsize=8)
        output = "figures/spectral_similarity.png"
        fig.savefig(PAPER / output, metadata={"Software": None}, bbox_inches="tight", pad_inches=0.08)
        plt.close(fig)
    record("fig.spectral_similarity", output, kind="figure", inputs=analysis_inputs(),
           desc="Source, lossless, and default spectra with intensity residuals for representative centroid, profile, and top-down spectra plus the lowest spectral angle")
    print(f"Wrote {output}")


if __name__ == "__main__":
    main()
