#!/usr/bin/env python3
"""Record paired package timings outside deterministic asset builds.

Build js/dist first, then run: uv run python scripts/bench_timing.py
The table generator summarizes the saved report without rerunning timings.
"""
from __future__ import annotations

import hashlib
import json
import os
import platform
import subprocess
import sys
import time
import warnings
from datetime import datetime, timezone
from importlib.metadata import version
from pathlib import Path

PAPER = Path(__file__).resolve().parents[2]
REPO = PAPER.parent
sys.path.insert(0, str(REPO / "src"))

from _datasets import encode_all, inputs
from _interop import model_json
from spectrl import decode_token, encode_spectrum
from spectrl.codecs.numpress import active_backend

REPEATS = 5
WARMUPS = 2


def measure(fn):
    start = time.perf_counter_ns()
    result = fn()
    elapsed = (time.perf_counter_ns() - start) / 1e6
    return elapsed, result


def main():
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        rows = encode_all()
        print(f"Loaded {len(rows)} selected spectra", flush=True)
        measurements = []
        for lossless in (False, True):
            mode = "Lossless" if lossless else "Default"
            tokens = [encode_spectrum(row.source, lossless=lossless) for row in rows]
            samples = [{"encode_ms": [], "decode_ms": []} for _ in rows]
            for iteration in range(WARMUPS + REPEATS):
                for row, token, sample in zip(rows, tokens, samples, strict=True):
                    enc, _ = measure(lambda: encode_spectrum(row.source, lossless=lossless))
                    dec, _ = measure(lambda: decode_token(token))
                    if iteration >= WARMUPS:
                        sample["encode_ms"].append(enc)
                        sample["decode_ms"].append(dec)
            measurements.extend({"package": "Python", "mode": mode,
                                 "dataset": row.dataset.key, "spectrum_id": row.spectrum_id,
                                 "points": row.n_peaks, **sample}
                                for row, sample in zip(rows, samples, strict=True))
            print(f"Python {mode} complete", flush=True)
    request = {"warmups": WARMUPS, "repeats": REPEATS,
               "rows": [{"dataset": row.dataset.key, "spectrum_id": row.spectrum_id,
                         "points": row.n_peaks, "source": model_json(row.source)} for row in rows]}
    proc = subprocess.run(["node", str(Path(__file__).with_suffix(".mjs"))],
                          input=json.dumps(request, allow_nan=False), text=True,
                          capture_output=True, check=True, cwd=REPO)
    js = json.loads(proc.stdout)
    measurements.extend(js["measurements"])
    cpu = next(line.split(":", 1)[1].strip() for line in Path("/proc/cpuinfo").read_text().splitlines()
               if line.startswith("model name"))
    paths = [PAPER / path for path in inputs()]
    paths += list((REPO / "src/spectrl").rglob("*.py"))
    paths += list((REPO / "js/src").rglob("*.ts"))
    paths += list((REPO / "js/dist").rglob("*.js"))
    paths += [Path(__file__), Path(__file__).with_suffix(".mjs"),
              PAPER / "analysis/scripts/_datasets.py", PAPER / "analysis/scripts/_interop.py",
              PAPER / "analysis/uv.lock", REPO / "js/package-lock.json"]
    report = {"measured_at": datetime.now(timezone.utc).isoformat(),
              "environment": {"cpu": cpu, "os": platform.platform(),
                              "python": platform.python_version(), "python_package": version("spectrl"),
                              "numpress_backend": active_backend(), **js["environment"]},
              "warmups": WARMUPS, "repeats": REPEATS,
              "inputs": {os.path.relpath(path, PAPER): hashlib.sha256(path.read_bytes()).hexdigest()
                         for path in sorted(set(paths))},
              "measurements": measurements}
    output = PAPER / "analysis/reports/timing.json"
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, indent=2) + "\n")
    print(f"Wrote {output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
