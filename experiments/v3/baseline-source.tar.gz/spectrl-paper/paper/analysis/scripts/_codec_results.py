"""Read the explicitly measured v3 compression report and reject stale inputs."""
import hashlib
import json
from pathlib import Path
from statistics import median

PAPER = Path(__file__).resolve().parents[2]
REPORT = PAPER / 'analysis/reports/compression-v3.json'


def load():
    report = json.loads(REPORT.read_text())
    for name, expected in report['inputs'].items():
        if hashlib.sha256((PAPER / name).read_bytes()).hexdigest() != expected:
            raise RuntimeError(f'Compression input changed: {name}. Rerun bench_compression.py explicitly.')
    return report


def add_stats(stats):
    report = load()
    arrays = report['arrays']
    rows = report['spectra']
    for dtype in ('float32', 'float64'):
        stats.add(f'compression.n_{dtype}', sum(a['dtype'] == dtype for a in arrays), fmt=',', desc=f'Corpus arrays with native {dtype} representation', sign='+')
    total = lambda profile: sum(r['profiles'][profile]['token_bytes'] for r in rows)
    stats.add('compression.n_arrays', len(arrays), fmt=',', desc='Native numeric arrays evaluated for lossless compression', sign='+')
    stats.add('compression.delta_token_saving_pct', 100 * (1 - total('v3-adaptive') / total('psi-adaptive')),
              fmt='.1f', desc='Aggregate complete-token reduction versus adaptive supported PSI lossless pipelines', sign='+')
    stats.add('compression.dictionary_token_saving_pct', 100 * (1 - total('v3-adaptive') / total('without-dictionary')),
              fmt='.1f', desc='Aggregate complete-token reduction from including dictionary encoding', between=(0, 100))
    for role in ('mz', 'intensity'):
        subset = [a for a in arrays if a['array'] == role]
        psi = ['raw-zlib', 'raw-zstd', 'shuffle-zstd', 'dictionary-zstd', 'raw-none']
        prior = sum(min((a['pipelines'][p] for p in psi), key=lambda x: x['descriptor_cost'])['blob_bytes'] for a in subset)
        after = sum(min(a['pipelines'].values(), key=lambda x: x['descriptor_cost'])['blob_bytes'] for a in subset)
        stats.add(f'compression.{role}_saving_pct', 100 * (1 - after / prior), fmt='.1f',
                  desc=f'Aggregate {role} payload reduction from adding modular-delta candidates', between=(0, 100))
    stats.add('compression.n_mobility_arrays', sum(a['array'].startswith('MS:') for a in arrays), fmt=',',
              desc='Additional accession-identified arrays in the selected corpus', sign='+')
    stats.add('compression.repeats', report['repeats'], fmt=',', desc='Timed repetitions per array and pipeline', sign='+')
