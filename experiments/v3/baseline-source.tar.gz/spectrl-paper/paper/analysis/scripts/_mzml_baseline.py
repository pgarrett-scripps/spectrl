"""Information-matched single-spectrum mzML documents with identical PSI blob bytes.

This baseline includes only the context referenced by the selected spectrum.
It never represents the spectrl modular-delta codec as a PSI-MS codec.
"""

from __future__ import annotations

import base64
import gzip
import re
import struct
import xml.etree.ElementTree as ET
import zlib
from pathlib import Path

import copy
from functools import lru_cache
from lxml import etree
import numpy as np

import cbor2

from spectrl import decode_token
from spectrl.cbor_format import read_token_document, token_checksum
from spectrl.cv import decode_unit_tail
from spectrl.header import (
    DESC_ARRAY,
    DESC_COMP,
    DESC_DATA,
    DESC_NAME,
    DESC_TYPE,
    DESC_UNIT,
)
from spectrl.model import SpectrlCvParam, SpectrlUserParam
from spectrl.token import MAGIC, b64url_decode, b64url_encode

from _datasets import DATASETS

# Official PSI-MS names for terms the corpus files do not spell out themselves
# (none of them ship numpress-compressed, which is exactly why the baseline
# has to be synthesized). Names are the published ones; mzML must write them.
_FALLBACK_NAMES = {
    "MS:1000523": "64-bit float",
    "MS:1000521": "32-bit float",
    "MS:1000519": "32-bit integer",
    "MS:1000574": "zlib compression",
    "MS:1002746": "MS-Numpress linear prediction compression followed by zlib compression",
    "MS:1002748": "MS-Numpress short logged float compression followed by zlib compression",
    "MS:1002747": "MS-Numpress positive integer compression followed by zlib compression",
    "MS:1000786": "non-standard data array",
    "MS:1000514": "m/z array",
    "MS:1000515": "intensity array",
    "MS:1000516": "charge array",
}

_CV_RE = re.compile(rb"<cvParam\b[^>]*/>")
_ATTR_RE = re.compile(rb'(\w+)="([^"]*)"')


def _harvest_cv_names(paths: list[Path], limit: int = 4_000_000) -> tuple[dict, dict]:
    """accession -> name, and unitAccession -> (unitName, unitCvRef), from the
    corpus's real files, so the XML spells names the way producers do."""
    names: dict[str, str] = {}
    units: dict[str, tuple[str, str]] = {}
    for path in paths:
        raw = path.read_bytes()[:limit]
        for m in _CV_RE.finditer(raw):
            a = {k.decode(): v.decode() for k, v in _ATTR_RE.findall(m.group(0))}
            if "accession" in a and "name" in a:
                names.setdefault(a["accession"], a["name"])
            if a.get("unitAccession"):
                units.setdefault(a["unitAccession"], (a.get("unitName", ""), a.get("unitCvRef", "UO")))
    return names, units


_NAMES: dict[str, str] = {}
_UNITS: dict[str, tuple[str, str]] = {}


def _ensure_names() -> None:
    if not _NAMES:
        names, units = _harvest_cv_names([d.path for d in DATASETS])
        obo = (Path(__file__).resolve().parents[1] / 'data/standards/psi-ms.obo').read_text()
        official = dict(re.findall(r'\nid: (MS:\d+)\nname: ([^\n]+)', obo))
        _NAMES.update({**_FALLBACK_NAMES, **names, **official})
        _UNITS.update(units)


def _xml_escape(s: str) -> str:
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")


def _cv_xml(p: SpectrlCvParam) -> str:
    ref = p.accession.split(":", 1)[0]
    out = f'<cvParam cvRef="{ref}" accession="{p.accession}" name="{_xml_escape(_NAMES.get(p.accession, p.accession))}"'
    # Empty string is a value in both models; only None is a flag parameter.
    if p.value is not None:
        out += f' value="{_xml_escape(str(p.value))}"'
    if p.unit_accession:
        uname, _ = _UNITS.get(p.unit_accession, ("", ""))
        uref = p.unit_accession.split(":", 1)[0]
        out += f' unitAccession="{p.unit_accession}" unitName="{_xml_escape(uname)}" unitCvRef="{uref}"'
    return out + "/>"


def _user_xml(u: SpectrlUserParam) -> str:
    out = f'<userParam name="{_xml_escape(u.name)}"'
    if u.type is not None:
        out += f' type="{_xml_escape(u.type)}"'
    if u.value is not None:
        out += f' value="{_xml_escape(str(u.value))}"'
    if u.unit_accession:
        uname, _ = _UNITS.get(u.unit_accession, ("", ""))
        uref = u.unit_accession.split(":", 1)[0]
        out += f' unitAccession="{u.unit_accession}" unitName="{_xml_escape(uname)}" unitCvRef="{uref}"'
    return out + "/>"


def _accession(tail: int) -> str:
    return f"MS:{tail:07d}"


class MatchError(AssertionError):
    """The XML must carry the same supported scientific information."""


def _parameters(parent, record):
    for p in record.get('params', []):
        parent.append(ET.fromstring(_cv_xml(p)))
    for p in record.get('user_params', []):
        parent.append(ET.fromstring(_user_xml(p)))


def _group(parent, tag, value):
    if value is None:
        return None
    node = ET.SubElement(parent, tag)
    _parameters(node, {'params': value.params, 'user_params': value.user_params})
    return node


class _Context:
    def __init__(self):
        self.sources = {}
        self.instruments = {}
        self.software = {}
        self.processing = {}

    def source(self, record):
        if not record:
            return {}
        attrs = {}
        if record.get('spectrum_ref'):
            attrs['externalSpectrumID'] = record['spectrum_ref']
        if record.get('id'):
            key = record['id']
            if key not in self.sources:
                node = ET.Element('sourceFile', {k: record[k] for k in ('id', 'name', 'location') if k in record})
                _parameters(node, record)
                self.sources[key] = node
            attrs['sourceFileRef'] = key
        if record.get('external_ids'):
            raise MatchError('external IDs require an explicit mzML mapping')
        return attrs

    def software_ref(self, record):
        if record is None:
            raise MatchError('mzML processing requires software context')
        key = record.get('id', f'software{len(self.software)}')
        if key not in self.software:
            node = ET.Element('software', {'id': key, 'version': record.get('version', '')})
            _parameters(node, record)
            self.software[key] = node
        return key

    def acquisition(self, record):
        if not record:
            return None
        value = record['instrument']
        key = value.get('id', f'instrument{len(self.instruments)}')
        if key not in self.instruments:
            node = ET.Element('instrumentConfiguration', {'id': key})
            _parameters(node, value)
            components = value.get('components', [])
            if components:
                collection = ET.SubElement(node, 'componentList', {'count': str(len(components))})
                for c in components:
                    part = ET.SubElement(collection, c['kind'], {'order': str(c['order'])})
                    _parameters(part, c)
            if value.get('software'):
                ET.SubElement(node, 'softwareRef', {'ref': self.software_ref(value['software'])})
            self.instruments[key] = node
        return key

    def processing_ref(self, records):
        key = f'processing{len(self.processing)}'
        node = ET.Element('dataProcessing', {'id': key})
        for i, record in enumerate(records):
            if record.get('operation'):
                raise MatchError('custom processing operation has no declared mzML mapping')
            method = ET.SubElement(node, 'processingMethod', {'order': str(i), 'softwareRef': self.software_ref(record.get('software'))})
            _parameters(method, record)
        self.processing[key] = node
        return key


def _clean_encoding_history(dec, descriptors):
    import copy
    dec = copy.deepcopy(dec)
    for desc in descriptors:
        if desc[7] != 1:
            continue
        tail = desc[1]
        key = {1000514: 'mz', 1000515: 'intensity', 1000516: 'charge'}.get(tail, desc.get(4, f'MS:{tail:07d}'))
        records = dec.array_processing[key]
        assert records[-1]['operation'] == 'spectrl:lossy-encoding'
        records.pop()
        if not records:
            del dec.array_processing[key]
    return dec


def _verify(xml, expected, descriptors):
    """Independently import the XML and compare all scoped metadata and blob bytes."""
    from mzmlpy.spectra import Spectrum
    from spectrl import from_mzmlpy
    from spectrl.mzml_context import MzMLContext
    from _datasets import _assert_metadata_equal
    root = ET.fromstring(xml)
    for node in root.iter():
        node.tag = node.tag.rsplit('}', 1)[-1]
    def records(tag):
        return {n.get('id'): n for n in root.findall(f'.//{tag}')}
    # Context methods read namespace-qualified header nodes.
    import copy
    header = copy.deepcopy(root)
    namespace = 'http://psi.hupo.org/ms/mzml'
    for node in header.iter():
        node.tag = '{' + namespace + '}' + node.tag
    def qualified(tag):
        return {n.get('id'): n for n in header.findall(f'.//{{{namespace}}}{tag}')}
    run = root.find('run')
    collection = run.find('spectrumList')
    context = MzMLContext({}, qualified('instrumentConfiguration'), qualified('software'),
                          qualified('dataProcessing'), qualified('sourceFile'), dict(run.attrib), dict(collection.attrib))
    element = collection.find('spectrum')
    for node, desc in zip(element.findall('./binaryDataArrayList/binaryDataArray'), descriptors, strict=True):
        if base64.b64decode(node.findtext('binary'), validate=True) != desc[5]:
            raise MatchError('XML array blob differs from the token')
    # pynumpress 0.0.9 rejects valid one-value linear streams. Decode that
    # documented case directly before independently importing the metadata.
    for node, desc in zip(element.findall('./binaryDataArrayList/binaryDataArray'), descriptors, strict=True):
        if desc[2][0] == 4 and expected.default_array_length == 1:
            from spectrl.pipeline import COMPRESSORS, operation
            compressor, params = operation(COMPRESSORS, desc[3])
            raw = compressor.decode(desc[5], 80, params)
            if len(raw) != 12:
                raise MatchError('invalid single-value linear stream')
            value = struct.unpack('<I', raw[8:])[0] / struct.unpack('>d', raw[:8])[0]
            for cv in node.findall('cvParam'):
                if cv.get('accession') in {'MS:1002312', 'MS:1002746', 'MS:1003783'}:
                    cv.set('accession', 'MS:1000576')
                    cv.set('name', 'no compression')
            node.find('binary').text = base64.b64encode(struct.pack('<d', value)).decode()
    # mzmlpy 0.6.0 interprets dictionary cardinality as output count.
    # Decode with a separate byte-lane implementation, then import raw arrays.
    # The original XML and identical compressed blobs were checked above.
    for node, desc in zip(element.findall('./binaryDataArrayList/binaryDataArray'), descriptors, strict=True):
        if desc[2][0] == 2:
            import zstandard
            raw = zstandard.ZstdDecompressor().decompress(desc[5])
            offset, count = struct.unpack('<QQ', raw[:16])
            width = 8 if desc[0] == 1000523 else 4
            iw = next(w for w in (1, 2, 4, 8) if count <= 2 ** (8 * w))
            if offset != 16 + count * width:
                raise MatchError('invalid dictionary offset')
            def lanes(data, w):
                n = len(data) // w
                return b''.join(bytes(data[lane * n + i] for lane in range(w)) for i in range(n))
            values = lanes(raw[16:offset], width)
            indices = lanes(raw[offset:], iw)
            uncompressed = b''.join(values[j * width:(j + 1) * width] for j in
                (int.from_bytes(indices[i:i + iw], 'little') for i in range(0, len(indices), iw)))
            if len(uncompressed) != width * expected.default_array_length:
                raise MatchError('invalid dictionary output count')
            for cv in node.findall('cvParam'):
                if cv.get('accession') == 'MS:1003782':
                    cv.set('accession', 'MS:1000576')
                    cv.set('name', 'no compression')
            node.find('binary').text = base64.b64encode(uncompressed).decode()
    actual = from_mzmlpy(Spectrum(element), run=context)
    for key in ('mz', 'intensity', 'charge'):
        left, right = getattr(actual, key), getattr(expected, key)
        if left is not None:
            np.testing.assert_array_equal(left, right)
    for key, value in actual.extra_arrays.items():
        np.testing.assert_array_equal(value, expected.extra_arrays[key])
    # XML scalar lexical forms are strings. Compare them as strings in both models.
    from dataclasses import fields, is_dataclass
    def lexical(value):
        if isinstance(value, (SpectrlCvParam, SpectrlUserParam)):
            return {f.name: None if getattr(value, f.name) is None else str(getattr(value, f.name)) for f in fields(value)}
        if is_dataclass(value):
            return {f.name: lexical(getattr(value, f.name)) for f in fields(value) if f.name not in {'mz', 'intensity', 'charge', 'extra_arrays', 'checksum', 'format_version'}}
        if isinstance(value, dict):
            return {k: lexical(v) for k, v in value.items()}
        if isinstance(value, list):
            return [lexical(v) for v in value]
        return value
    if lexical(actual) != lexical(expected):
        left, right = lexical(actual), lexical(expected)
        changed = [k for k in left if left[k] != right[k]]
        raise MatchError(f'XML metadata differs in {changed}: {expected.id}')


def mzml_element(token):
    """A compact single-spectrum mzML document with relevant resolved context."""
    from spectrl.pipeline import psi_alias
    from spectrl.header import _decode_param_map, _decode_user_params
    from spectrl.context import decode_record
    _ensure_names()
    doc, _ = read_token_document(token)
    descriptors = doc.get(6, [])
    dec = _clean_encoding_history(decode_token(token), descriptors)
    if dec.id is None or dec.extensions or dec.array_extensions:
        raise MatchError('baseline requires an ID and no unmapped extensions')
    context = _Context()
    spectrum = ET.Element('spectrum', {'id': dec.id, 'index': '0', 'defaultArrayLength': str(dec.default_array_length)})
    _parameters(spectrum, {'params': dec.params, 'user_params': dec.user_params})
    spectrum.attrib.update(context.source(dec.source))
    if dec.scans or dec.scan_combination:
        scans = ET.SubElement(spectrum, 'scanList', {'count': str(len(dec.scans))})
        if dec.scan_combination:
            scans.append(ET.fromstring(_cv_xml(dec.scan_combination)))
        for scan in dec.scans:
            node = ET.SubElement(scans, 'scan', context.source(scan.source))
            instrument = context.acquisition(scan.acquisition)
            if instrument:
                node.set('instrumentConfigurationRef', instrument)
            _parameters(node, {'params': scan.params, 'user_params': scan.user_params})
            if scan.windows:
                windows = ET.SubElement(node, 'scanWindowList', {'count': str(len(scan.windows))})
                for window in scan.windows:
                    _group(windows, 'scanWindow', window)
    if dec.precursors:
        precursors = ET.SubElement(spectrum, 'precursorList', {'count': str(len(dec.precursors))})
        for precursor in dec.precursors:
            node = ET.SubElement(precursors, 'precursor', context.source(precursor.source))
            _group(node, 'isolationWindow', precursor.isolation_window)
            if precursor.selected_ions:
                ions = ET.SubElement(node, 'selectedIonList', {'count': str(len(precursor.selected_ions))})
                for ion in precursor.selected_ions:
                    _group(ions, 'selectedIon', ion)
            _group(node, 'activation', precursor.activation)
    if dec.products:
        products = ET.SubElement(spectrum, 'productList', {'count': str(len(dec.products))})
        for product in dec.products:
            _group(ET.SubElement(products, 'product'), 'isolationWindow', product.isolation_window)
    arrays = ET.SubElement(spectrum, 'binaryDataArrayList', {'count': str(len(descriptors))})
    for desc in descriptors:
        alias = psi_alias(desc[2], desc[3])
        if alias is None:
            raise MatchError('container comparison requires a PSI alias')
        b64 = base64.b64encode(desc[5]).decode()
        node = ET.SubElement(arrays, 'binaryDataArray', {'encodedLength': str(len(b64))})
        if desc.get(10):
            node.set('dataProcessingRef', context.processing_ref([decode_record(x, 'processing') for x in desc[10]]))
        values = [SpectrlCvParam(_accession(desc[0])), SpectrlCvParam(alias),
                  SpectrlCvParam(_accession(desc[1]), desc.get(4), decode_unit_tail(desc[6]) if 6 in desc else None)]
        values += _decode_param_map(desc.get(8, []))
        _parameters(node, {'params': values, 'user_params': _decode_user_params(desc.get(9, []))})
        ET.SubElement(node, 'binary').text = b64
    instrument = context.acquisition(dec.acquisition)
    processing = context.processing_ref(dec.processing)
    root = ET.Element('mzML', {'xmlns': 'http://psi.hupo.org/ms/mzml', 'version': '1.1.0'})
    cvlist = ET.SubElement(root, 'cvList', {'count': '2'})
    ET.SubElement(cvlist, 'cv', {'id': 'MS', 'fullName': 'PSI-MS', 'URI': 'https://purl.obolibrary.org/obo/ms.obo'})
    ET.SubElement(cvlist, 'cv', {'id': 'UO', 'fullName': 'Unit Ontology', 'URI': 'https://purl.obolibrary.org/obo/uo.obo'})
    description = ET.SubElement(root, 'fileDescription')
    ET.SubElement(description, 'fileContent')
    if context.sources:
        collection = ET.SubElement(description, 'sourceFileList', {'count': str(len(context.sources))})
        collection.extend(context.sources.values())
    for tag, records in [('softwareList', context.software), ('instrumentConfigurationList', context.instruments), ('dataProcessingList', context.processing)]:
        collection = ET.SubElement(root, tag, {'count': str(len(records))})
        collection.extend(records.values())
    run = ET.SubElement(root, 'run', {'id': 'selected-spectrum'})
    if instrument:
        run.set('defaultInstrumentConfigurationRef', instrument)
    spectra = ET.SubElement(run, 'spectrumList', {'count': '1', 'defaultDataProcessingRef': processing})
    spectra.append(spectrum)
    xml = ET.tostring(root, encoding='unicode', short_empty_elements=True)
    validate_schema(xml)
    _verify(xml, dec, descriptors)
    return xml


def mzml_token(xml):
    """Size-only XML comparator in the same text framing, not a spectrl payload."""
    packed = gzip.compress(xml.encode(), compresslevel=9, mtime=0)
    body = f'{MAGIC}.g.{b64url_encode(packed)}'
    return f'{body}.{token_checksum(body)}'


@lru_cache(maxsize=1)
def schema():
    path = Path(__file__).resolve().parents[1] / 'data/standards/mzML1.1.0.xsd'
    return etree.XMLSchema(etree.parse(str(path)))


def validate_schema(xml):
    schema().assertValid(etree.fromstring(xml.encode('utf-8')))


def matched_source(row):
    """Make references external to a standalone spectrum in both containers."""
    source = copy.deepcopy(row.source)
    for item in [*source.scans, *source.precursors]:
        if item.source and item.source.get('spectrum_ref') and not item.source.get('id'):
            item.source = {
                'id': 'benchmark_mzml_source',
                'name': row.dataset.path.name,
                'location': str(Path(row.dataset.manifest_path).parent),
                'params': [SpectrlCvParam('MS:1000584')],
                **item.source,
            }
    from urllib.parse import quote
    from dataclasses import fields, is_dataclass
    def normalize(value):
        if isinstance(value, dict):
            if 'location' in value:
                original = value['location']
                uri = original
                if re.match(r'^file://[A-Za-z]:', uri):
                    uri = 'file:///' + uri[7:].replace(chr(92), '/')
                encoded = quote(uri, safe=":/?#[]@!$&'()*+,=%")
                if encoded != original:
                    value['location'] = encoded
                    value.setdefault('user_params', []).append(SpectrlUserParam(
                        'benchmark:original-source-location', original))
            for child in list(value.values()):
                normalize(child)
        elif is_dataclass(value):
            for field in fields(value):
                normalize(getattr(value, field.name))
        elif isinstance(value, list):
            for child in value:
                normalize(child)
    normalize(source)
    records = []
    def collect(value, kind=''):
        if isinstance(value, dict):
            if kind in ('source', 'instrument', 'software') and value.get('id'):
                records.append((kind, value))
            for key, child in value.items():
                collect(child, key)
        elif is_dataclass(value):
            for field in fields(value):
                collect(getattr(value, field.name), field.name)
        elif isinstance(value, list):
            for child in value:
                collect(child, kind)
    collect(source)
    id_kinds = {}
    for kind, record in records:
        id_kinds.setdefault(record['id'], set()).add(kind)
    seen_records = set()
    for kind, record in records:
        if id(record) in seen_records:
            continue
        seen_records.add(id(record))
        original = record['id']
        if len(id_kinds[original]) > 1 or not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_.-]*', original):
            record['id'] = 'benchmark_' + kind + '_' + original.encode().hex()
            record.setdefault('user_params', []).append(SpectrlUserParam('benchmark:original-id', original))
    return source
