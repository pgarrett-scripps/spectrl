#!/usr/bin/env node
// Decode Python tokens and independently encode source models in both modes.

import { createInterface } from "node:readline"
import { decodeToken, encodeSpectrum } from "../../../js/dist/index.js"

import { installZstd } from "../../../js/dist/zstd.js"
installZstd()

const types = { float64: Float64Array, float32: Float32Array, int32: Int32Array }

function array(value) {
  if (value === null) return null
  const Type = types[value.dtype]
  if (!Type) throw new Error(`Unsupported source dtype: ${value.dtype}`)
  return new Type(value.values)
}

function model(value) {
  return {
    ...value,
    mz: array(value.mz),
    intensity: array(value.intensity),
    charge: array(value.charge),
    extraArrays: Object.fromEntries(Object.entries(value.extraArrays).map(([k, v]) => [k, array(v)])),
  }
}

function json(value) {
  if (typeof value === "bigint") {
    const number = Number(value)
    if (!Number.isSafeInteger(number) || BigInt(number) !== value) {
      throw new Error(`Metadata integer cannot be represented exactly in JSON: ${value}`)
    }
    return number
  }
  if (ArrayBuffer.isView(value)) {
    const dtype = value instanceof Int32Array ? "int32" : value instanceof Float32Array ? "float32" : "float64"
    return { dtype, values: Array.from(value) }
  }
  if (Array.isArray(value)) return value.map(json)
  if (value !== null && typeof value === "object") {
    return Object.fromEntries(Object.entries(value)
      .filter(([k]) => k !== "checksum" && k !== "formatVersion")
      .map(([k, v]) => [k, json(v)]))
  }
  return value
}

for await (const line of createInterface({ input: process.stdin, crlfDelay: Infinity })) {
  if (!line) continue
  const request = JSON.parse(line)
  const source = model(request.source)
  const tokens = [false, true].map(lossless => encodeSpectrum(source, { lossless, quiet: true }))
  const decoded = request.tokens.map(token => json(decodeToken(token)))
  process.stdout.write(JSON.stringify({ decoded, tokens }) + "\n")
}
