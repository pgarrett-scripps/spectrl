#!/usr/bin/env python3
"""Show a real spectrum traveling from a local application to a browser.

The plotted source and token are the same untrimmed BSA example used by the
TOC graphic. The receiving plot is decoded from that token. The viewer address
uses a reserved example domain and illustrates the implemented fragment binding.
"""

from __future__ import annotations

from pathlib import Path

import matplotlib
import numpy as np

from _assets import record
from _bsa import MZML_INPUT, median_ms2
from spectrl import decode_token

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.patches import FancyBboxPatch  # noqa: E402

PAPER = Path(__file__).resolve().parent.parent.parent
OUT = PAPER / "figures" / "workflow.png"
INK = "#0f172a"
MUTED = "#64748b"
BLUE = "#2563eb"
EDGE = "#cbd5e1"
PALE = "#eff6ff"
W, H = 7.5, 3.25


def box(ax, x, y, w, h, face="white"):
    ax.add_patch(FancyBboxPatch(
        (x, y), w, h, boxstyle="round,pad=0,rounding_size=0.06",
        facecolor=face, edgecolor=EDGE, linewidth=0.8,
    ))


def spectrum(fig, x, mz, intensity):
    ax = fig.add_axes([(x + 0.12) / W, 1.89 / H, 1.31 / W, 0.51 / H])
    values = np.asarray(intensity, dtype=float)
    ax.vlines(mz, 0, values / values.max(), color=BLUE, linewidth=0.65)
    ax.set_ylim(0, 1.08)
    ax.set_xticks([])
    ax.set_yticks([])
    ax.spines[["left", "right", "top"]].set_visible(False)
    ax.spines["bottom"].set_color(EDGE)
    ax.set_xlabel("m/z", fontsize=7, color=MUTED, labelpad=2)


def main() -> int:
    mz, intensity, token, _ = median_ms2()
    decoded = decode_token(token)
    identifier, version, mode, payload, checksum = token.split(".")
    if identifier != "spectrl" or version != "v3" or mode not in ("r", "z"):
        raise ValueError("Workflow diagram expects a spectrl.v3 token")
    if len(decoded.mz) != len(mz) or len(decoded.intensity) != len(intensity):
        raise ValueError("Workflow example lost peaks during decoding")

    fig, ax = plt.subplots(figsize=(W, H), dpi=400)
    fig.subplots_adjust(left=0, right=1, bottom=0, top=1)
    ax.set(xlim=(0, W), ylim=(0, H))
    ax.set_axis_off()
    positions = [0.12, 2.02, 3.92, 5.82]
    titles = ["Local spectrum", "spectrl token", "Share a URL", "Browser viewer"]
    notes = ["From a search or analysis", "Python or TypeScript",
             "Token follows the #", "Decode in the browser"]
    for x, title, note in zip(positions, titles, notes):
        box(ax, x, 1.48, 1.56, 1.39, PALE if title == "spectrl token" else "white")
        ax.text(x + 0.78, 2.68, title, ha="center", va="center",
                fontsize=9, fontweight="bold", color=INK)
        ax.text(x + 0.78, 1.61, note, ha="center", va="center",
                fontsize=6.7, color=MUTED)
    for x in positions[:-1]:
        ax.annotate("", xy=(x + 1.86, 2.17), xytext=(x + 1.60, 2.17),
                    arrowprops={"arrowstyle": "-|>", "color": BLUE, "lw": 1.1})
    spectrum(fig, positions[0], mz, intensity)
    spectrum(fig, positions[3], decoded.mz, decoded.intensity)
    ax.text(2.80, 2.23, f"{identifier}.{version}.{mode}.\n{payload[:13]}...\n.{checksum}",
            ha="center", va="center", family="monospace", fontsize=7.5,
            color=BLUE, linespacing=1.6)
    ax.text(4.70, 2.23, "viewer.example/\n#spectrl.v3...",
            ha="center", va="center", family="monospace", fontsize=7.5,
            color=INK, linespacing=1.8)
    ax.text(W / 2, 1.22, "The link carries the spectrum. No spectrum lookup service is required.",
            ha="center", fontsize=9, color=INK)
    ax.text(0.12, 0.86, "Inside the token", fontsize=8.5, color=INK, fontweight="bold")
    fields = [
        (0.12, 1.02, identifier, "identifier"),
        (1.34, 0.55, version, "version"),
        (2.09, 0.45, mode, "mode"),
        (2.74, 3.37, "encoded spectrum data", "peak arrays + spectrum-level fields"),
        (6.31, 1.07, "checksum", "corruption check"),
    ]
    for x, width, value, label in fields:
        box(ax, x, 0.38, width, 0.32, PALE)
        ax.text(x + width / 2, 0.54, value, ha="center", va="center",
                fontsize=8, family="monospace", color=BLUE)
        ax.text(x + width / 2, 0.18, label, ha="center", va="center",
                fontsize=7, color=MUTED)
    for x in [1.24, 1.99, 2.64, 6.21]:
        ax.text(x, 0.54, ".", ha="center", va="center", color=INK, fontsize=11)

    OUT.parent.mkdir(exist_ok=True)
    fig.savefig(OUT, facecolor="white", metadata={"Software": None})
    plt.close(fig)
    record(
        "fig.workflow", str(OUT.relative_to(PAPER)), kind="figure",
        inputs=[MZML_INPUT],
        desc="A real local spectrum encoded as a token, carried in a URL fragment, "
             "and decoded for a browser viewer, with simplified token anatomy",
    )
    print(f"wrote {OUT.relative_to(PAPER)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
