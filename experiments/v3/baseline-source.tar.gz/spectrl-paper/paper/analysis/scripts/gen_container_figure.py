#!/usr/bin/env python3
"""Plot complete URL-safe text lengths and savings against framed gzip mzML."""

from pathlib import Path

import matplotlib
import numpy as np

from _assets import record
from _datasets import encode_all
from _sizes import size_inputs, measure_sizes

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import PercentFormatter

PAPER = Path(__file__).resolve().parent.parent.parent
OUT = PAPER / "figures" / "container_size.png"
SAVINGS_OUT = PAPER / "figures" / "container_savings.png"
MUTED = "#64748b"
EDGE = "#cbd5e1"
COLORS = {1: "#2563eb", 2: "#d97706", 3: "#9333ea"}
MARKERS = {"centroid": "o", "profile": "^", "unknown": "s"}


def style(ax):
    ax.set_xscale("log")
    ax.set_xlabel("Points in spectrum")
    ax.grid(alpha=0.15, which="major")
    ax.spines[["top", "right"]].set_visible(False)
    ax.tick_params(colors=MUTED, labelsize=8)
    for spine in ("left", "bottom"):
        ax.spines[spine].set_color(EDGE)


def main():
    rows = measure_sizes(encode_all())
    absolute_fig, absolutes = plt.subplots(
        1, 2, figsize=(6.8, 3.5), dpi=320, sharex=True, sharey=True,
    )
    savings_fig, framed = plt.subplots(figsize=(6.8, 3.5), dpi=320)
    for r in rows:
        n = r.spectrum.n_peaks
        for ax, size in zip(absolutes, (r.token_bytes, r.framed_xml_bytes)):
            ax.scatter(n, size, s=25, color=COLORS[r.spectrum.ms_level],
                       marker=MARKERS[r.spectrum.representation], edgecolor="white",
                       linewidth=0.4, zorder=3)
        framed.scatter(n, r.framed_saving_pct, s=25, color=COLORS[r.spectrum.ms_level],
                       marker=MARKERS[r.spectrum.representation], edgecolor="white", linewidth=0.4, zorder=3)
    for ax in (*absolutes, framed):
        style(ax)
    for ax, title in zip(absolutes, ("A  spectrl text", "B  Gzip mzML in equivalent text framing")):
        ax.set_yscale("log")
        ax.set_title(title, loc="left", fontsize=9)
    absolutes[0].set_ylabel("Complete URL-safe text (characters)")
    median = np.median([r.framed_saving_pct for r in rows])
    framed.axhline(0, color=EDGE, lw=0.8)
    framed.axhline(median, color=MUTED, lw=0.8, ls="--")
    framed.text(0.97, 0.94, f"Corpus median {median:.1f}%", transform=framed.transAxes,
                ha="right", va="top", fontsize=8, color=MUTED)
    framed.set_title("Versus gzip mzML in equivalent URL-safe text framing", loc="left", fontsize=9)
    framed.yaxis.set_major_formatter(PercentFormatter(100))
    framed.set_ylabel("Text length reduction")
    framed.set_ylim(
        min(-3, min(r.framed_saving_pct for r in rows) - 3),
        max(10, np.ceil(max(r.framed_saving_pct for r in rows) / 10) * 10),
    )
    categories = [
        Line2D([], [], marker="o", ls="", color=color, markersize=5, label=f"MS{level}")
        for level, color in COLORS.items()
    ] + [
        Line2D([], [], marker=MARKERS[mode], ls="", color=MUTED, markersize=5, label=mode.capitalize())
        for mode in sorted({r.spectrum.representation for r in rows})
    ]
    savings_fig.legend(handles=categories, loc="lower center", ncol=len(categories),
                       frameon=False, fontsize=8)
    absolute_fig.legend(handles=categories, loc="lower center", ncol=len(categories),
                        frameon=False, fontsize=8)
    absolute_fig.subplots_adjust(left=0.10, right=0.99, top=0.91, bottom=0.25, wspace=0.15)
    savings_fig.subplots_adjust(left=0.11, right=0.99, top=0.91, bottom=0.25, wspace=0.20)
    absolute_fig.savefig(OUT, metadata={"Software": None}, bbox_inches="tight")
    savings_fig.savefig(SAVINGS_OUT, metadata={"Software": None}, bbox_inches="tight")
    plt.close(absolute_fig)
    plt.close(savings_fig)
    record("fig.container", str(OUT.relative_to(PAPER)), kind="figure", inputs=size_inputs(),
           desc="Complete URL-safe text lengths with matched raw-zlib arrays and complete context")
    record("fig.savings", str(SAVINGS_OUT.relative_to(PAPER)), kind="figure", inputs=size_inputs(),
           desc="Per-spectrum text length savings against equivalently framed gzip mzML by point count, MS level, and representation")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
