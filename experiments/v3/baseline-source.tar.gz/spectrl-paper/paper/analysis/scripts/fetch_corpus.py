#!/usr/bin/env python3
"""Download the public benchmark corpus and verify every content hash."""

from __future__ import annotations

import hashlib
import io
import json
import urllib.request
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
PAPER = HERE.parent.parent
MANIFEST = PAPER / "analysis" / "data" / "corpus.json"


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def main() -> int:
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    for dataset in manifest["datasets"]:
        target = (PAPER / dataset["local_path"]).resolve()
        if target.exists() and digest(target.read_bytes()) == dataset["sha256"]:
            print(f"ok       {dataset['key']}: {target}")
            continue
        if "url" in dataset:
            with urllib.request.urlopen(dataset["url"]) as response:
                data = response.read()
        elif "archive_url" in dataset:
            with urllib.request.urlopen(dataset["archive_url"]) as response:
                archive = zipfile.ZipFile(io.BytesIO(response.read()))
                matches = [name for name in archive.namelist() if Path(name).name == dataset["archive_member"]]
                if len(matches) != 1:
                    raise RuntimeError(f"expected one {dataset['archive_member']} in archive, found {matches}")
                data = archive.read(matches[0])
        else:
            raise FileNotFoundError(f"missing local-only corpus input: {target}")
        actual = digest(data)
        if actual != dataset["sha256"]:
            raise RuntimeError(f"hash mismatch for {dataset['key']}: expected {dataset['sha256']}, got {actual}")
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        print(f"download {dataset['key']}: {target}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
