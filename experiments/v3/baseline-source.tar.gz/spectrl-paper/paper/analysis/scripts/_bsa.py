"""Select real BSA spectra used by the worked example and figures.

The mzML lives in the parent repository's test data
(../tests/data/BSA1.mzML relative to the manuscript root).
"""

from __future__ import annotations

import warnings
from pathlib import Path

import numpy as np
from mzmlpy.run import Mzml

from spectrl import encode_spectrum, from_mzmlpy

HERE = Path(__file__).resolve().parent
PAPER = HERE.parent.parent  # analysis/scripts/ -> analysis/ -> paper/
MZML = (PAPER / ".." / "tests" / "data" / "BSA1.mzML").resolve()
MZML_INPUT = "../tests/data/BSA1.mzML"  # as declared to the provenance manifest


def _ms_level(inline) -> int:
    for p in inline.params:
        if p.accession == "MS:1000511":
            return int(p.value)
    return 0


def median_ms2() -> tuple[np.ndarray, np.ndarray, str, str]:
    """The real MS2 spectrum whose lossy token is closest to the median size.

    The representative example for the anatomy figure. Returns
    (mz, intensity, token, spectrum id).
    """
    candidates = []
    with Mzml(str(MZML)) as mzml:
        ref_groups = {g.id: g for g in mzml.referenceable_param_groups}
        for spec in mzml.spectra:
            inline = from_mzmlpy(spec, ref_groups=ref_groups, run=mzml)
            if inline.mz is None or len(inline.mz) == 0 or _ms_level(inline) != 2:
                continue
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                token = encode_spectrum(inline)
            candidates.append((len(token), inline, token))
    candidates.sort(key=lambda c: c[0])
    _, inline, token = candidates[len(candidates) // 2]
    return np.asarray(inline.mz), np.asarray(inline.intensity), token, inline.id or ""


def smallest_ms2(min_peaks: int = 10) -> tuple[np.ndarray, np.ndarray, str, str]:
    """The real MS2 spectrum with the smallest lossy token, at least min_peaks.

    Used for the SI's worked example: compact enough to print, but still a
    complete, untrimmed spectrum. Returns (mz, intensity, token, spectrum id).
    """
    best = None
    with Mzml(str(MZML)) as mzml:
        ref_groups = {g.id: g for g in mzml.referenceable_param_groups}
        for spec in mzml.spectra:
            inline = from_mzmlpy(spec, ref_groups=ref_groups, run=mzml)
            if inline.mz is None or len(inline.mz) < min_peaks:
                continue
            if _ms_level(inline) != 2:
                continue
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                token = encode_spectrum(inline)
            if best is None or len(token) < len(best[2]):
                best = (np.asarray(inline.mz), np.asarray(inline.intensity), token, inline.id or "")
    if best is None:
        raise RuntimeError(f"no MS2 spectrum with at least {min_peaks} peaks")
    return best
