"""Check corpus arrays and modeled metadata across both implementations."""

from __future__ import annotations

import json
import subprocess
from dataclasses import fields, is_dataclass
from pathlib import Path

import numpy as np

from spectrl import decode_token
from _datasets import _assert_metadata_equal

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[2]
VALIDATOR = HERE / "validate_tokens.mjs"


def _camel(name):
    first, *rest = name.split("_")
    return first + "".join(part.title() for part in rest)


def model_json(value):
    """Pass source models through JSON without using either token decoder."""
    if is_dataclass(value):
        return {
            _camel(field.name): model_json(getattr(value, field.name))
            for field in fields(value)
            if field.name not in {"checksum", "format_version"}
        }
    if isinstance(value, np.ndarray):
        return {"dtype": value.dtype.name, "values": value.tolist()}
    if isinstance(value, dict):
        return {_camel(key) if key in {"user_params", "source_params", "external_ids", "spectrum_ref"} else key: model_json(item) for key, item in value.items()}
    if isinstance(value, list):
        return [model_json(item) for item in value]
    return value


def _canonical(value, key=""):
    if isinstance(value, dict):
        return {k: _canonical(v, k) for k, v in value.items() if v is not None}
    if isinstance(value, list):
        items = [_canonical(v) for v in value]
        return items
    return value


def assert_equal(expected, actual, *, lossless, label):
    """Compare every array and modeled field, including parameter order."""
    expected = dict(expected)
    actual = dict(actual)
    for name in ("mz", "intensity", "charge", "extraArrays"):
        left = expected.pop(name)
        right = actual.pop(name)
        arrays = {name: (left, right)}
        if name == "extraArrays":
            if left.keys() != right.keys():
                raise AssertionError(f"{label}: auxiliary array names changed")
            arrays = {key: (left[key], right[key]) for key in left}
        for key, (a, b) in arrays.items():
            if a is None or b is None:
                if a != b:
                    raise AssertionError(f"{label}: {key} presence changed")
                continue
            if a["dtype"] != b["dtype"]:
                raise AssertionError(f"{label}: {key} dtype changed")
            if len(a["values"]) != len(b["values"]):
                raise AssertionError(f"{label}: {key} length changed")
            if lossless:
                if np.asarray(a["values"], dtype=a["dtype"]).tobytes() != np.asarray(b["values"], dtype=b["dtype"]).tobytes():
                    raise AssertionError(f"{label}: {key} bits changed")
            else:
                # Allow runtime rounding far below source quantization error.
                np.testing.assert_allclose(
                    a["values"],
                    b["values"],
                    rtol=1e-12,
                    atol=1e-12,
                    err_msg=f"{label}: {key}",
                )
    if _canonical(expected) != _canonical(actual):
        raise AssertionError(f"{label}: modeled metadata changed")


def assert_cross_language(rows):
    requests = [{"source": model_json(row.source), "tokens": [row.lossy_token, row.lossless_token]} for row in rows]
    proc = subprocess.run(
        ["node", str(VALIDATOR)],
        input="".join(json.dumps(request, allow_nan=False) + "\n" for request in requests),
        text=True,
        capture_output=True,
        check=True,
        cwd=REPO,
    )
    results = [json.loads(line) for line in proc.stdout.splitlines()]
    if len(results) != len(rows):
        raise AssertionError("TypeScript returned an incomplete corpus")
    forward = reverse = 0
    for row, result in zip(rows, results, strict=True):
        if len(result["decoded"]) != 2 or len(result["tokens"]) != 2:
            raise AssertionError(f"{row.spectrum_id}: expected both encoding modes")
        source = model_json(row.source)
        order = np.argsort(row.source.mz, kind="stable")
        for array in [source["mz"], source["intensity"], source["charge"], *source["extraArrays"].values()]:
            if array is not None:
                array["values"] = np.asarray(array["values"])[order].tolist()
        for index, py_token in enumerate((row.lossy_token, row.lossless_token)):
            lossless = index == 1
            label = f"{row.dataset.key}/{row.spectrum_id}, {'lossless' if lossless else 'default'}"
            reference = model_json(decode_token(py_token))
            assert_equal(reference, result["decoded"][index], lossless=lossless, label=f"Python to TS: {label}")
            forward += 1
            decoded_model = decode_token(result["tokens"][index])
            _assert_metadata_equal(row.source, decoded_model, lossy=not lossless)
            decoded = model_json(decoded_model)
            assert_equal(reference, decoded, lossless=lossless, label=f"TS to Python: {label}")
            if lossless:
                assert_equal(source, decoded, lossless=True, label=f"TS lossless source: {label}")
            else:
                metadata_reference = {**source, **{k: decoded[k] for k in ("mz", "intensity", "charge", "extraArrays", "arrayProcessing")}}
                assert_equal(metadata_reference, decoded, lossless=True, label=f"TS metadata: {label}")
            reverse += 1
    for vector in json.loads((REPO / "test-vectors/reverse-vectors.json").read_text())["vectors"]:
        decode_token(vector["token"])
    print(f"Corpus interoperability passed: {forward} Python to TypeScript, {reverse} TypeScript to Python")
    return forward, reverse
