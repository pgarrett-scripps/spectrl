"""Rebuild a bundled corpus subset from its recorded converted mzML source.

Usage: uv run python scripts/rebuild_subset.py DATASET SOURCE_MZML
The manifest records original downloads, conversion settings, and native IDs.
Ordinary corpus reproduction uses the small bundled files directly.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import xml.etree.ElementTree as ET
from pathlib import Path

PAPER = Path(__file__).resolve().parents[2]
NS = "{http://psi.hupo.org/ms/mzml}"
ET.register_namespace("", NS[1:-1])
ET.register_namespace("xsi", "http://www.w3.org/2001/XMLSchema-instance")


def digest(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def extract(source: Path, selected_ids: list[str], output: Path, *, allow_external_precursors: bool = False) -> None:
    wanted = set(selected_ids)
    if len(wanted) != len(selected_ids) or not wanted:
        raise ValueError("Native spectrum IDs must be unique and nonempty")
    root = None
    run = None
    spectra = None
    stack = []
    for event, elem in ET.iterparse(source, events=("start", "end")):
        if event == "start":
            stack.append(elem)
            if elem.tag == NS + "mzML":
                root = ET.Element(elem.tag, elem.attrib)
            elif elem.tag == NS + "run":
                run = ET.SubElement(root, elem.tag, elem.attrib)
            elif elem.tag == NS + "spectrumList":
                spectra = ET.SubElement(run, elem.tag, {**elem.attrib, "count": str(len(wanted))})
            continue
        if elem.tag == NS + "spectrum":
            if elem.attrib["id"] in wanted:
                saved = copy.deepcopy(elem)
                saved.set("index", str(len(spectra)))
                spectra.append(saved)
            stack[-2].remove(elem)
        elif len(stack) > 1 and stack[-2].tag == NS + "mzML" and elem.tag != NS + "run":
            root.append(copy.deepcopy(elem))
            stack[-2].remove(elem)
        elif elem.tag == NS + "chromatogram":
            stack[-2].remove(elem)
        stack.pop()
    if spectra is None or len(spectra) != len(wanted):
        raise ValueError("Source does not contain all selected spectra")
    for spec in spectra:
        for precursor in spec.iter(NS + "precursor"):
            ref = precursor.attrib.get("spectrumRef")
            if ref is not None and ref not in wanted and not allow_external_precursors:
                raise ValueError(f"Subset omits precursor spectrum {ref}")
    output.parent.mkdir(parents=True, exist_ok=True)
    ET.ElementTree(root).write(output, encoding="utf-8", xml_declaration=True)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("dataset")
    parser.add_argument("source", type=Path)
    args = parser.parse_args()
    manifest = json.loads((PAPER / "analysis/data/corpus.json").read_text())
    item = next(d for d in manifest["datasets"] if d["key"] == args.dataset)
    derivation = item["derivation"]
    if digest(args.source) != derivation["mzml_sha256"]:
        raise ValueError("Source mzML hash does not match the recorded conversion")
    output = PAPER / item["local_path"]
    temporary = output.with_suffix(".mzML.partial")
    try:
        extract(args.source, derivation["selected_ids"], temporary,
                allow_external_precursors=derivation.get("allow_external_precursors", False))
        if digest(temporary) != item["sha256"]:
            raise ValueError("Rebuilt subset hash does not match the corpus manifest")
        temporary.replace(output)
    finally:
        temporary.unlink(missing_ok=True)
    print(f"Rebuilt and verified {output}")


if __name__ == "__main__":
    main()
