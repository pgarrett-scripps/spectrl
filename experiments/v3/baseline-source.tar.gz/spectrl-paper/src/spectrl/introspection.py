"""Public token and resolved-encoding inspection helpers."""

from __future__ import annotations

from .cbor_format import encode_cbor, read_token_document
from .cv import decode_tail, decode_unit_tail
from .header import DESC_ARRAY, DESC_DATA, DESC_NAME, DESC_TYPE, DESC_UNIT
from .model import ArrayEncoding, InlineSpectrum
from .pipeline import COMPRESSORS, ENCODINGS, psi_alias


def inspect_token(token: str) -> list[dict[str, object]]:
    """Return resolved metadata for every array in a verified token."""
    doc, _ = read_token_document(token)
    out: list[dict[str, object]] = []
    for desc in doc.get(6, []):
        tail = desc[DESC_ARRAY]
        item: dict[str, object] = {
            "accession": decode_tail(tail),
            "name": desc.get(DESC_NAME),
            "type_accession": decode_tail(desc[DESC_TYPE]),
            "compression_accession": psi_alias(desc[2], desc[3]),
            "encoding": desc[2],
            "compression": desc[3],
            "fidelity": "exact" if desc[7] == 0 else "lossy",
            "available": tuple(desc[2][:2]) in ENCODINGS and tuple(desc[3][:2]) in COMPRESSORS,
            "fixed_point": desc[2][2].get("fp") if len(desc[2]) == 3 else None,
            "compressed_bytes": len(desc.get(DESC_DATA, b"")),
        }
        if DESC_UNIT in desc:
            item["unit_accession"] = decode_unit_tail(desc[DESC_UNIT])
        out.append(item)
    return out


def encoding_plan(
    spec: InlineSpectrum,
    *,
    lossless: bool = False,
    array_encodings: dict[str, ArrayEncoding | str | int | dict] | None = None,
    allow_unsafe_lossy_custom: bool = False,
) -> list[dict[str, object]]:
    """Resolve automatic codecs, fixed points, types, and units for a spectrum."""
    token = encode_cbor(
        spec,
        lossless=lossless,
        array_encodings=array_encodings,
        allow_unsafe_lossy_custom=allow_unsafe_lossy_custom,
    )
    return inspect_token(token)
