"""Versioned array encodings and byte compressors for spectrl v3."""

from __future__ import annotations

import re
import struct
import zlib
from collections.abc import Callable
from dataclasses import dataclass

import cbor2
import numpy as np
import zstandard

from ._format import MAX_BLOB_BYTES, MAX_SAFE_INTEGER
from .codecs._delta import delta_shuffle, delta_unshuffle
from .codecs._zlibutil import bounded_decompress
from .codecs.dictionary import dictionary_decode, dictionary_encode, shuffle
from .codecs.numpress import (
    decode_numlin_raw,
    decode_numpic_raw,
    decode_numslof_raw,
    encode_numlin_raw,
    encode_numpic_raw,
    encode_numslof_raw,
)
from .codecs.raw import _np_dtype
from .codecs.zstd import bounded_zstd_decompress
from .cv import TYPE_FLOAT64

DESC_ENCODING = 2
DESC_COMPRESSION = 3
DESC_FIDELITY = 7
DESC_PARAMS = 8
DESC_USER_PARAMS = 9
DESC_PROCESSING = 10
DESC_EXTENSIONS = 11

ENCODING_NAMES = {
    "raw": 0,
    "byte-shuffle": 1,
    "dictionary": 2,
    "modular-delta-shuffle": 3,
    "numlin": 4,
    "numpic": 5,
    "numslof": 6,
}
COMPRESSION_NAMES = {"none": 0, "zlib": 1, "zstd": 2}
PSI_ALIASES = {
    1000576: (0, 0),
    1000574: (0, 1),
    1003780: (0, 2),
    1003781: (1, 2),
    1003782: (2, 2),
    1002312: (4, 0),
    1002313: (5, 0),
    1002314: (6, 0),
    1002746: (4, 1),
    1002747: (5, 1),
    1002748: (6, 1),
    1003783: (4, 2),
    1003784: (5, 2),
    1003785: (6, 2),
}
PIPELINE_NAMES = {
    "none": (0, 0),
    "zlib": (0, 1),
    "zstd": (0, 2),
    "byte-shuffled-zstd": (1, 2),
    "dictionary-zstd": (2, 2),
    "delta-shuffled-zlib": (3, 1),
    "delta-shuffled-zstd": (3, 2),
    **{
        f"{e}-{c}": (ENCODING_NAMES[e], COMPRESSION_NAMES[c])
        for e in ("numlin", "numpic", "numslof")
        for c in ("zlib", "zstd")
    },
}
_ID = re.compile(r"^[A-Za-z][A-Za-z0-9._-]*:[A-Za-z0-9._/-]+$")


def descriptor(value, names=None):
    """Normalize public operation settings or validate a wire tuple."""
    if isinstance(value, (str, int)) and not isinstance(value, bool):
        value = [value, 1]
    elif isinstance(value, dict):
        if set(value) - {"id", "revision", "parameters"} or "id" not in value:
            raise ValueError("invalid operation descriptor")
        value = [value["id"], value.get("revision", 1), value.get("parameters", {})]
    if not isinstance(value, list) or len(value) not in (2, 3):
        raise ValueError("operation must be [identifier, revision, optional parameters]")
    identifier, revision = value[:2]
    if names and isinstance(identifier, str):
        identifier = names.get(identifier.removeprefix("spectrl:"), identifier)
    if not (
        (type(identifier) is int and 0 <= identifier <= MAX_SAFE_INTEGER)
        or (isinstance(identifier, str) and _ID.fullmatch(identifier))
    ):
        raise ValueError("operation identifier must be a built-in integer or namespaced string")
    if type(revision) is not int or not 1 <= revision <= MAX_SAFE_INTEGER:
        raise ValueError("operation revision must be a positive safe integer")
    params = value[2] if len(value) == 3 else {}
    if not isinstance(params, dict) or not all(isinstance(k, str) for k in params):
        raise ValueError("operation parameters must be a string-keyed map")
    return [identifier, revision, params] if params else [identifier, revision]


@dataclass(frozen=True)
class Encoding:
    """Callbacks encode(array, type, parameters) and decode(bytes, type, count, parameters)."""

    encode: Callable
    decode: Callable
    validate: Callable
    lossless: bool = True
    types: tuple[int, ...] = (1000521, 1000523, 1000519)


@dataclass(frozen=True)
class Compressor:
    """Callbacks encode(bytes, parameters) and decode(bytes, maximum_bytes, parameters)."""

    encode: Callable
    decode: Callable
    validate: Callable


ENCODINGS: dict[tuple[int | str, int], Encoding] = {}
COMPRESSORS: dict[tuple[int | str, int], Compressor] = {}


def _register(registry, identifier, implementation, revision):
    desc = descriptor([identifier, revision])
    if not isinstance(identifier, str) or not _ID.fullmatch(identifier) or identifier.startswith("spectrl:"):
        raise ValueError("custom registrations require a non-spectrl namespaced identifier")
    key = tuple(desc[:2])
    if key in registry:
        raise ValueError(f"operation is already registered: {identifier}@{revision}")
    registry[key] = implementation


def register_encoding(identifier: str, implementation: Encoding, *, revision: int = 1):
    if not isinstance(implementation, Encoding):
        raise TypeError("implementation must be an Encoding")
    _register(ENCODINGS, identifier, implementation, revision)


def register_compressor(identifier: str, implementation: Compressor, *, revision: int = 1):
    if not isinstance(implementation, Compressor):
        raise TypeError("implementation must be a Compressor")
    _register(COMPRESSORS, identifier, implementation, revision)


def operation(registry, desc):
    desc = descriptor(desc)
    try:
        impl = registry[tuple(desc[:2])]
    except KeyError:
        raise ValueError(f"unsupported operation {desc[0]!r} revision {desc[1]}") from None
    params = desc[2] if len(desc) == 3 else {}
    impl.validate(params)
    return impl, params


def _empty(params):
    if params:
        raise ValueError("this operation does not accept parameters")


def _fixed(params):
    if set(params) != {"fp"} or type(params["fp"]) is not int or not 0 < params["fp"] <= MAX_SAFE_INTEGER:
        raise ValueError("Numpress requires a positive safe-integer fp parameter")


def _level(params, maximum):
    if set(params) - {"level"} or (
        "level" in params and (type(params["level"]) is not int or not 0 <= params["level"] <= maximum)
    ):
        raise ValueError("invalid compression level")


def _raw(data, tail, params):
    return np.asarray(data).astype(_np_dtype(tail)).tobytes()


def _from_raw(raw, tail, n, params):
    dtype = np.dtype(_np_dtype(tail))
    if len(raw) != n * dtype.itemsize:
        raise ValueError("decoded byte length does not match dtype and count")
    return np.frombuffer(raw, dtype).copy()


def _transform(forward, inverse):
    return Encoding(
        lambda a, t, p: forward(_raw(a, t, p), np.dtype(_np_dtype(t)).itemsize),
        lambda b, t, n, p: _from_raw(inverse(b, np.dtype(_np_dtype(t)).itemsize), t, n, p),
        _empty,
    )


def _numpress_decode(fn, blob, tail, n, params):
    if params and (len(blob) < 8 or struct.unpack(">d", blob[:8])[0] != params["fp"]):
        raise ValueError("Numpress fixed point mismatch")
    result = fn(blob)
    if len(result) != n:
        raise ValueError("Numpress count mismatch")
    return result


ENCODINGS.update(
    {
        (0, 1): Encoding(_raw, _from_raw, _empty),
        (1, 1): _transform(shuffle, lambda b, w: shuffle(b, w, inverse=True)),
        (2, 1): _transform(dictionary_encode, dictionary_decode),
        (3, 1): _transform(delta_shuffle, delta_unshuffle),
    }
)
for _id, _enc, _dec in [
    (4, encode_numlin_raw, decode_numlin_raw),
    (5, encode_numpic_raw, decode_numpic_raw),
    (6, encode_numslof_raw, decode_numslof_raw),
]:
    ENCODINGS[(_id, 1)] = Encoding(
        lambda a, t, p, fn=_enc: fn(a, p["fp"]) if p else fn(a),
        lambda b, t, n, p, fn=_dec: _numpress_decode(fn, b, t, n, p),
        _empty if _id == 5 else _fixed,
        lossless=False,
        types=(TYPE_FLOAT64,),
    )


def _none_decode(blob, cap, params):
    if len(blob) > cap:
        raise ValueError("uncompressed data exceeds byte limit")
    return blob


COMPRESSORS.update(
    {
        (0, 1): Compressor(lambda b, p: b, _none_decode, _empty),
        (1, 1): Compressor(
            lambda b, p: zlib.compress(b, p.get("level", 6)),
            lambda b, cap, p: bounded_decompress(b, cap),
            lambda p: _level(p, 9),
        ),
        (2, 1): Compressor(
            lambda b, p: zstandard.ZstdCompressor(level=p.get("level", 3)).compress(b),
            lambda b, cap, p: bounded_zstd_decompress(b, cap),
            lambda p: _level(p, 19),
        ),
    }
)


def encode_pipeline(data, tail, enc, comp):
    encoding, ep = operation(ENCODINGS, enc)
    compressor, cp = operation(COMPRESSORS, comp)
    if tail not in encoding.types:
        raise ValueError("encoding does not support the declared dtype")
    raw = encoding.encode(data, tail, ep)
    if not isinstance(raw, bytes) or len(raw) > min(MAX_BLOB_BYTES, 64 + 16 * len(data)):
        raise ValueError("encoding exceeds the intermediate byte limit")
    blob = compressor.encode(raw, cp)
    if not isinstance(blob, bytes):
        raise ValueError("compressor must return bytes")
    return blob, 0 if encoding.lossless else 1


def decode_pipeline(blob, tail, count, enc, comp, fidelity):
    encoding, ep = operation(ENCODINGS, enc)
    compressor, cp = operation(COMPRESSORS, comp)
    if tail not in encoding.types or fidelity != (0 if encoding.lossless else 1):
        raise ValueError("encoding dtype or fidelity declaration mismatch")
    cap = min(MAX_BLOB_BYTES, 64 + 16 * count)
    raw = compressor.decode(blob, cap, cp)
    if not isinstance(raw, bytes) or len(raw) > cap:
        raise ValueError("decompressed data exceeds byte limit")
    # Dictionary expansion is bounded before constructing an output array.
    if enc[:2] == [2, 1] and raw:
        if len(raw) < 16:
            raise ValueError("truncated dictionary")
        from .codecs.dictionary import index_width

        offset, entries = struct.unpack("<QQ", raw[:16])
        if entries > count or len(raw) - offset != count * index_width(entries):
            raise ValueError("dictionary dimensions exceed declared count")
    result = encoding.decode(raw, tail, count, ep)
    if not isinstance(result, np.ndarray) or result.ndim != 1 or len(result) != count:
        raise ValueError("encoding returned an invalid array shape")
    if result.dtype != np.dtype(_np_dtype(tail)):
        raise ValueError("encoding returned an incorrect dtype")
    return result


def adaptive(data, tail):
    """Minimize serialized descriptor cost with stable candidate ordering."""
    best = None
    for enc, comp in [(0, 1), (0, 2), (1, 2), (2, 2), (3, 1), (3, 2), (0, 0)]:
        ed, cd = [enc, 1], [comp, 1]
        blob, fidelity = encode_pipeline(data, tail, ed, cd)
        size = len(cbor2.dumps({2: ed, 3: cd, 5: blob, 7: fidelity}, canonical=True))
        if best is None or size < best[0]:
            best = (size, blob, ed, cd, fidelity)
    return best[1:]


def psi_alias(enc, comp):
    if enc[1] != 1 or comp[1] != 1:
        return None
    return next((f"MS:{key}" for key, pair in PSI_ALIASES.items() if pair == (enc[0], comp[0])), None)
