"""Sorted unsigned-word dictionary and byte shuffle, PSI MS:1003782 layout."""

import struct

import numpy as np


def shuffle(raw, width, inverse=False):
    if width not in (1, 2, 4, 8) or len(raw) % width:
        raise ValueError("invalid word width or byte length")
    data = np.frombuffer(raw, dtype=np.uint8)
    shape = (width, -1) if inverse else (-1, width)
    return data.reshape(shape).T.copy().tobytes()


def index_width(count):
    # Maintained mzdata encoder and decoder use <= 2**bits, allowing index zero.
    for width in (1, 2, 4, 8):
        if count <= 1 << (8 * width):
            return width
    raise ValueError("dictionary too large")


def dictionary_encode(raw, width):
    if width not in (4, 8) or len(raw) % width:
        raise ValueError("invalid numeric representation")
    if not raw:
        return b""
    words = np.frombuffer(raw, dtype=f"<u{width}")
    values, indices = np.unique(words, return_inverse=True)
    count = len(values)
    iw = index_width(count)
    header = struct.pack("<QQ", 16 + count * width, count)
    return (
        header
        + shuffle(values.astype(f"<u{width}").tobytes(), width)
        + shuffle(indices.astype(f"<u{iw}").tobytes(), iw)
    )


def dictionary_decode(blob, width):
    if width not in (4, 8):
        raise ValueError("invalid word width")
    if not blob:
        return b""
    if len(blob) < 16:
        raise ValueError("truncated dictionary header")
    offset, count = struct.unpack("<QQ", blob[:16])
    if not count or offset != 16 + count * width or offset > len(blob):
        raise ValueError("invalid dictionary dimensions")
    values = np.frombuffer(shuffle(blob[16:offset], width, inverse=True), dtype=f"<u{width}")
    iw = index_width(count)
    indices = np.frombuffer(shuffle(blob[offset:], iw, inverse=True), dtype=f"<u{iw}")
    if len(indices) and int(indices.max()) >= count:
        raise ValueError("dictionary index out of range")
    return values[indices].astype(f"<u{width}").tobytes()
