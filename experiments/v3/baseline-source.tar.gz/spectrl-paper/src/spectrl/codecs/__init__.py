"""Codec registry keyed by compression CV accession tail integer."""

from __future__ import annotations

from typing import Protocol

import numpy as np

from ..cv import (
    COMP_BYTE_SHUFFLED_ZSTD,
    COMP_NUMLIN_ZLIB,
    COMP_NUMLIN_ZSTD,
    COMP_NUMPIC_ZLIB,
    COMP_NUMPIC_ZSTD,
    COMP_NUMSLOF_ZLIB,
    COMP_NUMSLOF_ZSTD,
    COMP_ZLIB,
    COMP_ZSTD,
    TYPE_FLOAT64,
)
from .numpress import (
    decode_numlin_zlib,
    decode_numpic_zlib,
    decode_numslof_zlib,
    encode_numlin_zlib,
    encode_numpic_zlib,
    encode_numslof_zlib,
)
from .raw import decode_zlib_raw, encode_zlib_raw
from .zstd import (
    decode_byte_shuffled_zstd,
    decode_numlin_zstd,
    decode_numpic_zstd,
    decode_numslof_zstd,
    decode_zstd_raw,
    encode_byte_shuffled_zstd,
    encode_numlin_zstd,
    encode_numpic_zstd,
    encode_numslof_zstd,
    encode_zstd_raw,
)


class Codec(Protocol):
    # type_tail is only meaningful for the raw codec (which preserves the declared
    # binary data type); the lossy numpress codecs always operate on float64.
    # max_bytes bounds the decompressed size when decoding untrusted input.
    def encode(self, data: np.ndarray, fp: float | None, type_tail: int = TYPE_FLOAT64) -> bytes: ...
    def decode(self, blob: bytes, type_tail: int = TYPE_FLOAT64, max_bytes: int | None = None) -> np.ndarray: ...


class _NumLinZlibCodec:
    def encode(self, data: np.ndarray, fp: float | None, type_tail: int = TYPE_FLOAT64) -> bytes:
        return encode_numlin_zlib(data, fp)

    def decode(self, blob: bytes, type_tail: int = TYPE_FLOAT64, max_bytes: int | None = None) -> np.ndarray:
        return decode_numlin_zlib(blob, max_bytes)


class _NumSlofZlibCodec:
    def encode(self, data: np.ndarray, fp: float | None, type_tail: int = TYPE_FLOAT64) -> bytes:
        return encode_numslof_zlib(data, fp)

    def decode(self, blob: bytes, type_tail: int = TYPE_FLOAT64, max_bytes: int | None = None) -> np.ndarray:
        return decode_numslof_zlib(blob, max_bytes)


class _NumPicZlibCodec:
    def encode(self, data: np.ndarray, fp: float | None, type_tail: int = TYPE_FLOAT64) -> bytes:
        return encode_numpic_zlib(data, fp)

    def decode(self, blob: bytes, type_tail: int = TYPE_FLOAT64, max_bytes: int | None = None) -> np.ndarray:
        return decode_numpic_zlib(blob, max_bytes)


class _ZlibRawCodec:
    def encode(self, data: np.ndarray, fp: float | None, type_tail: int = TYPE_FLOAT64) -> bytes:
        return encode_zlib_raw(data, type_tail)

    def decode(self, blob: bytes, type_tail: int = TYPE_FLOAT64, max_bytes: int | None = None) -> np.ndarray:
        return decode_zlib_raw(blob, type_tail, max_bytes)


class _ZstdRawCodec:
    def encode(self, data: np.ndarray, fp: float | None, type_tail: int = TYPE_FLOAT64) -> bytes:
        return encode_zstd_raw(data, type_tail)

    def decode(self, blob: bytes, type_tail: int = TYPE_FLOAT64, max_bytes: int | None = None) -> np.ndarray:
        return decode_zstd_raw(blob, type_tail, max_bytes)


class _ByteShuffledZstdCodec:
    def encode(self, data: np.ndarray, fp: float | None, type_tail: int = TYPE_FLOAT64) -> bytes:
        return encode_byte_shuffled_zstd(data, type_tail)

    def decode(self, blob: bytes, type_tail: int = TYPE_FLOAT64, max_bytes: int | None = None) -> np.ndarray:
        return decode_byte_shuffled_zstd(blob, type_tail, max_bytes)


class _NumLinZstdCodec:
    def encode(self, data: np.ndarray, fp: float | None, type_tail: int = TYPE_FLOAT64) -> bytes:
        return encode_numlin_zstd(data, fp)

    def decode(self, blob: bytes, type_tail: int = TYPE_FLOAT64, max_bytes: int | None = None) -> np.ndarray:
        return decode_numlin_zstd(blob, max_bytes)


class _NumSlofZstdCodec:
    def encode(self, data: np.ndarray, fp: float | None, type_tail: int = TYPE_FLOAT64) -> bytes:
        return encode_numslof_zstd(data, fp)

    def decode(self, blob: bytes, type_tail: int = TYPE_FLOAT64, max_bytes: int | None = None) -> np.ndarray:
        return decode_numslof_zstd(blob, max_bytes)


class _NumPicZstdCodec:
    def encode(self, data: np.ndarray, fp: float | None, type_tail: int = TYPE_FLOAT64) -> bytes:
        return encode_numpic_zstd(data)

    def decode(self, blob: bytes, type_tail: int = TYPE_FLOAT64, max_bytes: int | None = None) -> np.ndarray:
        return decode_numpic_zstd(blob, max_bytes)


_REGISTRY: dict[int, Codec] = {
    COMP_NUMLIN_ZLIB: _NumLinZlibCodec(),
    COMP_NUMSLOF_ZLIB: _NumSlofZlibCodec(),
    COMP_NUMPIC_ZLIB: _NumPicZlibCodec(),
    COMP_ZLIB: _ZlibRawCodec(),
    COMP_ZSTD: _ZstdRawCodec(),
    COMP_BYTE_SHUFFLED_ZSTD: _ByteShuffledZstdCodec(),
    COMP_NUMLIN_ZSTD: _NumLinZstdCodec(),
    COMP_NUMSLOF_ZSTD: _NumSlofZstdCodec(),
    COMP_NUMPIC_ZSTD: _NumPicZstdCodec(),
}


def get_codec(comp_tail: int) -> Codec:
    """Return the codec for a given compression accession tail.

    Raises KeyError if the tail is not registered.
    """
    if comp_tail not in _REGISTRY:
        raise KeyError(f"No codec registered for compression tail {comp_tail}.")
    return _REGISTRY[comp_tail]


def encode_adaptive_lossless(data: np.ndarray, type_tail: int = TYPE_FLOAT64) -> tuple[bytes, int]:
    """Choose the smallest supported lossless blob with a stable tie order.

    All three compression accessions have the same CBOR integer width and
    leave the other descriptor fields unchanged. Minimizing blob length also
    minimizes the serialized descriptor, including its byte-string header.
    """
    best_comp = COMP_ZLIB
    best_blob = get_codec(best_comp).encode(data, None, type_tail)
    for comp in (COMP_ZSTD, COMP_BYTE_SHUFFLED_ZSTD):
        blob = get_codec(comp).encode(data, None, type_tail)
        if len(blob) < len(best_blob):
            best_blob, best_comp = blob, comp
    return best_blob, best_comp
